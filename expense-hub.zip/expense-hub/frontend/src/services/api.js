const DEFAULT_API_BASE_URL = 'http://localhost:4000/api'

const ACTION_CONFIGS = {
  bootstrap: { method: 'GET', endpoint: '/health' },
  login: { method: 'POST', endpoint: '/auth/login' },
  register: { method: 'POST', endpoint: '/auth/register' },
  getManagers: { method: 'GET', endpoint: '/auth/managers' },
  getAdminUsers: { method: 'GET', endpoint: '/admin/users' },
  updateProfile: { method: 'PATCH', endpoint: '/auth/profile' },
  changePassword: { method: 'POST', endpoint: '/auth/change-password' }
}

export function getApiConfig() {
  const apiBaseUrl = (import.meta.env.VITE_API_BASE_URL || DEFAULT_API_BASE_URL).replace(/\/$/, '')

  return { apiBaseUrl }
}

export function isApiConfigured() {
  return Boolean(getApiConfig().apiBaseUrl)
}

export async function apiRequest(action, payload = {}, options = {}) {
  const { apiBaseUrl } = getApiConfig()
  const configuredAction = ACTION_CONFIGS[action]
  const method = options.method || configuredAction?.method || 'GET'
  const endpoint = options.endpoint || configuredAction?.endpoint || action
  const url = `${apiBaseUrl}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`
  const isFormData = typeof FormData !== 'undefined' && payload instanceof FormData

  const requestConfig = {
    method,
    mode: 'cors',
    credentials: 'include',
    headers: {
      Accept: 'application/json'
    }
  }

  if (!isFormData) {
    requestConfig.headers['Content-Type'] = 'application/json'
  }

  if (options.token) {
    requestConfig.headers.Authorization = `Bearer ${options.token}`
  }

  if (method !== 'GET' && payload !== null && payload !== undefined) {
    requestConfig.body = isFormData ? payload : JSON.stringify(payload)
  }

  const response = await fetch(url, requestConfig)

  const text = await response.text()
  let parsed = {}

  try {
    parsed = JSON.parse(text)
  } catch {
    parsed = { success: false, message: text || 'Request failed' }
  }

  if (!response.ok || parsed.success === false) {
    throw new Error(parsed.message || 'Request failed')
  }

  return parsed.data ?? parsed
}

function extractFileNameFromDisposition(contentDisposition = '') {
  const match = String(contentDisposition || '').match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i)
  const raw = match ? (match[1] || match[2] || '').trim() : ''
  if (!raw) return null

  try {
    return decodeURIComponent(raw)
  } catch {
    return raw
  }
}

export async function apiDownload(endpoint, options = {}) {
  const { apiBaseUrl } = getApiConfig()
  const url = `${apiBaseUrl}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`

  const headers = {
    Accept: '*/*'
  }

  if (options.token) {
    headers.Authorization = `Bearer ${options.token}`
  }

  const response = await fetch(url, {
    method: 'GET',
    mode: 'cors',
    credentials: 'include',
    headers
  })

  if (!response.ok) {
    let message = 'Unable to download file'
    try {
      const data = await response.json()
      message = data.message || message
    } catch {
      const text = await response.text()
      if (text) {
        message = text
      }
    }

    throw new Error(message)
  }

  const blob = await response.blob()
  const fileName = extractFileNameFromDisposition(response.headers.get('Content-Disposition'))

  return {
    blob,
    fileName
  }
}
