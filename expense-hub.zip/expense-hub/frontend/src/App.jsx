import { useEffect, useMemo, useState } from 'react'
import { apiDownload, apiRequest, isApiConfigured } from './services/api'
import AdminEmployeesPage from './components/AdminEmployeesPage'
import AdminEmployeeClaimsPage from './components/AdminEmployeeClaimsPage'
import DashboardPage from './components/DashboardPage'
import MyClaimsPage from './components/MyClaimsPage'
import NewClaimPage from './components/NewClaimPage'
import ClaimDetailsPage from './components/ClaimDetailsPage'
import ReportsPage from './components/ReportsPage'
import ProfilePage from './components/ProfilePage'
import './App.css'

const STORAGE_KEY = 'expensehub-demo-v1'
const SESSION_STORAGE_KEY = 'expensehub-session-v1'
const DEFAULT_ROUTE = '#/login'
const COMPANY_EMAIL_DOMAIN = '@axiotechx.com'

const statusLabels = {
  PENDING: 'Pending',
  ACTIVE: 'Active',
  REJECTED: 'Rejected',
  BLOCKED: 'Blocked',
  DRAFT: 'Draft',
  SUBMITTED: 'Submitted',
  UNDER_REVIEW: 'Pending Review',
  MORE_INFO_NEEDED: 'More info needed',
  APPROVED: 'Approved'
}

const claimTypes = ['Travel', 'Food', 'Stay', 'Tech', 'Office', 'Communication', 'Maintenance', 'Training', 'Client', 'Marketing', 'Professional Services', 'Others']
const departmentOptions = ['Engineering', 'Design', 'Finance', 'Operations', 'Human Resources', 'Sales', 'Marketing', 'Administration']

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase()
}

function extractEmailLocalPart(value) {
  return normalizeEmail(value).split('@')[0]
}

function toCompanyEmail(value) {
  const localPart = extractEmailLocalPart(value)
  if (!localPart) return ''
  return `${localPart}${COMPANY_EMAIL_DOMAIN}`
}

function formatCurrency(value) {
  const amount = Number(value || 0)
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(amount)
}

function formatDate(dateValue) {
  if (!dateValue) return '—'
  const date = new Date(dateValue)
  if (Number.isNaN(date.getTime())) return dateValue
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function formatDateTime(dateValue) {
  if (!dateValue) return '—'
  const date = new Date(dateValue)
  if (Number.isNaN(date.getTime())) return dateValue
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date)
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

function endOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59, 999)
}

async function hashValue(value) {
  const encoder = new TextEncoder()
  const data = encoder.encode(String(value))
  const digest = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, '0')).join('')
}

function createId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

function isStrongPassword(password) {
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,20}$/.test(String(password || ''))
}

function getHomeRouteForUser(user) {
  if (!user) return DEFAULT_ROUTE

  const normalizedRole = String(user.role || '').toUpperCase()
  if (normalizedRole === 'ADMIN' || normalizedRole === 'MANAGER') return '#/admin'
  return '#/dashboard'
}

function getRoute() {
  return window.location.hash || DEFAULT_ROUTE
}

async function buildDemoState() {
  const adminPassword = await hashValue('Admin@123')
  const rahulPassword = await hashValue('Rahul@123')
  const priyaPassword = await hashValue('Priya@123')

  const demoUsers = [
    {
      user_id: 'USR-ADMIN-001',
      first_name: 'Priya',
      last_name: 'Mehta',
      email: 'admin@expensehub.com',
      password: adminPassword,
      security_code: 'SECURE-ADMIN-1',
      role: 'ADMIN',
      status: 'ACTIVE',
      created_at: '2026-08-01T09:00:00.000Z',
      updated_at: '2026-08-01T09:00:00.000Z'
    },
    {
      user_id: 'USR-EMP-001',
      first_name: 'Rahul',
      last_name: 'Sharma',
      email: 'rahul@expensehub.com',
      password: rahulPassword,
      security_code: 'SECURE-EMP-1',
      role: 'EMPLOYEE',
      status: 'ACTIVE',
      created_at: '2026-08-10T12:35:00.000Z',
      updated_at: '2026-08-10T12:35:00.000Z'
    },
    {
      user_id: 'USR-EMP-002',
      first_name: 'Meera',
      last_name: 'Patel',
      email: 'meera@expensehub.com',
      password: priyaPassword,
      security_code: 'SECURE-EMP-2',
      role: 'EMPLOYEE',
      status: 'PENDING',
      created_at: '2026-09-14T11:00:00.000Z',
      updated_at: '2026-09-14T11:00:00.000Z'
    }
  ]

  const demoClaims = [
    {
      claim_id: 'CLM-2026-001',
      user_id: 'USR-EMP-001',
      claim_type: 'Travel',
      expense_from: '2026-09-18',
      expense_to: '2026-09-20',
      expense_amount: 4500,
      docs_count: 1,
      attachments: JSON.stringify([
        { fileId: 'DOC-1', name: 'train-ticket.pdf', mimeType: 'application/pdf', size: 520000, uploadedAt: '2026-09-20T11:21:00.000Z' }
      ]),
      doc_required: true,
      status: 'APPROVED',
      remarks: '',
      approved_by: 'USR-ADMIN-001',
      created_at: '2026-09-20T10:30:00.000Z',
      updated_at: '2026-09-21T12:05:00.000Z'
    },
    {
      claim_id: 'CLM-2026-002',
      user_id: 'USR-EMP-001',
      claim_type: 'Food',
      expense_from: '2026-09-12',
      expense_to: '2026-09-12',
      expense_amount: 1200,
      docs_count: 1,
      attachments: JSON.stringify([
        { fileId: 'DOC-2', name: 'restaurant-bill.jpg', mimeType: 'image/jpeg', size: 680000, uploadedAt: '2026-09-12T18:16:00.000Z' }
      ]),
      doc_required: true,
      status: 'UNDER_REVIEW',
      remarks: '',
      approved_by: '',
      created_at: '2026-09-12T18:30:00.000Z',
      updated_at: '2026-09-13T08:10:00.000Z'
    },
    {
      claim_id: 'CLM-2026-003',
      user_id: 'USR-EMP-001',
      claim_type: 'Accommodation',
      expense_from: '2026-09-05',
      expense_to: '2026-09-06',
      expense_amount: 3800,
      docs_count: 1,
      attachments: JSON.stringify([
        { fileId: 'DOC-3', name: 'hotel-invoice.png', mimeType: 'image/png', size: 990000, uploadedAt: '2026-09-06T09:15:00.000Z' }
      ]),
      doc_required: true,
      status: 'REJECTED',
      remarks: 'Receipt is unclear and does not show hotel name. Please submit a clear invoice.',
      approved_by: '',
      created_at: '2026-09-05T08:45:00.000Z',
      updated_at: '2026-09-06T17:25:00.000Z'
    }
  ]

  return { users: demoUsers, claims: demoClaims }
}

function getSafeUser(user) {
  if (!user) return null

  const resolvedStatus = String(
    user.status || user.account_status || (user.registration_status === 'PENDING' ? 'PENDING' : 'INACTIVE')
  ).toUpperCase()

  return {
    user_id: user.user_id || user.employee_id || user.id,
    first_name: user.first_name,
    last_name: user.last_name,
    email: user.email,
    role: user.role,
    status: resolvedStatus,
    account_status: user.account_status,
    registration_status: user.registration_status,
    mobile_number: user.mobile_number,
    manager_id: user.manager_id,
    department: user.department,
    designation: user.designation,
    created_at: user.created_at,
    updated_at: user.updated_at
  }
}

function toApiExpenseType(value) {
  return String(value || '').trim().replace(/\s+/g, '_').toUpperCase()
}

function fromApiExpenseType(value) {
  const safe = String(value || '').trim().toLowerCase()
  if (!safe) return 'Others'

  return safe
    .split('_')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ')
}

function toInputDateValue(value) {
  if (!value) return ''
  const date = new Date(value)
  if (!Number.isNaN(date.getTime())) {
    return date.toISOString().slice(0, 10)
  }

  const safe = String(value)
  if (/^\d{4}-\d{2}-\d{2}/.test(safe)) {
    return safe.slice(0, 10)
  }

  return ''
}

function mapApiExpenseToClaim(expense = {}) {
  const documents = Array.isArray(expense.documents)
    ? expense.documents.map((doc, index) => ({
      fileId: doc.fileId || doc.file_id || `DOC-${expense.expense_id || 'X'}-${index + 1}`,
      name: doc.name || doc.file_name || doc.stored_name || 'proof',
      mimeType: doc.mimeType || doc.mime_type || 'application/octet-stream',
      size: Number(doc.size || 0),
      uploadedAt: doc.uploadedAt || doc.uploaded_at || expense.updated_at || expense.created_at || new Date().toISOString(),
      s3Key: doc.s3_key || '',
      s3Bucket: doc.s3_bucket || ''
    }))
    : []

  return {
    claim_id: expense.expense_id || expense.claim_id || createId('CLM'),
    user_id: expense.employee_id || expense.user_id || '',
    employee_email: expense.employee_email || expense.email || '',
    employee_first_name: expense.first_name || expense.employee_first_name || '',
    employee_last_name: expense.last_name || expense.employee_last_name || '',
    department: expense.department || expense.employee_department || '',
    claim_title: expense.expense_title || expense.claim_title || '',
    claim_description: expense.expense_description || expense.claim_description || '',
    claim_type: fromApiExpenseType(expense.expense_type || expense.claim_type || 'OTHERS'),
    expense_date: expense.expense_date || expense.expenseDate || expense.expense_from || expense.created_at,
    expense_from: expense.expense_from || expense.expense_date || expense.created_at,
    expense_to: expense.expense_to || expense.expense_date || expense.created_at,
    expense_amount: Number(expense.amount || expense.expense_amount || 0),
    docs_count: Number(expense.document_count || expense.docs_count || documents.length || 0),
    attachments: JSON.stringify(documents),
    doc_required: true,
    status: expense.status || 'DRAFT',
    payment_mode: expense.payment_mode || 'CARD',
    currency: expense.currency || 'INR',
    location: expense.location || '',
    remarks: expense.employee_remarks || expense.remarks || '',
    reviewer_remarks: expense.admin_comments || '',
    approved_by: expense.reviewed_by || expense.approved_by || '',
    created_at: expense.created_at || new Date().toISOString(),
    updated_at: expense.updated_at || new Date().toISOString(),
    vendor_name: expense.vendor_name || '',
    vendor: expense.vendor_name || ''
  }
}

function getUserIdentity(value = {}) {
  return value.user_id || value.employee_id || value.id || ''
}

function getClaimOwnerIdentity(claim = {}) {
  return claim.user_id || claim.employee_id || ''
}

function doesClaimBelongToUser(claim = {}, user = null) {
  if (!user) return false

  const claimOwnerId = String(getClaimOwnerIdentity(claim) || '').trim()
  const userId = String(getUserIdentity(user) || '').trim()
  if (claimOwnerId && userId && claimOwnerId === userId) {
    return true
  }

  const claimEmail = normalizeEmail(claim.employee_email || claim.email)
  const userEmail = normalizeEmail(user.email)
  if (claimEmail && userEmail && claimEmail === userEmail) {
    return true
  }

  return false
}

function toApiExpensePayload(payload = {}) {
  const expenseDate = payload.expenseDate || payload.expenseFrom || payload.expenseTo
  const rawAttachments = Array.isArray(payload.attachments) ? payload.attachments : []

  return {
    expense_type: toApiExpenseType(payload.claimType),
    expense_title: String(payload.title || payload.claimType || 'Expense Claim').trim(),
    expense_description: String(payload.description || payload.remarks || 'Expense claim').trim(),
    expense_date: expenseDate,
    expense_from: payload.expenseFrom || expenseDate,
    expense_to: payload.expenseTo || payload.expenseFrom || expenseDate,
    amount: Number(payload.amount || 0),
    currency: payload.currency || 'INR',
    payment_mode: payload.paymentMode || 'CARD',
    vendor_name: payload.vendor || null,
    location: payload.location || null,
    employee_remarks: payload.remarks || null,
    status: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
    documents: rawAttachments.map((file) => ({
      file_name: file.name,
      mime_type: file.mimeType,
      size: Number(file.size || 0),
      uploaded_at: file.uploadedAt || new Date().toISOString()
    }))
  }
}

function buildExpenseFormData(payload = {}) {
  const formData = new FormData()
  const rawAttachments = Array.isArray(payload.attachments) ? payload.attachments : []
  const expenseDate = payload.expenseDate || payload.expenseFrom || payload.expenseTo

  const fieldMap = {
    expense_type: toApiExpenseType(payload.claimType),
    expense_title: String(payload.title || payload.claimType || 'Expense Claim').trim(),
    expense_description: String(payload.description || payload.remarks || 'Expense claim').trim(),
    expense_date: expenseDate,
    expense_from: payload.expenseFrom || expenseDate,
    expense_to: payload.expenseTo || payload.expenseFrom || expenseDate,
    amount: Number(payload.amount || 0),
    currency: payload.currency || 'INR',
    payment_mode: payload.paymentMode || 'CARD',
    vendor_name: payload.vendor || '',
    location: payload.location || '',
    employee_remarks: payload.remarks || '',
    status: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED'
  }

  Object.entries(fieldMap).forEach(([key, value]) => {
    if (value === null || value === undefined || value === '') return
    formData.append(key, String(value))
  })

  rawAttachments.forEach((attachment) => {
    const file = attachment?.file instanceof File ? attachment.file : attachment instanceof File ? attachment : null
    if (file) {
      formData.append('proofs', file)
    }
  })

  return formData
}

function App() {
  const [appState, setAppState] = useState({ users: [], claims: [] })
  const [session, setSession] = useState(() => {
    try {
      const savedSession = window.localStorage.getItem(SESSION_STORAGE_KEY)
      if (!savedSession) return null
      const parsed = JSON.parse(savedSession)
      if (!parsed?.user) return null
      return parsed
    } catch {
      return null
    }
  })
  const [route, setRoute] = useState(getRoute())
  const [flash, setFlash] = useState('')
  const [selectedClaimId, setSelectedClaimId] = useState(null)
  const [claimDraft, setClaimDraft] = useState(null)
  const [adminEmployeeFilter, setAdminEmployeeFilter] = useState('PENDING')
  const [selectedAdminEmployeeId, setSelectedAdminEmployeeId] = useState('')
  const [adminRejectReason, setAdminRejectReason] = useState('')
  const [adminRejectError, setAdminRejectError] = useState('')
  const [adminReviewFilter, setAdminReviewFilter] = useState('ALL')
  const [adminReviewComment, setAdminReviewComment] = useState('')
  const [adminReviewError, setAdminReviewError] = useState('')
  const [adminUsersRemote, setAdminUsersRemote] = useState([])
  const [adminUsersLoaded, setAdminUsersLoaded] = useState(false)
  const [adminDatePreset, setAdminDatePreset] = useState('LAST_30_DAYS')
  const [adminCustomFrom, setAdminCustomFrom] = useState('')
  const [adminCustomTo, setAdminCustomTo] = useState('')
  const [adminAppliedCustomRange, setAdminAppliedCustomRange] = useState({ from: '', to: '' })
  const [isAdminCustomDateOpen, setIsAdminCustomDateOpen] = useState(false)
  const [isProfileEditing, setIsProfileEditing] = useState(false)
  const [profileDraft, setProfileDraft] = useState({ first_name: '', last_name: '', mobile_number: '', manager_id: '', department: '', designation: '' })
  const [managerDirectory, setManagerDirectory] = useState([])
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false)

  const loadEmployeeClaimsFromApi = async (token) => {
    if (!token || !isApiConfigured()) return

    const expenses = await apiRequest('/expenses/mine', {}, { token, endpoint: '/expenses/mine', method: 'GET' })
    const mappedClaims = Array.isArray(expenses) ? expenses.map(mapApiExpenseToClaim) : []
    setAppState((prev) => ({ ...prev, claims: mappedClaims }))
  }

  const loadAdminClaimsFromApi = async (token) => {
    if (!token || !isApiConfigured()) return

    const expenses = await apiRequest('/expenses/admin/list', {}, { token, endpoint: '/expenses/admin/list', method: 'GET' })
    const mappedClaims = Array.isArray(expenses) ? expenses.map(mapApiExpenseToClaim) : []
    setAppState((prev) => ({ ...prev, claims: mappedClaims }))
  }

  useEffect(() => {
    const onRouteChange = () => setRoute(getRoute())
    window.addEventListener('hashchange', onRouteChange)
    return () => window.removeEventListener('hashchange', onRouteChange)
  }, [])

  useEffect(() => {
    const bootstrap = async () => {
      try {
        if (isApiConfigured()) {
          const data = await apiRequest('bootstrap')
          if (data?.users || data?.claims) {
            const normalizedUsers = Array.isArray(data.users) ? data.users.map((item) => ({ ...item, user_id: getUserIdentity(item) })) : []
            const normalizedClaims = Array.isArray(data.claims)
              ? data.claims.map((claim) => (claim?.expense_id || claim?.employee_id ? mapApiExpenseToClaim(claim) : claim))
              : []

            setAppState({ users: normalizedUsers, claims: normalizedClaims })
            return
          }

          // In API mode, avoid falling back to demo/local datasets.
          setAppState((prev) => (prev.users.length || prev.claims.length ? prev : { users: [], claims: [] }))
          return
        }

        const saved = window.localStorage.getItem(STORAGE_KEY)
        if (saved) {
          const parsed = JSON.parse(saved)
          setAppState({ users: parsed.users || [], claims: parsed.claims || [] })
          return
        }

        const seeded = await buildDemoState()
        setAppState(seeded)
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded))
      } catch (error) {
        console.error('Could not initialize app data', error)

        if (isApiConfigured()) {
          setAppState((prev) => (prev.users.length || prev.claims.length ? prev : { users: [], claims: [] }))
        }
      }
    }

    bootstrap()
  }, [])

  useEffect(() => {
    if (!appState.users.length) return
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(appState))
  }, [appState])

  useEffect(() => {
    if (!session) {
      window.localStorage.removeItem(SESSION_STORAGE_KEY)
      return
    }

    window.localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session))
  }, [session])

  useEffect(() => {
    if (!session?.user) return
    setProfileDraft({
      first_name: session.user.first_name || '',
      last_name: session.user.last_name || '',
      mobile_number: session.user.mobile_number || '',
      manager_id: session.user.manager_id || '',
      department: session.user.department || '',
      designation: session.user.designation || ''
    })
  }, [session])

  useEffect(() => {
    let isCancelled = false

    const loadManagers = async () => {
      if (isApiConfigured()) {
        try {
          const response = await apiRequest('getManagers')
          if (!isCancelled) {
            setManagerDirectory(Array.isArray(response) ? response : [])
          }
          return
        } catch {
          // Fallback to local users when API manager list is unavailable.
        }
      }

      const fallbackManagers = appState.users
        .filter((item) => ['MANAGER', 'ADMIN'].includes(String(item.role || '').toUpperCase()))
        .map((item) => ({
          employee_id: getUserIdentity(item),
          first_name: item.first_name,
          last_name: item.last_name,
          email: item.email,
          designation: item.designation,
          role: item.role
        }))

      if (!isCancelled) {
        setManagerDirectory(fallbackManagers)
      }
    }

    loadManagers()
    return () => {
      isCancelled = true
    }
  }, [appState.users])

  useEffect(() => {
    if (!session?.user || !appState.users.length) return

    const userId = getUserIdentity(session.user)
    const matchingUser = appState.users.find((item) => {
      const itemId = getUserIdentity(item)
      if (itemId && userId && itemId === userId) return true
      return String(item.email || '').toLowerCase() === String(session.user.email || '').toLowerCase()
    })

    if (!matchingUser) return

    const enrichedUser = {
      ...session.user,
      user_id: userId || getUserIdentity(matchingUser),
      first_name: session.user.first_name || matchingUser.first_name || '',
      last_name: session.user.last_name || matchingUser.last_name || '',
      mobile_number: session.user.mobile_number || matchingUser.mobile_number || '',
      manager_id: session.user.manager_id || matchingUser.manager_id || '',
      department: session.user.department || matchingUser.department || '',
      designation: session.user.designation || matchingUser.designation || ''
    }

    const shouldUpdateSession =
      enrichedUser.user_id !== session.user.user_id ||
      enrichedUser.first_name !== session.user.first_name ||
      enrichedUser.last_name !== session.user.last_name ||
      enrichedUser.mobile_number !== session.user.mobile_number ||
      enrichedUser.manager_id !== session.user.manager_id ||
      enrichedUser.department !== session.user.department ||
      enrichedUser.designation !== session.user.designation

    if (shouldUpdateSession) {
      setSession((prev) => ({ ...(prev || {}), user: enrichedUser }))
    }

    setProfileDraft((prev) => ({
      ...prev,
      first_name: prev.first_name || enrichedUser.first_name,
      last_name: prev.last_name || enrichedUser.last_name,
      mobile_number: prev.mobile_number || enrichedUser.mobile_number,
      manager_id: prev.manager_id || enrichedUser.manager_id,
      department: prev.department || enrichedUser.department,
      designation: prev.designation || enrichedUser.designation
    }))
  }, [appState.users, session])

  useEffect(() => {
    if (!session) return

    const safeStatus = String(session.user.status || '').toUpperCase()
    const normalizedRole = String(session.user.role || '').toUpperCase()
    const safeRoute = route || '#/login'
    const homeRoute = getHomeRouteForUser(session.user)
    const authRoutes = ['#/login', '#/register', '#/review']

    if (safeStatus === 'PENDING' && route !== '#/review') {
      window.location.hash = '#/review'
      setRoute('#/review')
      return
    }

    if (safeStatus !== 'ACTIVE' && route !== '#/review' && route !== '#/login' && route !== '#/register') {
      window.location.hash = '#/review'
      setRoute('#/review')
      return
    }

    if (safeRoute === '#/' || safeRoute === '' || authRoutes.includes(safeRoute)) {
      window.location.hash = homeRoute
      setRoute(homeRoute)
      return
    }

    if (normalizedRole === 'EMPLOYEE' && route.startsWith('#/admin')) {
      window.location.hash = '#/dashboard'
      setRoute('#/dashboard')
      return
    }

    if ((normalizedRole === 'ADMIN' || normalizedRole === 'MANAGER') && route.startsWith('#/dashboard')) {
      window.location.hash = '#/admin'
      setRoute('#/admin')
    }
  }, [session, route])

  useEffect(() => {
    if (!session && route !== '#/login' && route !== '#/register') {
      window.location.hash = '#/login'
      setRoute('#/login')
    }
  }, [session, route])

  const user = session?.user || null
  const profileManagerOptions = useMemo(() => {
    if (managerDirectory.length) {
      return managerDirectory
    }

    return appState.users
      .filter((item) => ['MANAGER', 'ADMIN'].includes(String(item.role || '').toUpperCase()))
      .map((item) => ({
        employee_id: getUserIdentity(item),
        first_name: item.first_name,
        last_name: item.last_name,
        email: item.email,
        designation: item.designation,
        role: item.role
      }))
  }, [appState.users, managerDirectory])

  const currentClaim = useMemo(() => {
    if (!selectedClaimId) return null
    return appState.claims.find((claim) => claim.claim_id === selectedClaimId) || null
  }, [appState.claims, selectedClaimId])

  const visibleClaims = useMemo(() => {
    if (!user) return []
    const normalizedRole = String(user.role || '').toUpperCase()
    if (normalizedRole === 'ADMIN') return [...appState.claims].sort((a, b) => new Date(b.created_at) - new Date(a.created_at))

    return appState.claims
      .filter((claim) => doesClaimBelongToUser(claim, user))
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  }, [appState.claims, user])

  const adminDashboardClaims = useMemo(() => {
    if (!appState.claims.length) return []

    const now = new Date()
    const todayStart = startOfDay(now)
    const todayEnd = endOfDay(now)
    const last7Start = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6))
    const last30Start = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29))

    return appState.claims.filter((claim) => {
      const claimDate = new Date(claim.created_at)
      if (Number.isNaN(claimDate.getTime())) return false

      if (adminDatePreset === 'TODAY') {
        return claimDate >= todayStart && claimDate <= todayEnd
      }

      if (adminDatePreset === 'LAST_7_DAYS') {
        return claimDate >= last7Start && claimDate <= todayEnd
      }

      if (adminDatePreset === 'LAST_30_DAYS') {
        return claimDate >= last30Start && claimDate <= todayEnd
      }

      if (adminDatePreset === 'CUSTOM') {
        const from = adminAppliedCustomRange.from ? startOfDay(new Date(adminAppliedCustomRange.from)) : null
        const to = adminAppliedCustomRange.to ? endOfDay(new Date(adminAppliedCustomRange.to)) : null

        if (!from || !to || Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
          return true
        }

        return claimDate >= from && claimDate <= to
      }

      return true
    })
  }, [adminAppliedCustomRange.from, adminAppliedCustomRange.to, adminDatePreset, appState.claims])

  const myClaims = useMemo(() => {
    if (!user || String(user.role || '').toUpperCase() !== 'EMPLOYEE') return []
    return visibleClaims
  }, [visibleClaims, user])

  const adminReviewCounts = useMemo(() => {
    const reviewClaims = visibleClaims.filter((claim) => ['SUBMITTED', 'UNDER_REVIEW', 'MORE_INFO_NEEDED', 'REJECTED'].includes(claim.status))
    const submitted = reviewClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW').length
    const moreInfo = reviewClaims.filter((claim) => claim.status === 'MORE_INFO_NEEDED').length
    const rejected = reviewClaims.filter((claim) => claim.status === 'REJECTED').length

    return {
      all: reviewClaims.length,
      submitted,
      moreInfo,
      rejected
    }
  }, [visibleClaims])

  const adminUsers = useMemo(() => [...appState.users].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)), [appState.users])
  const effectiveAdminUsers = useMemo(() => {
    if (isApiConfigured() && session?.user?.role === 'ADMIN' && adminUsersLoaded) {
      return adminUsersRemote
    }

    return adminUsers
  }, [adminUsers, adminUsersLoaded, adminUsersRemote, session])

  const fetchAdminUsers = async (token) => {
    if (!isApiConfigured() || !token) {
      setAdminUsersLoaded(false)
      setAdminUsersRemote([])
      return
    }

    try {
      const users = await apiRequest('getAdminUsers', {}, { token })
      setAdminUsersRemote(Array.isArray(users) ? users : [])
      setAdminUsersLoaded(true)
    } catch (error) {
      setAdminUsersLoaded(false)
      setAdminUsersRemote([])
      setFlash(error.message || 'Unable to load employee registrations from server.')
    }
  }

  const navigate = (nextRoute) => {
    window.location.hash = nextRoute
    setRoute(nextRoute)
  }

  const persistState = (nextState) => {
    setAppState(nextState)
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextState))
  }

  useEffect(() => {
    if (session?.user?.role === 'ADMIN' && session?.token) {
      fetchAdminUsers(session.token)
      return
    }

    setAdminUsersLoaded(false)
    setAdminUsersRemote([])
  }, [session])

  useEffect(() => {
    const syncClaimsFromApi = async () => {
      if (!session?.token || !isApiConfigured()) return

      const userRole = String(session.user?.role || '').toUpperCase()
      const claimsRoutes = new Set([
        '#/dashboard',
        '#/my-claims',
        '#/new-claim',
        '#/claim-details',
        '#/admin',
        '#/admin/claims',
        '#/admin/employee-claims',
        '#/admin/users',
        '#/admin/reports'
      ])

      if (!claimsRoutes.has(route)) return

      try {
        if (userRole === 'EMPLOYEE') {
          await loadEmployeeClaimsFromApi(session.token)
        } else if (userRole === 'ADMIN' || userRole === 'MANAGER') {
          await loadAdminClaimsFromApi(session.token)
        }
      } catch {
        // Keep existing local state as fallback when server claims cannot be loaded.
      }
    }

    syncClaimsFromApi()
  }, [route, session?.token, session?.user?.role])

  useEffect(() => {
    const normalizedRole = String(session?.user?.role || '').toUpperCase()
    if (normalizedRole !== 'ADMIN' && normalizedRole !== 'MANAGER') {
      return
    }

    if (route !== '#/admin/claims') {
      return
    }

    const selectedClaim = appState.claims.find((claim) => claim.claim_id === selectedClaimId)
    if (!selectedClaim) {
      setAdminReviewComment('')
      setAdminReviewError('')
      return
    }

    const existingComment = String(selectedClaim.reviewer_remarks || selectedClaim.remarks || '').trim()
    setAdminReviewComment(existingComment)
    setAdminReviewError('')
  }, [appState.claims, route, selectedClaimId, session?.user?.role])

  const handleLogin = async (formValues) => {
    const localPart = extractEmailLocalPart(formValues.email)
    const email = toCompanyEmail(formValues.email)

    if (isApiConfigured()) {
      try {
        const result = await apiRequest('login', {
          email,
          password: formValues.password
        })

        const serverUser = result?.user
        if (!serverUser) {
          return { success: false, message: 'Invalid email or password.' }
        }

        const userSession = getSafeUser(serverUser)
        const sessionToken = result?.token || ''
        setSession({ user: userSession, token: sessionToken })
        setFlash(result.message || 'Login successful.')

        if (userSession.status === 'PENDING') {
          navigate('#/review')
          return { success: true, message: result.message }
        }

        const normalizedRole = String(userSession.role || '').toUpperCase()
        if (normalizedRole === 'EMPLOYEE') {
          await loadEmployeeClaimsFromApi(sessionToken)
        } else if (normalizedRole === 'ADMIN' || normalizedRole === 'MANAGER') {
          await loadAdminClaimsFromApi(sessionToken)
          setAdminDatePreset('LAST_30_DAYS')
        }

        const nextRoute = userSession.role === 'ADMIN' ? '#/admin' : '#/dashboard'
        navigate(nextRoute)
        return { success: true, message: result.message }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to sign in right now.' }
      }
    }

    const passwordHash = await hashValue(formValues.password)

    const foundUser = appState.users.find((item) => extractEmailLocalPart(item.email) === localPart)
    if (!foundUser || foundUser.password !== passwordHash) {
      return { success: false, message: 'Invalid email or password.' }
    }

    if (foundUser.status === 'PENDING') {
      setSession({ user: getSafeUser(foundUser), token: '' })
      setFlash('Your registration request is currently under review.')
      navigate('#/review')
      return { success: true, message: 'Your account is pending approval.' }
    }

    if (foundUser.status === 'REJECTED') {
      setSession({ user: getSafeUser(foundUser), token: '' })
      setFlash('Your registration request has been rejected. Please contact the administrator.')
      navigate('#/review')
      return { success: true, message: 'Your account was rejected.' }
    }

    if (foundUser.status === 'BLOCKED') {
      setSession({ user: getSafeUser(foundUser), token: '' })
      setFlash('Your account has been blocked. Please contact the administrator.')
      navigate('#/review')
      return { success: true, message: 'Your account is blocked.' }
    }

    setSession({ user: getSafeUser(foundUser), token: '' })
    setFlash('Signed in successfully.')
    const nextRoute = foundUser.role === 'ADMIN' ? '#/admin' : '#/dashboard'
    navigate(nextRoute)
    return { success: true, message: 'Login successful.' }
  }

  const handleRegister = async (formValues) => {
    const role = String(formValues.role || 'EMPLOYEE').toUpperCase()
    const firstName = String(formValues.firstName || '').trim()
    const lastName = String(formValues.lastName || '').trim()
    const email = toCompanyEmail(formValues.email)
    const password = String(formValues.password || '')
    const confirmPassword = String(formValues.confirmPassword || '')

    if (!firstName || !lastName || !email || !password || !confirmPassword) {
      return { success: false, message: 'All fields are required.' }
    }

    if (!email || !email.endsWith(COMPANY_EMAIL_DOMAIN)) {
      return { success: false, message: 'Use your official AxiotechX email address.' }
    }

    if (!['EMPLOYEE', 'MANAGER'].includes(role)) {
      return { success: false, message: 'Role must be EMPLOYEE or MANAGER.' }
    }

    if (role === 'EMPLOYEE' && !formValues.managerId) {
      return { success: false, message: 'A reporting manager is required for employee registration.' }
    }

    if (!isStrongPassword(password)) {
      return { success: false, message: 'Password must be 8-20 characters with at least one uppercase, lowercase, number, and special character.' }
    }

    if (password !== confirmPassword) {
      return { success: false, message: 'Passwords do not match.' }
    }

    if (isApiConfigured()) {
      try {
        const response = await apiRequest('register', {
          first_name: formValues.firstName,
          last_name: formValues.lastName,
          email,
          password: formValues.password,
          mobile_number: formValues.mobile,
          department: formValues.department,
          designation: formValues.designation,
          manager_id: role === 'EMPLOYEE' ? formValues.managerId : null,
          company: 'AxiotechX',
          role
        })

        setFlash(response.message || 'Your registration request has been submitted successfully. Your account is currently under review by the administrator.')
        navigate('#/login')
        return { success: true, message: response.message || 'Registration submitted successfully.' }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to submit your registration.' }
      }
    }

    const duplicate = appState.users.some((userItem) => normalizeEmail(userItem.email) === email)
    if (duplicate) {
      return { success: false, message: 'An account with this email already exists.' }
    }

    const hashedPassword = await hashValue(password)
    const newUser = {
      user_id: createId('USR'),
      first_name: firstName,
      last_name: lastName,
      email,
      department: formValues.department || 'Engineering',
      designation: formValues.designation || 'Employee',
      mobile_number: formValues.mobile || '',
      manager_id: role === 'EMPLOYEE' ? (formValues.managerId || '') : '',
      password: hashedPassword,
      security_code: createId('SEC'),
      role,
      status: 'PENDING',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }

    const nextState = {
      users: [newUser, ...appState.users],
      claims: appState.claims
    }
    persistState(nextState)
    setFlash('Your registration request has been submitted successfully. Your account is currently under review by the administrator.')
    navigate('#/login')
    return { success: true, message: 'Registration submitted successfully.' }
  }

  const handleForgotPasswordRequestCode = async (emailValue) => {
    const email = toCompanyEmail(emailValue)
    if (!email) {
      return { success: false, message: 'Work email is required.' }
    }

    if (isApiConfigured()) {
      try {
        const result = await apiRequest('/auth/forgot-password/request-code', { email }, { endpoint: '/auth/forgot-password/request-code', method: 'POST' })
        return { success: true, message: result.message || 'Security code sent. Please check your email inbox.' }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to send security code right now.' }
      }
    }

    const userMatch = appState.users.find((item) => normalizeEmail(item.email) === email)
    if (!userMatch) {
      return { success: false, message: 'No account found for this email.' }
    }

    const securityCode = String(Math.floor(100000 + Math.random() * 900000))
    const nextState = {
      ...appState,
      users: appState.users.map((item) => (
        (item.user_id === userMatch.user_id || item.employee_id === userMatch.employee_id)
          ? { ...item, security_code: securityCode, updated_at: new Date().toISOString() }
          : item
      ))
    }
    persistState(nextState)

    return {
      success: true,
      message: 'Security code generated for local mode. Use 6-digit code from the local dataset to continue.'
    }
  }

  const handleForgotPasswordVerifyCode = async ({ emailValue, securityCode }) => {
    const email = toCompanyEmail(emailValue)
    const code = String(securityCode || '').trim()

    if (!email || !code) {
      return { success: false, message: 'Email and security code are required.' }
    }

    if (isApiConfigured()) {
      try {
        const result = await apiRequest(
          '/auth/forgot-password/verify-code',
          { email, security_code: code },
          { endpoint: '/auth/forgot-password/verify-code', method: 'POST' }
        )
        return { success: true, message: result.message || 'Security code verified successfully.' }
      } catch (error) {
        return { success: false, message: error.message || 'Invalid security code.' }
      }
    }

    const userMatch = appState.users.find((item) => normalizeEmail(item.email) === email)
    if (!userMatch || String(userMatch.security_code || '').trim() !== code) {
      return { success: false, message: 'Invalid security code.' }
    }

    return { success: true, message: 'Security code verified successfully.' }
  }

  const handleForgotPasswordReset = async ({ emailValue, securityCode, newPassword, confirmPassword }) => {
    const email = toCompanyEmail(emailValue)
    const code = String(securityCode || '').trim()

    if (!email || !code || !newPassword || !confirmPassword) {
      return { success: false, message: 'All fields are required.' }
    }

    if (newPassword !== confirmPassword) {
      return { success: false, message: 'Passwords do not match.' }
    }

    if (!isStrongPassword(newPassword)) {
      return { success: false, message: 'Password must be 8-20 characters with uppercase, lowercase, number, and special character.' }
    }

    if (isApiConfigured()) {
      try {
        const result = await apiRequest(
          '/auth/forgot-password/reset',
          {
            email,
            security_code: code,
            new_password: newPassword,
            confirm_password: confirmPassword
          },
          { endpoint: '/auth/forgot-password/reset', method: 'POST' }
        )
        return { success: true, message: result.message || 'Password reset successful.' }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to reset password.' }
      }
    }

    const userMatch = appState.users.find((item) => normalizeEmail(item.email) === email)
    if (!userMatch || String(userMatch.security_code || '').trim() !== code) {
      return { success: false, message: 'Invalid security code.' }
    }

    const passwordHash = await hashValue(newPassword)
    const nextState = {
      ...appState,
      users: appState.users.map((item) => (
        (item.user_id === userMatch.user_id || item.employee_id === userMatch.employee_id)
          ? { ...item, password: passwordHash, security_code: null, updated_at: new Date().toISOString() }
          : item
      ))
    }
    persistState(nextState)

    return { success: true, message: 'Password reset successful. Please sign in with your new password.' }
  }

  const handleApproveUser = async (userId) => {
    if (isApiConfigured() && session?.token) {
      try {
        await apiRequest(
          '/admin/users/approve',
          { approved: true },
          { token: session.token, endpoint: `/admin/users/${userId}/approve`, method: 'PATCH' }
        )
        await fetchAdminUsers(session.token)
        setSelectedAdminEmployeeId('')
        setAdminRejectReason('')
        setAdminRejectError('')
        setFlash('User approved successfully.')
        return
      } catch (error) {
        setFlash(error.message || 'Unable to approve user.')
        return
      }
    }

    const nextState = {
      ...appState,
      users: appState.users.map((userItem) =>
        (userItem.user_id === userId || userItem.employee_id === userId)
          ? { ...userItem, status: 'ACTIVE', updated_at: new Date().toISOString() }
          : userItem
      )
    }
    persistState(nextState)
    setSelectedAdminEmployeeId('')
    setAdminRejectReason('')
    setAdminRejectError('')
    setFlash('User approved successfully.')
  }

  const handleRejectUser = (userId, reason = '') => {
    const trimmedReason = String(reason || '').trim()

    if (!trimmedReason) {
      setAdminRejectError('Enter a reason to reject this registration.')
      return { success: false, message: 'Enter a reason to reject this registration.' }
    }

    if (isApiConfigured() && session?.token) {
      return apiRequest(
        '/admin/users/reject',
        { approved: false, remark: trimmedReason },
        { token: session.token, endpoint: `/admin/users/${userId}/approve`, method: 'PATCH' }
      )
        .then(async () => {
          await fetchAdminUsers(session.token)
          setSelectedAdminEmployeeId('')
          setAdminRejectReason('')
          setAdminRejectError('')
          setFlash('User rejected successfully.')
          return { success: true, message: 'User rejected successfully.' }
        })
        .catch((error) => {
          setFlash(error.message || 'Unable to reject user.')
          return { success: false, message: error.message || 'Unable to reject user.' }
        })
    }

    const nextState = {
      ...appState,
      users: appState.users.map((userItem) =>
        (userItem.user_id === userId || userItem.employee_id === userId)
          ? { ...userItem, status: 'REJECTED', account_status: 'BLOCKED', rejection_reason: trimmedReason, updated_at: new Date().toISOString() }
          : userItem
      )
    }
    persistState(nextState)
    setSelectedAdminEmployeeId('')
    setAdminRejectReason('')
    setAdminRejectError('')
    setFlash('User rejected successfully.')
    return { success: true, message: 'User rejected successfully.' }
  }

  const handleBlockUser = (userId) => {
    const nextState = {
      ...appState,
      users: appState.users.map((userItem) =>
        userItem.user_id === userId ? { ...userItem, status: 'BLOCKED', updated_at: new Date().toISOString() } : userItem
      )
    }
    persistState(nextState)
    setFlash('User account blocked successfully.')
  }

  const handleCreateClaim = async (payload) => {
    const requiredAmount = Number(payload.amount)
    const expenseFrom = payload.expenseFrom || payload.expenseDate
    const expenseTo = payload.expenseTo || payload.expenseDate || payload.expenseFrom
    if (!payload.claimType || !expenseFrom || !expenseTo || !requiredAmount || requiredAmount <= 0) {
      return { success: false, message: 'Please complete the required claim fields with a valid positive amount.' }
    }

    if (new Date(expenseTo) < new Date(expenseFrom)) {
      return { success: false, message: 'Expense end date cannot be earlier than the start date.' }
    }

    const attachments = Array.isArray(payload.attachments) ? payload.attachments : []
    if (payload.docRequired && payload.status !== 'DRAFT' && attachments.length === 0) {
      return { success: false, message: 'At least one valid attachment is required for this claim.' }
    }

    if (attachments.some((file) => !file || !file.name || !file.mimeType || file.size <= 0)) {
      return { success: false, message: 'File metadata is invalid or incomplete.' }
    }

    if (isApiConfigured() && session?.token) {
      try {
        const formData = buildExpenseFormData(payload)
        const createdExpense = await apiRequest('/expenses', formData, { token: session.token, endpoint: '/expenses', method: 'POST' })

        const createdClaim = mapApiExpenseToClaim(createdExpense)
        await loadEmployeeClaimsFromApi(session.token)
        setSelectedClaimId(createdClaim.claim_id)
        setFlash(`Claim submitted successfully. Claim ID: ${createdClaim.claim_id}`)
        navigate('#/my-claims')
        return { success: true, message: `Claim ${createdClaim.claim_id} saved successfully.` }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to create claim right now.' }
      }
    }

    const claim = {
      claim_id: createId('CLM'),
      user_id: user.user_id,
      claim_title: String(payload.title || payload.claimType || 'Expense Claim').trim(),
      claim_description: String(payload.description || '').trim(),
      claim_type: payload.claimType,
      expense_date: payload.expenseDate || expenseFrom,
      expense_from: expenseFrom,
      expense_to: expenseTo,
      expense_amount: Number(requiredAmount.toFixed(2)),
      payment_mode: payload.paymentMode || 'CARD',
      currency: payload.currency || 'INR',
      vendor_name: payload.vendor || '',
      location: payload.location || '',
      docs_count: attachments.length,
      attachments: JSON.stringify(attachments),
      doc_required: Boolean(payload.docRequired),
      status: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
      remarks: payload.remarks || '',
      approved_by: '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }

    const sanitizedAttachments = attachments.map(({ file, ...rest }) => rest)
    const nextState = {
      users: appState.users,
      claims: [claim, ...appState.claims]
    }
    nextState.claims = [
      {
        ...claim,
        attachments: JSON.stringify(sanitizedAttachments)
      },
      ...appState.claims
    ]
    persistState(nextState)
    setSelectedClaimId(claim.claim_id)
    setFlash(`Claim submitted successfully. Claim ID: ${claim.claim_id}`)
    navigate('#/my-claims')
    return { success: true, message: `Claim ${claim.claim_id} saved successfully.` }
  }

  const handleUpdateClaim = async (payload) => {
    const claimToUpdate = appState.claims.find((claim) => claim.claim_id === payload.claimId)
    if (!claimToUpdate) return { success: false, message: 'Claim was not found.' }

    if (claimToUpdate.status === 'APPROVED') {
      return { success: false, message: 'Approved claims are read-only and cannot be updated.' }
    }

    if (isApiConfigured() && session?.token) {
      try {
        const formData = buildExpenseFormData(payload)
        const updatedExpense = await apiRequest(
          `/expenses/${payload.claimId}`,
          formData,
          { token: session.token, endpoint: `/expenses/${payload.claimId}`, method: 'PATCH' }
        )

        await loadEmployeeClaimsFromApi(session.token)
        setFlash('Claim updated successfully.')
        navigate('#/my-claims')
        return { success: true, message: 'Claim updated successfully.' }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to update claim right now.' }
      }
    }

    const attachments = Array.isArray(payload.attachments) ? payload.attachments : []
    if (payload.docRequired && payload.status !== 'DRAFT' && attachments.length === 0) {
      return { success: false, message: 'At least one attachment is required before resubmitting this claim.' }
    }

    const sanitizedAttachments = attachments.map(({ file, ...rest }) => rest)
    const nextState = {
      users: appState.users,
      claims: appState.claims.map((claim) =>
        claim.claim_id === payload.claimId
          ? {
              ...claim,
              claim_title: String(payload.title || payload.claimType || 'Expense Claim').trim(),
              claim_description: String(payload.description || '').trim(),
              claim_type: payload.claimType,
              expense_date: payload.expenseDate || payload.expenseFrom,
              expense_from: payload.expenseFrom,
              expense_to: payload.expenseTo,
              expense_amount: Number(payload.amount),
              payment_mode: payload.paymentMode || claim.payment_mode || 'CARD',
              currency: payload.currency || claim.currency || 'INR',
              vendor_name: payload.vendor || claim.vendor_name || '',
              location: payload.location || claim.location || '',
              docs_count: attachments.length,
              attachments: JSON.stringify(sanitizedAttachments),
              doc_required: Boolean(payload.docRequired),
              status: payload.status === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
              remarks: payload.remarks || '',
              approved_by: '',
              updated_at: new Date().toISOString()
            }
          : claim
      )
    }
    persistState(nextState)
    setFlash('Claim resubmitted successfully.')
    navigate('#/my-claims')
    return { success: true, message: 'Claim resubmitted successfully.' }
  }

  const triggerBrowserDownload = (blob, fileName = 'download.bin') => {
    const objectUrl = window.URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = objectUrl
    anchor.download = fileName
    document.body.appendChild(anchor)
    anchor.click()
    anchor.remove()
    window.URL.revokeObjectURL(objectUrl)
  }

  const handleDownloadAttachment = async (claim, file, fileIndex) => {
    if (!claim?.claim_id || !session?.token) {
      setFlash('Unable to download the document. Please sign in again.')
      return
    }

    try {
      const endpoint = `/expenses/${claim.claim_id}/documents/${fileIndex}`
      const { blob, fileName } = await apiDownload(endpoint, { token: session.token })
      triggerBrowserDownload(blob, fileName || file?.name || `proof-${Number(fileIndex) + 1}`)
    } catch (error) {
      setFlash(error.message || 'Unable to download the selected document.')
    }
  }

  const handleDownloadAllAttachments = async (claim) => {
    if (!claim?.claim_id || !session?.token) {
      setFlash('Unable to download proofs. Please sign in again.')
      return
    }

    try {
      const endpoint = `/expenses/${claim.claim_id}/documents/download-all`
      const { blob, fileName } = await apiDownload(endpoint, { token: session.token })
      triggerBrowserDownload(blob, fileName || `${claim.claim_id}-proofs.zip`)
    } catch (error) {
      setFlash(error.message || 'Unable to download all proof documents.')
    }
  }

  const handleProfileSave = async () => {
    const firstName = String(profileDraft.first_name || '').trim()
    const lastName = String(profileDraft.last_name || '').trim()

    if (!firstName || !lastName) {
      setFlash('First name and last name are required.')
      return
    }

    try {
      if (isApiConfigured() && session?.token) {
        const updatedUserFromApi = await apiRequest(
          'updateProfile',
          {
            first_name: firstName,
            last_name: lastName,
            mobile_number: String(profileDraft.mobile_number || '').trim(),
            manager_id: String(profileDraft.manager_id || '').trim() || null,
            department: String(profileDraft.department || '').trim(),
            designation: String(profileDraft.designation || '').trim()
          },
          { token: session.token }
        )

        const safeUpdatedUser = getSafeUser(updatedUserFromApi)
        const updatedUserId = getUserIdentity(safeUpdatedUser) || session?.user?.user_id

        setSession((prev) => ({
          ...(prev || {}),
          user: {
            ...prev?.user,
            ...safeUpdatedUser,
            user_id: updatedUserId
          }
        }))

        setAppState((prev) => ({
          ...prev,
          users: prev.users.map((item) => {
            const itemId = item.user_id || item.employee_id
            if (itemId !== updatedUserId) return item
            return {
              ...item,
              ...safeUpdatedUser,
              user_id: updatedUserId,
              employee_id: item.employee_id || updatedUserId
            }
          })
        }))

        setIsProfileEditing(false)
        setFlash('Profile updated successfully.')
        return
      }

      const userId = session?.user?.user_id
      const updatedSessionUser = {
        ...session.user,
        first_name: firstName,
        last_name: lastName,
        mobile_number: String(profileDraft.mobile_number || '').trim(),
        manager_id: String(profileDraft.manager_id || '').trim(),
        department: String(profileDraft.department || '').trim(),
        designation: String(profileDraft.designation || '').trim(),
        updated_at: new Date().toISOString()
      }

      setSession((prev) => ({
        ...(prev || {}),
        user: updatedSessionUser
      }))

      setAppState((prev) => ({
        ...prev,
        users: prev.users.map((item) => {
          const itemId = item.user_id || item.employee_id
          if (itemId !== userId) return item
          return {
            ...item,
            first_name: updatedSessionUser.first_name,
            last_name: updatedSessionUser.last_name,
            mobile_number: updatedSessionUser.mobile_number,
            manager_id: updatedSessionUser.manager_id,
            department: updatedSessionUser.department,
            designation: updatedSessionUser.designation,
            updated_at: updatedSessionUser.updated_at
          }
        })
      }))

      setIsProfileEditing(false)
      setFlash('Profile updated successfully.')
    } catch (error) {
      setFlash(error.message || 'Unable to update profile right now.')
    }
  }

  const handleChangePassword = async ({ currentPassword, newPassword, confirmPassword }) => {
    const current_password = String(currentPassword || '')
    const new_password = String(newPassword || '')
    const confirm_password = String(confirmPassword || '')

    if (!current_password || !new_password || !confirm_password) {
      return { success: false, message: 'All password fields are required.' }
    }

    if (new_password !== confirm_password) {
      return { success: false, message: 'Passwords do not match.' }
    }

    if (!isStrongPassword(new_password)) {
      return { success: false, message: 'Password must be 8-20 characters with uppercase, lowercase, number, and special character.' }
    }

    if (isApiConfigured() && session?.token) {
      try {
        await apiRequest(
          'changePassword',
          { current_password, new_password, confirm_password },
          { token: session.token }
        )
        setFlash('Password changed successfully.')
        return { success: true, message: 'Password changed successfully.' }
      } catch (error) {
        return { success: false, message: error.message || 'Unable to change password right now.' }
      }
    }

    const activeUser = appState.users.find((item) => {
      const itemId = getUserIdentity(item)
      if (itemId && session?.user?.user_id && itemId === session.user.user_id) return true
      return normalizeEmail(item.email) === normalizeEmail(session?.user?.email)
    })

    if (!activeUser) {
      return { success: false, message: 'Unable to identify your account. Please sign in again.' }
    }

    const currentPasswordHash = await hashValue(current_password)
    if (String(activeUser.password || '') !== currentPasswordHash) {
      return { success: false, message: 'Current password is incorrect.' }
    }

    if (current_password === new_password) {
      return { success: false, message: 'New password must be different from current password.' }
    }

    const newPasswordHash = await hashValue(new_password)
    setAppState((prev) => ({
      ...prev,
      users: prev.users.map((item) => {
        const itemId = getUserIdentity(item)
        const activeUserId = getUserIdentity(activeUser)
        if (itemId !== activeUserId) return item
        return {
          ...item,
          password: newPasswordHash,
          updated_at: new Date().toISOString()
        }
      })
    }))

    setFlash('Password changed successfully.')
    return { success: true, message: 'Password changed successfully.' }
  }

  const handleAdminClaimDecision = async (claimId, decision, remark = '') => {
    const normalizedDecision = String(decision || '').toUpperCase()
    const trimmedRemark = String(remark || '').trim()
    const requiresRemark = ['REJECTED', 'MORE_INFO_NEEDED'].includes(normalizedDecision)

    if (requiresRemark && !trimmedRemark) {
      const message = normalizedDecision === 'REJECTED'
        ? 'Rejection remark is required.'
        : 'Comment is required to request more info.'
      setAdminReviewError(message)
      return { success: false, message }
    }

    setAdminReviewError('')

    if (isApiConfigured() && session?.token) {
      try {
        await apiRequest(
          '/expenses/admin/review',
          {
            decision: normalizedDecision,
            remark: trimmedRemark
          },
          { token: session.token, endpoint: `/expenses/admin/${claimId}/review`, method: 'PATCH' }
        )

        await loadAdminClaimsFromApi(session.token)
        setAdminReviewComment('')
        setFlash(
          normalizedDecision === 'APPROVED'
            ? 'Claim approved successfully.'
            : normalizedDecision === 'MORE_INFO_NEEDED'
              ? 'More info requested successfully.'
              : 'Claim rejected successfully.'
        )
        return { success: true }
      } catch (error) {
        const message = error.message || 'Unable to review claim right now.'
        setAdminReviewError(message)
        setFlash(message)
        return { success: false, message }
      }
    }

    const nextState = {
      users: appState.users,
      claims: appState.claims.map((claim) => {
        if (claim.claim_id !== claimId) return claim

        return {
          ...claim,
          status: normalizedDecision,
          approved_by: normalizedDecision === 'APPROVED' ? (user?.user_id || '') : '',
          remarks: trimmedRemark || claim.remarks || '',
          reviewer_remarks: trimmedRemark || '',
          updated_at: new Date().toISOString()
        }
      })
    }

    persistState(nextState)
    setAdminReviewComment('')
    setFlash(
      normalizedDecision === 'APPROVED'
        ? 'Claim approved successfully.'
        : normalizedDecision === 'MORE_INFO_NEEDED'
          ? 'More info requested successfully.'
          : 'Claim rejected successfully.'
    )

    return { success: true }
  }

  const reportMetrics = useMemo(() => {
    const filteredClaims = user && user.role === 'ADMIN' ? appState.claims : appState.claims.filter((claim) => claim.user_id === user?.user_id)
    const totalAmount = filteredClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
    const approvedCount = filteredClaims.filter((claim) => claim.status === 'APPROVED').length
    const rejectedCount = filteredClaims.filter((claim) => claim.status === 'REJECTED').length
    const underReviewCount = filteredClaims.filter((claim) => claim.status === 'UNDER_REVIEW').length

    return {
      totalClaims: filteredClaims.length,
      totalAmount,
      approvedCount,
      rejectedCount,
      underReviewCount,
      byType: claimTypes.map((type) => ({
        name: type,
        count: filteredClaims.filter((claim) => claim.claim_type === type).length,
        amount: filteredClaims.filter((claim) => claim.claim_type === type).reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
      })),
      byStatus: ['SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED'].map((status) => ({
        name: status,
        count: filteredClaims.filter((claim) => claim.status === status).length
      }))
    }
  }, [appState.claims, user])

  const handleAdminPresetSelect = (preset) => {
    if (preset === 'CUSTOM') {
      setAdminCustomFrom(adminAppliedCustomRange.from || '')
      setAdminCustomTo(adminAppliedCustomRange.to || '')
      setAdminDatePreset('CUSTOM')
      setIsAdminCustomDateOpen(true)
      return
    }

    setAdminDatePreset(preset)
    setAdminAppliedCustomRange({ from: '', to: '' })
    setAdminCustomFrom('')
    setAdminCustomTo('')
    setIsAdminCustomDateOpen(false)
  }

  const handleApplyAdminCustomRange = () => {
    if (!adminCustomFrom || !adminCustomTo) {
      setFlash('Please choose both from and to dates for custom range.')
      return
    }

    if (new Date(adminCustomFrom) > new Date(adminCustomTo)) {
      setFlash('From date cannot be later than to date.')
      return
    }

    setAdminAppliedCustomRange({ from: adminCustomFrom, to: adminCustomTo })
    setAdminDatePreset('CUSTOM')
    setIsAdminCustomDateOpen(false)
    setFlash('')
  }

  const handleLogout = () => {
    setSession(null)
    setFlash('')
    setShowLogoutConfirm(false)
    navigate('#/login')
  }

  const renderEmployeeLayout = (children) => (
    <div className="shell">
      <aside className="left-nav employee-nav">
        <div className="brand-block">
          <span className="brand-dot" />
          <strong>Expense Hub</strong>
        </div>
        <p className="nav-role">EMPLOYEE</p>
        <nav className="nav-list">
          <button className={route === '#/dashboard' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/dashboard')}>
            <span className="nav-item-icon">📊</span>
            <span>Dashboard</span>
          </button>
          <button className={route === '#/my-claims' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/my-claims')}>
            <span className="nav-item-icon">💰</span>
            <span>My Expenses</span>
          </button>
          <button className={route === '#/new-claim' ? 'nav-item active' : 'nav-item'} onClick={() => { setSelectedClaimId(null); setClaimDraft(null); navigate('#/new-claim') }}>
            <span className="nav-item-icon">➕</span>
            <span>New Expense</span>
          </button>
        </nav>
        <div className="nav-footer">
          <button className={route === '#/profile' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/profile')}>
            <span className="nav-item-icon">👤</span>
            <span>Profile</span>
          </button>
          <button className="nav-item nav-logout" onClick={() => setShowLogoutConfirm(true)}>
            <span className="nav-item-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <path d="M16 17l5-5-5-5" />
                <path d="M21 12H9" />
              </svg>
            </span>
            <span>Logout</span>
          </button>
          <div className="nav-usercard">
            <strong>{user ? `${user.first_name} ${user.last_name}` : 'Employee'}</strong>
            <span>Engineering</span>
          </div>
        </div>
      </aside>
      <main className="shell-main">{children}</main>
    </div>
  )

  const renderAdminLayout = (children) => (
    <div className="shell">
      <aside className="left-nav admin-nav">
        <div className="brand-block">
          <span className="brand-dot" />
          <strong>Expense Hub</strong>
        </div>
        <p className="nav-role">ADMIN</p>
        <nav className="nav-list admin-menu-list">
          <button className={(route === '#/admin' || route === '#/admin/reports') ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/admin')}>
            <span className="nav-item-icon">🏠</span>
            <span>Dashboard</span>
          </button>
          <button className={(route === '#/admin/users' || route === '#/admin/employees') ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/admin/employees')}>
            <span className="nav-item-icon">👥</span>
            <span>Employees</span>
          </button>
          <button className={route === '#/admin/employee-claims' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/admin/employee-claims')}>
            <span className="nav-item-icon">🧾</span>
            <span>Employee Claims</span>
          </button>
          <button className={route === '#/admin/claims' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/admin/claims')}>
            <span className="nav-item-icon">✅</span>
            <span>Expense Review</span>
          </button>
        </nav>
        <div className="nav-footer">
          <button className={route === '#/profile' ? 'nav-item active' : 'nav-item'} onClick={() => navigate('#/profile')}>
            <span className="nav-item-icon">👤</span>
            <span>Profile</span>
          </button>
          <button className="nav-item nav-logout" onClick={() => setShowLogoutConfirm(true)}>
            <span className="nav-item-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <path d="M16 17l5-5-5-5" />
                <path d="M21 12H9" />
              </svg>
            </span>
            <span>Logout</span>
          </button>
          <div className="nav-usercard">
            <strong>{user ? `${user.first_name} ${user.last_name}` : 'Admin'}</strong>
            <span>AxiotechX</span>
          </div>
        </div>
      </aside>
      <main className="shell-main">{children}</main>
    </div>
  )

  const renderAuthPage = (tab) => (
    <div className="auth-shell">
      <section className="auth-left">
        <div className="brand-block light">
          <span className="brand-dot" />
          <strong>Expense Hub</strong>
        </div>
        <h1>Submit expenses with proof. Get approved faster.</h1>
        <p>Built for AxiotechX teams. Every claim is tracked from draft to decision.</p>
        <ol>
          <li>Register with your official work email</li>
          <li>An admin confirms you are an AxiotechX employee</li>
          <li>Sign in and start claiming</li>
        </ol>
      </section>

      <section className="auth-right">
        <div className="auth-card modern">
          <div className="tab-switch">
            <button type="button" className={tab === 'login' ? 'tab-btn active' : 'tab-btn'} onClick={() => navigate('#/login')}>Sign In</button>
            <button type="button" className={tab === 'register' ? 'tab-btn active' : 'tab-btn'} onClick={() => navigate('#/register')}>Register</button>
          </div>
          {tab === 'login'
            ? <LoginForm onSubmit={handleLogin} flash={flash} onForgotPassword={() => setIsForgotPasswordOpen(true)} />
            : <RegisterForm onSubmit={handleRegister} flash={flash} />}
        </div>
      </section>
    </div>
  )

  const renderLoginPage = () => renderAuthPage('login')

  const renderRegisterPage = () => renderAuthPage('register')

  const renderReviewPage = () => (
    <div className="review-page">
      <div className="status-card">
        <div className="status-icon">!</div>
        <h1>Account Review</h1>
        <p>{session?.user ? (
          session.user.status === 'PENDING' ? 'Your registration request is currently under review.' :
          session.user.status === 'REJECTED' ? 'Your registration request has been rejected. Please contact the administrator.' :
          'Your account has been blocked. Please contact the administrator.'
        ) : 'Your account requires review.'}</p>
        <button className="btn btn-primary" onClick={() => { setSession(null); navigate('#/login') }}>Back To Login</button>
      </div>
    </div>
  )

  const renderDashboard = () => (
    renderEmployeeLayout(
      <DashboardPage
        user={user}
        myClaims={myClaims}
        formatCurrency={formatCurrency}
        formatDate={formatDate}
        statusLabels={statusLabels}
        onCreateNewClaim={() => { setSelectedClaimId(null); setClaimDraft(null); navigate('#/new-claim') }}
        onUpdateClaim={(claimId) => { setSelectedClaimId(null); setClaimDraft(claimId); navigate('#/new-claim') }}
        onOpenClaim={(claimId) => { setClaimDraft(null); setSelectedClaimId(claimId); navigate('#/claim-details') }}
      />
    )
  )

  const renderNewClaim = () => {
    const claimToEdit = claimDraft ? appState.claims.find((claim) => claim.claim_id === claimDraft) || null : null
    return renderEmployeeLayout(
      <NewClaimPage
        claimToEdit={claimToEdit}
        ClaimForm={ClaimForm}
        onSubmit={claimToEdit ? handleUpdateClaim : handleCreateClaim}
        onCancel={() => { setClaimDraft(null); setSelectedClaimId(null); navigate('#/my-claims') }}
      />
    )
  }

  const renderMyClaims = () => (
    renderEmployeeLayout(
      <MyClaimsPage
        myClaims={myClaims}
        statusLabels={statusLabels}
        formatDate={formatDate}
        formatCurrency={formatCurrency}
        onCreateNewClaim={() => { setSelectedClaimId(null); setClaimDraft(null); navigate('#/new-claim') }}
        onEditDraft={(claimId) => { setSelectedClaimId(null); setClaimDraft(claimId); navigate('#/new-claim') }}
        onViewClaim={(claimId) => { setClaimDraft(null); setSelectedClaimId(claimId); navigate('#/claim-details') }}
        MetricCard={MetricCard}
      />
    )
  )

  const renderClaimDetails = () => (
    renderEmployeeLayout(
      <ClaimDetailsPage
        currentClaim={currentClaim}
        formatDate={formatDate}
        formatDateTime={formatDateTime}
        formatCurrency={formatCurrency}
        statusLabels={statusLabels}
        backTarget={user?.role === 'ADMIN' || user?.role === 'MANAGER' ? '#/admin/employee-claims' : '#/my-claims'}
        backLabel={user?.role === 'ADMIN' || user?.role === 'MANAGER' ? 'Back to Employee Claims' : 'Back to My Claims'}
        onResubmit={(claimId) => { setSelectedClaimId(null); setClaimDraft(claimId); navigate('#/new-claim') }}
        onOpenAttachment={handleDownloadAttachment}
        onDownloadAllAttachments={handleDownloadAllAttachments}
        InfoBlock={InfoBlock}
      />
    )
  )

  const renderAdminDashboard = () => (
    renderAdminLayout(
      <section className="workspace-page">
        {(() => {
          const validClaims = adminDashboardClaims.filter((claim) => claim.status && claim.status !== 'DRAFT')
          const totalClaimCount = validClaims.length
          const approvedClaims = validClaims.filter((claim) => claim.status === 'APPROVED')
          const pendingClaims = validClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW')
          const moreInfoClaims = validClaims.filter((claim) => claim.status === 'MORE_INFO_NEEDED')
          const rejectedClaims = validClaims.filter((claim) => claim.status === 'REJECTED')
          const totalAmount = validClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
          const approvedAmount = approvedClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
          const pendingAmount = pendingClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
          const moreInfoAmount = moreInfoClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
          const rejectedAmount = rejectedClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)

          const typeBreakdown = claimTypes
            .map((type) => ({
              name: type,
              count: validClaims.filter((claim) => String(claim.claim_type || '').toLowerCase() === type.toLowerCase()).length,
              amount: validClaims
                .filter((claim) => String(claim.claim_type || '').toLowerCase() === type.toLowerCase())
                .reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
            }))
            .filter((entry) => entry.amount > 0)

          const claimStatusBreakdown = [
            { name: 'Submitted', statuses: ['SUBMITTED', 'UNDER_REVIEW'] },
            { name: 'More Info', statuses: ['MORE_INFO_NEEDED'] },
            { name: 'Approved', statuses: ['APPROVED'] },
            { name: 'Rejected', statuses: ['REJECTED'] }
          ].map((entry) => {
            const matching = validClaims.filter((claim) => entry.statuses.includes(String(claim.status || '').toUpperCase()))
            return {
              name: entry.name,
              count: matching.length,
              amount: matching.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
            }
          })

          const getDateKey = (value) => {
            const date = new Date(value || new Date())
            if (Number.isNaN(date.getTime())) return null
            return date.toISOString().slice(0, 10)
          }

          const dayBuckets = new Map()
          validClaims.forEach((claim) => {
            const claimDate = claim.created_at
            const dateKey = getDateKey(claimDate)
            if (!dateKey) return
            dayBuckets.set(dateKey, (dayBuckets.get(dateKey) || 0) + Number(claim.expense_amount || 0))
          })

          const now = new Date()
          const today = startOfDay(now)
          let rangeStart = null
          let rangeEnd = endOfDay(now)

          if (adminDatePreset === 'TODAY') {
            rangeStart = startOfDay(now)
            rangeEnd = endOfDay(now)
          } else if (adminDatePreset === 'LAST_7_DAYS') {
            rangeStart = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6))
            rangeEnd = endOfDay(now)
          } else if (adminDatePreset === 'LAST_30_DAYS') {
            rangeStart = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29))
            rangeEnd = endOfDay(now)
          } else if (adminDatePreset === 'CUSTOM' && adminAppliedCustomRange.from && adminAppliedCustomRange.to) {
            const from = startOfDay(new Date(adminAppliedCustomRange.from))
            const to = endOfDay(new Date(adminAppliedCustomRange.to))
            if (!Number.isNaN(from.getTime()) && !Number.isNaN(to.getTime()) && from <= to) {
              rangeStart = from
              rangeEnd = to
            }
          }

          const dateRangeKeys = []
          if (rangeStart) {
            const cursor = new Date(rangeStart)
            const safeRangeEnd = new Date(rangeEnd)
            while (cursor <= safeRangeEnd) {
              dateRangeKeys.push(cursor.toISOString().slice(0, 10))
              cursor.setDate(cursor.getDate() + 1)
            }
          }

          const dailySpendData = (dateRangeKeys.length
            ? dateRangeKeys
            : Array.from(dayBuckets.keys()).sort((left, right) => new Date(left) - new Date(right))
          ).map((dateKey) => ({
            date: dateKey,
            amount: Number(dayBuckets.get(dateKey) || 0)
          }))

          const departmentMap = new Map()
          const employeeSource = effectiveAdminUsers.length ? effectiveAdminUsers : appState.users

          validClaims.forEach((claim) => {
            const ownerId = getClaimOwnerIdentity(claim)
            const userMatch = employeeSource.find((item) => getUserIdentity(item) === ownerId)
            const departmentName = claim.department || userMatch?.department || 'Unassigned'
            const current = departmentMap.get(departmentName) || { claims: 0, amount: 0, approved: 0 }
            current.claims += 1
            current.amount += Number(claim.expense_amount || 0)
            if (claim.status === 'APPROVED') current.approved += 1
            departmentMap.set(departmentName, current)
          })

          const departmentRows = Array.from(departmentMap.entries())
            .map(([department, stats]) => ({
              department,
              claims: stats.claims,
              amount: stats.amount,
              approvalRate: stats.claims ? Math.round((stats.approved / stats.claims) * 100) : 0
            }))
            .sort((left, right) => right.amount - left.amount)

          return (
            <>
        <div className="workspace-head">
          <div>
            <h1>Reports</h1>
            <p>Spend across all employees.</p>
          </div>
          <div className="head-actions">
            <button className="btn btn-secondary">Export CSV</button>
            <button className="btn btn-secondary">Export PDF</button>
          </div>
        </div>

        <div className="filters-bar panel-card">
          <div className="chip-toggle">
            <button type="button" className={adminDatePreset === 'TODAY' ? 'active' : ''} onClick={() => handleAdminPresetSelect('TODAY')}>Today</button>
            <button type="button" className={adminDatePreset === 'LAST_7_DAYS' ? 'active' : ''} onClick={() => handleAdminPresetSelect('LAST_7_DAYS')}>Last 7 Days</button>
            <button type="button" className={adminDatePreset === 'LAST_30_DAYS' ? 'active' : ''} onClick={() => handleAdminPresetSelect('LAST_30_DAYS')}>Last 30 Days</button>
            <button type="button" className={adminDatePreset === 'CUSTOM' ? 'active' : ''} onClick={() => handleAdminPresetSelect('CUSTOM')}>Custom</button>
          </div>

          {adminDatePreset === 'CUSTOM' && adminAppliedCustomRange.from && adminAppliedCustomRange.to && (
            <div className="custom-range-pill">{formatDate(adminAppliedCustomRange.from)} - {formatDate(adminAppliedCustomRange.to)}</div>
          )}

          {isAdminCustomDateOpen && (
            <div className="custom-date-popover" role="dialog" aria-label="Custom report date range">
              <div className="modal-card custom-range-modal" onClick={(event) => event.stopPropagation()}>
                <h3>Select Date Range</h3>
                <div className="custom-range-fields">
                  <label>
                    <span>From</span>
                    <input type="date" value={adminCustomFrom} onChange={(event) => setAdminCustomFrom(event.target.value)} />
                  </label>
                  <label>
                    <span>To</span>
                    <input type="date" value={adminCustomTo} onChange={(event) => setAdminCustomTo(event.target.value)} />
                  </label>
                </div>
                <div className="action-row narrow-action-row">
                  <button type="button" className="btn btn-secondary" onClick={() => setIsAdminCustomDateOpen(false)}>Cancel</button>
                  <button type="button" className="btn btn-primary" onClick={handleApplyAdminCustomRange}>Apply</button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="kpi-grid five">
          <article className="kpi-card"><span>Total Claimed ({totalClaimCount})</span><strong>{formatCurrency(totalAmount)}</strong></article>
          <article className="kpi-card"><span>Approved ({approvedClaims.length})</span><strong className="ok">{formatCurrency(approvedAmount)}</strong></article>
          <article className="kpi-card"><span>Pending Review ({pendingClaims.length})</span><strong>{formatCurrency(pendingAmount)}</strong></article>
          <article className="kpi-card"><span>More Info ({moreInfoClaims.length})</span><strong>{formatCurrency(moreInfoAmount)}</strong></article>
          <article className="kpi-card"><span>Rejected ({rejectedClaims.length})</span><strong className="bad">{formatCurrency(rejectedAmount)}</strong></article>
        </div>

        <section className="report-section-block" aria-label="Daily Spends Section">
          <div className="report-section-header">Daily Spends</div>
          <div className="panel-card">
            <h3>Daily Spends</h3>
            {dailySpendData.length ? (
              <>
                <div
                  className="fake-bars wide"
                  style={{ gridTemplateColumns: `repeat(${Math.max(dailySpendData.length, 1)}, minmax(0, 1fr))` }}
                >
                  {dailySpendData.map(({ date, amount }, index) => {
                    const maxAmount = Math.max(...dailySpendData.map((entry) => entry.amount), 1)
                    return (
                      <div key={`${date}-${index}`} className="bar-wrap">
                        <span style={{ height: `${Math.max((amount / maxAmount) * 100, 10)}%` }} title={`${formatDate(date)}: ${formatCurrency(amount)}`} />
                      </div>
                    )
                  })}
                </div>
                <div
                  className="axis-row"
                  style={{ gridTemplateColumns: `repeat(${Math.max(dailySpendData.length, 1)}, minmax(0, 1fr))` }}
                >
                  {dailySpendData.map(({ date }) => {
                    const axisDate = new Date(date)
                    const day = Number.isNaN(axisDate.getTime()) ? date : axisDate.getDate()
                    const month = Number.isNaN(axisDate.getTime())
                      ? ''
                      : axisDate.toLocaleString('en-IN', { month: 'short' })
                    return <span key={date}>{`${day}, ${month}`}</span>
                  })}
                </div>
              </>
            ) : (
              <p className="empty-state">No valid claim data for this range.</p>
            )}
          </div>
        </section>

        <section className="report-section-block" aria-label="By Claim Status Section">
          <div className="report-section-header">By Claim Status</div>
          <div className="panel-card">
            <h3>By Claim Status</h3>
            {claimStatusBreakdown.some((entry) => entry.count > 0) ? claimStatusBreakdown.map((entry) => (
              <div key={entry.name} className="progress-row">
                <span>{`${entry.name} (${entry.count})`}</span>
                <div className="track"><em style={{ width: `${Math.max((entry.amount / Math.max(totalAmount, 1)) * 100, entry.amount ? 8 : 4)}%` }} /></div>
              </div>
            )) : <p className="empty-state">No claim status data available.</p>}
          </div>
        </section>

        <section className="report-section-block" aria-label="By Category Section">
          <div className="report-section-header">By Category</div>
          <div className="panel-card">
            <h3>By Category</h3>
            {typeBreakdown.length ? typeBreakdown.slice(0, 4).map((entry) => (
              <div key={entry.name} className="progress-row">
                <span>{`${entry.name} (${entry.count})`}</span>
                <div className="track"><em style={{ width: `${Math.max((entry.amount / Math.max(totalAmount, 1)) * 100, entry.amount ? 8 : 4)}%` }} /></div>
              </div>
            )) : <p className="empty-state">No category data available.</p>}
          </div>
        </section>

        <section className="report-section-block" aria-label="Department Summary Section">
          <div className="report-section-header">By Department</div>
          <div className="panel-card table-panel modern-table">
          <h3>By Department</h3>
          <table>
            <thead>
              <tr>
                <th>Department</th>
                <th>Claims</th>
                <th>Amount</th>
                <th>Approval Rate</th>
              </tr>
            </thead>
            <tbody>
              {departmentRows.length ? departmentRows.map((entry) => (
                <tr key={entry.department}>
                  <td>{entry.department}</td>
                  <td>{entry.claims}</td>
                  <td>{formatCurrency(entry.amount)}</td>
                  <td>{entry.approvalRate}%</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="4" className="empty-state">No department data available.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        </section>
            </>
          )
        })()}
      </section>
    )
  )

  const renderAdminUsers = () => (
    renderAdminLayout(
      <AdminEmployeesPage
        adminUsers={effectiveAdminUsers}
        adminEmployeeFilter={adminEmployeeFilter}
        setAdminEmployeeFilter={setAdminEmployeeFilter}
        selectedAdminEmployeeId={selectedAdminEmployeeId}
        setSelectedAdminEmployeeId={setSelectedAdminEmployeeId}
        adminRejectReason={adminRejectReason}
        setAdminRejectReason={setAdminRejectReason}
        adminRejectError={adminRejectError}
        setAdminRejectError={setAdminRejectError}
        onApproveUser={handleApproveUser}
        onRejectUser={handleRejectUser}
      />
    )
  )

  const renderAdminClaims = () => (
    renderAdminLayout(
      <section className="workspace-page">
        <div className="workspace-head">
          <div>
            <h1>Expense Review</h1>
            <p>{visibleClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW' || claim.status === 'MORE_INFO_NEEDED').length} claims waiting.</p>
          </div>
          <div className="chip-toggle compact">
            <button type="button" className={adminReviewFilter === 'ALL' ? 'active' : ''} onClick={() => setAdminReviewFilter('ALL')}>All ({adminReviewCounts.all})</button>
            <button type="button" className={adminReviewFilter === 'SUBMITTED' ? 'active' : ''} onClick={() => setAdminReviewFilter('SUBMITTED')}>Submitted ({adminReviewCounts.submitted})</button>
            <button type="button" className={adminReviewFilter === 'MORE_INFO' ? 'active' : ''} onClick={() => setAdminReviewFilter('MORE_INFO')}>More Info ({adminReviewCounts.moreInfo})</button>
            <button type="button" className={adminReviewFilter === 'REJECTED' ? 'active' : ''} onClick={() => setAdminReviewFilter('REJECTED')}>Rejected ({adminReviewCounts.rejected})</button>
          </div>
        </div>

        {(() => {
          const reviewClaims = visibleClaims.filter((claim) => ['SUBMITTED', 'UNDER_REVIEW', 'MORE_INFO_NEEDED', 'REJECTED'].includes(claim.status))
          const pendingClaims = reviewClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW')
          const moreInfoClaims = reviewClaims.filter((claim) => claim.status === 'MORE_INFO_NEEDED')
          const rejectedClaims = reviewClaims.filter((claim) => claim.status === 'REJECTED')
          const filteredClaims = adminReviewFilter === 'SUBMITTED'
            ? pendingClaims
            : adminReviewFilter === 'MORE_INFO'
              ? moreInfoClaims
              : adminReviewFilter === 'REJECTED'
                ? rejectedClaims
              : reviewClaims

          const activeClaim = filteredClaims.find((claim) => claim.claim_id === selectedClaimId) || filteredClaims[0]
          const activeEmployee = activeClaim
            ? appState.users.find((item) => getUserIdentity(item) === getClaimOwnerIdentity(activeClaim))
            : null
          const activeAttachments = activeClaim ? JSON.parse(activeClaim.attachments || '[]') : []

          return (
            <div className="review-layout">
              <div className="panel-card review-list">
                {filteredClaims.length ? filteredClaims.map((claim) => {
                  const employee = appState.users.find((item) => getUserIdentity(item) === getClaimOwnerIdentity(claim))
                  const employeeName = employee
                    ? `${employee.first_name || ''} ${employee.last_name || ''}`.trim()
                    : `${claim.employee_first_name || ''} ${claim.employee_last_name || ''}`.trim()
                  const claimStatusLabel = statusLabels[claim.status] || claim.status
                  return (
                    <button key={claim.claim_id} type="button" className={activeClaim?.claim_id === claim.claim_id ? 'review-item active' : 'review-item'} onClick={() => setSelectedClaimId(claim.claim_id)}>
                      <div className="review-item-main">
                        <strong>{employeeName || 'Unknown Employee'}</strong>
                        <span className="review-item-meta">{claim.claim_type} • {formatDate(claim.created_at)}</span>
                        <span className="review-item-subtle">Claim ID: {claim.claim_id}</span>
                      </div>
                      <div className="review-item-side">
                        <strong>{formatCurrency(claim.expense_amount)}</strong>
                        <span className="review-status-tag">{claimStatusLabel}</span>
                      </div>
                    </button>
                  )
                }) : <p className="empty-state">No claims available for this filter.</p>}
              </div>

              <div className="panel-card review-detail">
                {activeClaim ? (
                  <>
                    <div className="review-head">
                      <div>
                        <h3>{activeClaim.claim_type}</h3>
                        <p>{activeEmployee ? `${activeEmployee.first_name} ${activeEmployee.last_name}` : activeClaim.user_id} • {formatDate(activeClaim.created_at)}</p>
                      </div>
                      <strong>{formatCurrency(activeClaim.expense_amount)}</strong>
                    </div>

                    <div className="info-grid two-col">
                      <InfoBlock label="Travel dates" value={`${formatDate(activeClaim.expense_from)} - ${formatDate(activeClaim.expense_to)}`} />
                      <InfoBlock label="Payment mode" value="Card" />
                      <InfoBlock label="Vendor" value="IndiGo" />
                      <InfoBlock label="Description" value={activeClaim.remarks || 'Expense submitted for review'} />
                    </div>

                    <h4>Proof documents ({activeAttachments.length})</h4>
                    <div className="proof-tile-grid">
                      {activeAttachments.length ? activeAttachments.map((file, index) => (
                        <button
                          key={file.fileId || file.name || index}
                          type="button"
                          className="proof-tile"
                          onClick={() => handleDownloadAttachment(activeClaim, file, index)}
                        >
                          {file.name || `Proof ${index + 1}`}
                        </button>
                      )) : <p className="empty-state">No proofs attached.</p>}
                    </div>
                    {activeAttachments.length > 0 && (
                      <button type="button" className="btn btn-secondary" onClick={() => handleDownloadAllAttachments(activeClaim)}>
                        Download All Proofs
                      </button>
                    )}

                    <label>Comment to Employee</label>
                    <textarea rows="3" value={adminReviewComment} onChange={(event) => setAdminReviewComment(event.target.value)} placeholder="Add a comment to reject or request more info." />
                    {adminReviewError && <p className="helper-error">{adminReviewError}</p>}

                    <div className="action-row review-actions">
                      <button className="btn btn-primary" onClick={() => handleAdminClaimDecision(activeClaim.claim_id, 'APPROVED', adminReviewComment)}>Approve</button>
                      <button className="btn btn-secondary" onClick={() => handleAdminClaimDecision(activeClaim.claim_id, 'MORE_INFO_NEEDED', adminReviewComment)}>Request More Info</button>
                      <button className="btn btn-secondary btn-secondary-danger" onClick={() => handleAdminClaimDecision(activeClaim.claim_id, 'REJECTED', adminReviewComment)}>Reject</button>
                    </div>
                  </>
                ) : <p className="empty-state">No claim selected.</p>}
              </div>
            </div>
          )
        })()}
      </section>
    )
  )

  const renderAdminEmployeeClaims = () => (
    renderAdminLayout(
      <AdminEmployeeClaimsPage
        claims={appState.claims}
        users={effectiveAdminUsers}
        formatCurrency={formatCurrency}
        formatDate={formatDate}
        onViewClaim={(claimId) => {
          setSelectedClaimId(claimId)
          navigate('#/claim-details')
        }}
      />
    )
  )

  const renderReports = () => (
    renderEmployeeLayout(
      <ReportsPage
        user={user}
        reportMetrics={reportMetrics}
        formatCurrency={formatCurrency}
        MetricCard={MetricCard}
      />
    )
  )

  const renderProfile = () => (
    (String(user?.role || '').toUpperCase() === 'ADMIN' ? renderAdminLayout : renderEmployeeLayout)(
      <ProfilePage
        user={user}
        statusLabels={statusLabels}
        profileDraft={profileDraft}
        managerOptions={profileManagerOptions}
        departmentOptions={departmentOptions}
        isProfileEditing={isProfileEditing}
        setProfileDraft={setProfileDraft}
        onSave={handleProfileSave}
        onChangePassword={handleChangePassword}
        onStartEdit={() => setIsProfileEditing(true)}
        onCancelEdit={() => {
          setIsProfileEditing(false)
          setProfileDraft({
            first_name: user?.first_name || '',
            last_name: user?.last_name || '',
            mobile_number: user?.mobile_number || '',
            manager_id: user?.manager_id || '',
            department: user?.department || '',
            designation: user?.designation || ''
          })
        }}
      />
    )
  )

  let screen = renderLoginPage()

  if (session && session.user.status !== 'ACTIVE') {
    screen = renderReviewPage()
  } else if (session && session.user.role === 'ADMIN') {
    if (route === '#/profile') screen = renderProfile()
    else if (route === '#/admin/users' || route === '#/admin/employees') screen = renderAdminUsers()
    else if (route === '#/admin/employee-claims') screen = renderAdminEmployeeClaims()
    else if (route === '#/admin/claims') screen = renderAdminClaims()
    else if (route === '#/admin/reports') screen = renderAdminDashboard()
    else if (route === '#/admin') screen = renderAdminDashboard()
    else screen = renderAdminDashboard()
  } else if (session) {
    if (route === '#/my-claims') screen = renderMyClaims()
    else if (route === '#/new-claim') screen = renderNewClaim()
    else if (route === '#/claim-details') screen = renderClaimDetails()
    else if (route === '#/reports') screen = renderReports()
    else if (route === '#/profile') screen = renderProfile()
    else screen = renderDashboard()
  } else if (route === '#/register') {
    screen = renderRegisterPage()
  }

  return (
    <>
      {flash && <Toast message={flash} onClose={() => setFlash('')} />}
      {showLogoutConfirm && (
        <div className="modal-backdrop" onClick={() => setShowLogoutConfirm(false)}>
          <div className="modal-card confirm-modal" onClick={(event) => event.stopPropagation()}>
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to sign out?</p>
            <div className="action-row">
              <button type="button" className="btn btn-secondary" onClick={() => setShowLogoutConfirm(false)}>Cancel</button>
              <button type="button" className="btn btn-primary" onClick={handleLogout}>Logout</button>
            </div>
          </div>
        </div>
      )}
      {isForgotPasswordOpen && (
        <ForgotPasswordModal
          onClose={() => setIsForgotPasswordOpen(false)}
          onRequestCode={handleForgotPasswordRequestCode}
          onVerifyCode={handleForgotPasswordVerifyCode}
          onResetPassword={handleForgotPasswordReset}
          onComplete={(message) => {
            setIsForgotPasswordOpen(false)
            setFlash(message)
          }}
        />
      )}
      {screen}
    </>
  )
}

function LoginForm({ onSubmit, flash, onForgotPassword }) {
  const [values, setValues] = useState({ email: '', password: '' })
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const validate = () => {
    const nextErrors = {}
    const emailLocalPart = extractEmailLocalPart(values.email)

    if (!emailLocalPart) {
      nextErrors.email = 'Work email is required.'
    } else if (!/^[a-zA-Z0-9._%+-]+$/.test(emailLocalPart)) {
      nextErrors.email = 'Please enter a valid email address.'
    }

    if (!values.password) {
      nextErrors.password = 'Password is required.'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    if (!validate()) {
      return
    }

    setErrors({})
    if (!values.email || !values.password) {
      setErrors({ email: 'Email and password are required.' })
      return
    }

    setIsSubmitting(true)
    const result = await onSubmit(values)
    if (!result.success) {
      setErrors({ password: result.message || 'We could not sign you in. Please check your details.' })
    }
    setIsSubmitting(false)
  }

  return (
    <form onSubmit={handleSubmit} className="auth-form">
      <h2>Welcome back</h2>
      <p>Sign in with your work account.</p>
      {flash && <p className="flash-text">{flash}</p>}

      <div className="field-group">
        <label>Work email</label>
        <div className="email-input-wrap">
          <input
            className={errors.email ? 'input-invalid' : ''}
            type="text"
            value={values.email}
            onChange={(event) => setValues((prev) => ({ ...prev, email: extractEmailLocalPart(event.target.value) }))}
            placeholder="admin"
            autoComplete="username"
          />
          <span className="email-domain-suffix">{COMPANY_EMAIL_DOMAIN}</span>
        </div>
        {errors.email && <span className="field-error">{errors.email}</span>}
      </div>

      <div className="field-group">
        <label>Password</label>
        <div className="password-input-wrap">
          <input className={errors.password ? 'input-invalid' : ''} type={showPassword ? 'text' : 'password'} value={values.password} onChange={(event) => setValues((prev) => ({ ...prev, password: event.target.value }))} placeholder="Enter password" />
          <button type="button" className="password-toggle" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((prev) => !prev)}>
            {showPassword ? (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
                <path d="M4 4L20 20" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            )}
          </button>
        </div>
        {errors.password && <span className="field-error">{errors.password}</span>}
      </div>

      <div className="auth-form-actions login-form-actions">
        <button className="btn btn-primary" disabled={isSubmitting}>{isSubmitting ? 'Signing In...' : 'Sign In'}</button>
        <button type="button" className="btn-link" onClick={onForgotPassword}>Forgot password?</button>
      </div>
    </form>
  )
}

function ForgotPasswordModal({ onClose, onRequestCode, onVerifyCode, onResetPassword, onComplete }) {
  const [step, setStep] = useState('REQUEST')
  const [email, setEmail] = useState('')
  const [securityCode, setSecurityCode] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleRequestCode = async () => {
    setError('')
    setMessage('')
    setIsSubmitting(true)
    const result = await onRequestCode(email)
    setIsSubmitting(false)

    if (!result.success) {
      setError(result.message || 'Unable to send security code.')
      return
    }

    setMessage(result.message || 'Security code sent. Please check your email inbox.')
    setStep('VERIFY')
  }

  const handleVerifyCode = async () => {
    setError('')
    setMessage('')
    setIsSubmitting(true)
    const result = await onVerifyCode({ emailValue: email, securityCode })
    setIsSubmitting(false)

    if (!result.success) {
      setError(result.message || 'Invalid security code.')
      return
    }

    setMessage(result.message || 'Security code verified successfully.')
    setStep('RESET')
  }

  const handleResetPassword = async () => {
    setError('')
    setMessage('')
    setIsSubmitting(true)
    const result = await onResetPassword({
      emailValue: email,
      securityCode,
      newPassword,
      confirmPassword
    })
    setIsSubmitting(false)

    if (!result.success) {
      setError(result.message || 'Unable to reset password.')
      return
    }

    onComplete(result.message || 'Password reset successful. Please sign in with your new password.')
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card forgot-password-modal" onClick={(event) => event.stopPropagation()}>
        <h3>Recover your account</h3>
        <p>Enter your work email to receive a security code, then set a new password.</p>

        <div className="field-group">
          <label>Work email</label>
          <div className="email-input-wrap">
            <input
              type="text"
              value={email}
              onChange={(event) => setEmail(extractEmailLocalPart(event.target.value))}
              placeholder="admin"
              disabled={step !== 'REQUEST'}
            />
            <span className="email-domain-suffix">{COMPANY_EMAIL_DOMAIN}</span>
          </div>
        </div>

        {step !== 'REQUEST' && (
          <div className="field-group">
            <label>Security code</label>
            <input
              type="text"
              value={securityCode}
              onChange={(event) => setSecurityCode(event.target.value.replace(/\D+/g, '').slice(0, 6))}
              placeholder="Enter 6-digit code"
              maxLength={6}
              disabled={step === 'RESET'}
            />
          </div>
        )}

        {step === 'RESET' && (
          <>
            <div className="field-group">
              <label>New password</label>
              <input type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} placeholder="Enter new password" />
            </div>
            <div className="field-group">
              <label>Confirm new password</label>
              <input type="password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="Confirm new password" />
            </div>
          </>
        )}

        {message && <p className="flash-text">{message}</p>}
        {error && <span className="field-error">{error}</span>}

        <div className="action-row">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          {step === 'REQUEST' && (
            <button type="button" className="btn btn-primary" disabled={isSubmitting} onClick={handleRequestCode}>
              {isSubmitting ? 'Sending...' : 'Send Code'}
            </button>
          )}
          {step === 'VERIFY' && (
            <button type="button" className="btn btn-primary" disabled={isSubmitting} onClick={handleVerifyCode}>
              {isSubmitting ? 'Verifying...' : 'Verify Code'}
            </button>
          )}
          {step === 'RESET' && (
            <button type="button" className="btn btn-primary" disabled={isSubmitting} onClick={handleResetPassword}>
              {isSubmitting ? 'Resetting...' : 'Reset Password'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function RegisterForm({ onSubmit, flash }) {
  const [values, setValues] = useState({
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    department: 'Engineering',
    designation: '',
    managerId: '',
    role: 'EMPLOYEE',
    password: '',
    confirmPassword: ''
  })
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [managers, setManagers] = useState([])

  const validate = () => {
    const nextErrors = {}
    const emailLocalPart = extractEmailLocalPart(values.email)

    if (!values.firstName.trim()) nextErrors.firstName = 'First name is required.'
    if (!values.lastName.trim()) nextErrors.lastName = 'Last name is required.'
    if (!emailLocalPart) {
      nextErrors.email = 'Work email is required.'
    } else if (!/^[a-zA-Z0-9._%+-]+$/.test(emailLocalPart)) {
      nextErrors.email = 'Please enter a valid email address.'
    }

    if (!values.department.trim()) nextErrors.department = 'Department is required.'
    if (!values.designation.trim()) nextErrors.designation = 'Designation is required.'

    if (!values.role) nextErrors.role = 'Please select a role.'
    if (values.role === 'EMPLOYEE' && !values.managerId) nextErrors.managerId = 'A reporting manager is required for employee registration.'
    if (!values.password) {
      nextErrors.password = 'Password is required.'
    } else if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,20}$/.test(values.password)) {
      nextErrors.password = 'Password must be 8-20 characters with upper, lower, number, and special character.'
    }

    if (!values.confirmPassword) {
      nextErrors.confirmPassword = 'Confirm your password.'
    } else if (values.password !== values.confirmPassword) {
      nextErrors.confirmPassword = 'Passwords do not match.'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  useEffect(() => {
    const fetchManagers = async () => {
      try {
        const response = await apiRequest('getManagers')
        setManagers(Array.isArray(response) ? response : [])
      } catch {
        setManagers([])
      }
    }

    fetchManagers()
  }, [])

  const handleSubmit = async (event) => {
    event.preventDefault()
    const valid = validate()
    if (!valid) {
      return
    }

    setIsSubmitting(true)
    const result = await onSubmit(values)
    if (!result.success) {
      setErrors((prev) => ({
        ...prev,
        email: prev.email || result.message || 'Unable to submit your registration.'
      }))
    }
    setIsSubmitting(false)
  }

  const roleOptions = ['EMPLOYEE', 'MANAGER']

  return (
    <form onSubmit={handleSubmit} className="auth-form">
      <h2>Create your account</h2>
      <p>Access starts after admin approval.</p>
      {flash && <p className="flash-text">{flash}</p>}

      <div className="two-col-inputs">
        <div className="field-group">
          <label>First name</label>
          <input className={errors.firstName ? 'input-invalid' : ''} value={values.firstName} onChange={(event) => setValues((prev) => ({ ...prev, firstName: event.target.value }))} placeholder="First name" />
          {errors.firstName && <span className="field-error">{errors.firstName}</span>}
        </div>
        <div className="field-group">
          <label>Last name</label>
          <input className={errors.lastName ? 'input-invalid' : ''} value={values.lastName} onChange={(event) => setValues((prev) => ({ ...prev, lastName: event.target.value }))} placeholder="Last name" />
          {errors.lastName && <span className="field-error">{errors.lastName}</span>}
        </div>
      </div>

      <div className="field-group">
        <label>Work email</label>
        <div className="email-input-wrap">
          <input className={errors.email ? 'input-invalid' : ''} type="text" value={values.email} onChange={(event) => setValues((prev) => ({ ...prev, email: extractEmailLocalPart(event.target.value) }))} placeholder="your.name" autoComplete="username" />
          <span className="email-domain-suffix">{COMPANY_EMAIL_DOMAIN}</span>
        </div>
        {errors.email && <span className="field-error">{errors.email}</span>}
      </div>

      <div className="two-col-inputs">
        <div className="field-group">
          <label>Mobile (optional)</label>
          <input value={values.mobile} onChange={(event) => setValues((prev) => ({ ...prev, mobile: event.target.value }))} placeholder="+91" />
        </div>
        <div className="field-group">
          <label>Department</label>
          <select className={errors.department ? 'input-invalid' : ''} value={values.department} onChange={(event) => setValues((prev) => ({ ...prev, department: event.target.value }))}>
            <option>Engineering</option>
            <option>Design</option>
            <option>Finance</option>
            <option>Operations</option>
          </select>
          {errors.department && <span className="field-error">{errors.department}</span>}
        </div>
      </div>

      <div className="two-col-inputs">
        <div className="field-group">
          <label>Designation</label>
          <input className={errors.designation ? 'input-invalid' : ''} value={values.designation} onChange={(event) => setValues((prev) => ({ ...prev, designation: event.target.value }))} placeholder="Software Engineer" />
          {errors.designation && <span className="field-error">{errors.designation}</span>}
        </div>
        <div className="field-group">
          <label>Reporting Manager</label>
          <select className={errors.managerId ? 'input-invalid' : ''} value={values.managerId} onChange={(event) => setValues((prev) => ({ ...prev, managerId: event.target.value }))}>
            <option value="">Select Manager</option>
            {managers.map((manager) => {
              const roleLabel = String(manager.role || '').toUpperCase() === 'ADMIN' ? 'Admin' : 'Manager'
              return (
                <option key={manager.employee_id} value={manager.employee_id}>
                  {manager.first_name} {manager.last_name} ({roleLabel})
                </option>
              )
            })}
          </select>
          {errors.managerId && <span className="field-error">{errors.managerId}</span>}
        </div>
      </div>

      <div style={{ marginBottom: '12px' }}>
        <label style={{ display: 'block', marginBottom: '8px' }}>Role</label>
        <div className="roleSelector" style={{ display: 'flex', gap: '8px' }}>
          {roleOptions.map((role) => {
            const isSelected = values.role === role
            return (
              <button
                key={role}
                type="button"
                onClick={() => setValues((prev) => ({ ...prev, role }))}
                style={{
                  flex: 1,
                  padding: '10px 12px',
                  borderRadius: '999px',
                  border: isSelected ? '1.5px solid #0e8a5c' : '1.5px dashed rgba(16, 185, 129, 0.8)',
                  background: isSelected ? '#ecfdf5' : 'transparent',
                  color: '#0f172a',
                  fontWeight: 600,
                  cursor: 'pointer'
                }}
              >
                {role === 'EMPLOYEE' ? 'Employee' : 'Manager'}
              </button>
            )
          })}
        </div>
        {errors.role && <span className="field-error">{errors.role}</span>}
      </div>

      <div className="field-group">
        <label>Password</label>
        <div className="password-input-wrap">
          <input className={errors.password ? 'input-invalid' : ''} type={showPassword ? 'text' : 'password'} value={values.password} onChange={(event) => setValues((prev) => ({ ...prev, password: event.target.value }))} placeholder="Create password" />
          <button type="button" className="password-toggle" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((prev) => !prev)}>
            {showPassword ? (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
                <path d="M4 4L20 20" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            )}
          </button>
        </div>
        {errors.password && <span className="field-error">{errors.password}</span>}
      </div>

      <div className="field-group">
        <label>Confirm password</label>
        <div className="password-input-wrap">
          <input className={errors.confirmPassword ? 'input-invalid' : ''} type={showConfirmPassword ? 'text' : 'password'} value={values.confirmPassword} onChange={(event) => setValues((prev) => ({ ...prev, confirmPassword: event.target.value }))} placeholder="Confirm password" />
          <button type="button" className="password-toggle" aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'} onClick={() => setShowConfirmPassword((prev) => !prev)}>
            {showConfirmPassword ? (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
                <path d="M4 4L20 20" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            )}
          </button>
        </div>
        {errors.confirmPassword && <span className="field-error">{errors.confirmPassword}</span>}
      </div>

      <button className="btn btn-primary" disabled={isSubmitting}>{isSubmitting ? 'Submitting...' : 'Submit For Approval'}</button>
      <p className="subtle-row">Status after submitting: <strong>Pending Approval</strong>. You will be able to sign in once approved.</p>
    </form>
  )
}

function ClaimForm({ claimToEdit, onSubmit, onCancel }) {
  const paymentModeOptions = ['CASH', 'UPI', 'CARD', 'BANK_TRANSFER', 'OTHER']
  const currencyOptions = ['INR', 'USD', 'EUR']
  const maxFiles = 6
  const maxTotalFileSize = 5 * 1024 * 1024
  const allowedFileTypes = new Set(['image/png', 'image/jpg', 'image/jpeg', 'application/pdf'])
  const allowedFileExtensions = new Set(['png', 'jpg', 'jpeg', 'pdf'])

  const defaultValues = claimToEdit ? {
    claimType: claimToEdit.claim_type,
    title: claimToEdit.claim_title || claimToEdit.claim_id,
    description: claimToEdit.claim_description || '',
    expenseFrom: toInputDateValue(claimToEdit.expense_from),
    expenseTo: toInputDateValue(claimToEdit.expense_to),
    expenseDate: toInputDateValue(claimToEdit.expense_date || claimToEdit.expense_from),
    amount: claimToEdit.expense_amount,
    paymentMode: claimToEdit.payment_mode || 'CARD',
    currency: claimToEdit.currency || 'INR',
    vendor: claimToEdit.vendor_name || claimToEdit.vendor || '',
    location: claimToEdit.location || '',
    docRequired: claimToEdit.doc_required,
    remarks: claimToEdit.remarks || '',
    status: 'SUBMITTED',
    attachments: JSON.parse(claimToEdit.attachments || '[]')
  } : {
    claimType: 'TRAVEL',
    title: '',
    description: '',
    expenseFrom: '',
    expenseTo: '',
    expenseDate: '',
    amount: '',
    paymentMode: 'CARD',
    currency: 'INR',
    vendor: '',
    location: '',
    docRequired: true,
    remarks: '',
    status: 'DRAFT',
    attachments: []
  }

  const [values, setValues] = useState(defaultValues)
  const [errorMessages, setErrorMessages] = useState([])
  const [fieldErrors, setFieldErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    setValues(defaultValues)
  }, [claimToEdit])

  const parseInputDate = (value) => {
    if (!value) return null
    const date = new Date(`${value}T00:00:00`)
    if (Number.isNaN(date.getTime())) return null
    return startOfDay(date)
  }

  const getFileExtension = (fileName) => {
    const parts = String(fileName || '').toLowerCase().split('.')
    return parts.length > 1 ? parts.pop() : ''
  }

  const isAllowedAttachment = (fileName, mimeType) => {
    const normalizedType = String(mimeType || '').toLowerCase()
    const extension = getFileExtension(fileName)
    return allowedFileTypes.has(normalizedType) || allowedFileExtensions.has(extension)
  }

  const validateForSubmit = () => {
    const nextFieldErrors = {}
    const nextErrors = []
    const today = startOfDay(new Date())

    if (!String(values.title || '').trim()) {
      nextFieldErrors.title = 'Title is required.'
      nextErrors.push('Title is required.')
    }

    if (!String(values.description || '').trim()) {
      nextFieldErrors.description = 'Description is required.'
      nextErrors.push('Description is required.')
    }

    if (!String(values.amount || '').trim()) {
      nextFieldErrors.amount = 'Amount is required.'
      nextErrors.push('Amount is required.')
    } else {
      const amountNumber = Number(values.amount)
      if (!Number.isFinite(amountNumber) || amountNumber <= 0) {
        nextFieldErrors.amount = 'Amount must be greater than 0.'
        nextErrors.push('Amount must be greater than 0.')
      }
    }

    if (!values.expenseDate) {
      nextFieldErrors.expenseDate = 'Expense date is required.'
      nextErrors.push('Expense date is required.')
    } else {
      const expenseDate = parseInputDate(values.expenseDate)
      if (!expenseDate) {
        nextFieldErrors.expenseDate = 'Please provide a valid expense date.'
        nextErrors.push('Please provide a valid expense date.')
      } else if (expenseDate.getTime() > today.getTime()) {
        nextFieldErrors.expenseDate = 'Expense date cannot be in the future.'
        nextErrors.push('Expense date cannot be in the future.')
      }
    }

    const expenseFrom = parseInputDate(values.expenseFrom)
    const expenseTo = parseInputDate(values.expenseTo)

    if (expenseFrom && expenseFrom.getTime() > today.getTime()) {
      nextFieldErrors.expenseFrom = 'From date cannot be in the future.'
      nextErrors.push('From date cannot be in the future.')
    }

    if (expenseFrom && expenseTo && expenseFrom.getTime() > expenseTo.getTime()) {
      nextFieldErrors.expenseTo = 'To date cannot be earlier than From date.'
      nextErrors.push('To date cannot be earlier than From date.')
    }

    const totalAttachmentSize = values.attachments.reduce((total, file) => total + Number(file.size || 0), 0)
    const hasUnsupportedFiles = values.attachments.some(
      (file) => !isAllowedAttachment(file.name, file.mimeType)
    )

    if (hasUnsupportedFiles) {
      nextErrors.push('Allowed file types are PNG, JPG, JPEG, and PDF only.')
    }

    if (totalAttachmentSize > maxTotalFileSize) {
      nextErrors.push("Total files size can't exceed 5MB.")
    }

    if (values.attachments.length > maxFiles) {
      nextErrors.push(`You can upload up to ${maxFiles} files only.`)
    }

    setFieldErrors(nextFieldErrors)
    setErrorMessages(nextErrors)

    return nextErrors.length === 0
  }

  const handleFiles = (event) => {
    const selectedFiles = Array.from(event.target.files || [])
    if (!selectedFiles.length) {
      return
    }

    const nextErrors = []
    const nextAttachments = [...values.attachments]
    let totalAttachmentSize = nextAttachments.reduce((total, file) => total + Number(file.size || 0), 0)

    selectedFiles.forEach((file) => {
      if (!isAllowedAttachment(file.name, file.type)) {
        nextErrors.push(`${file.name}: allowed files are PNG, JPG, JPEG, and PDF only.`)
        return
      }

      if (nextAttachments.length >= maxFiles) {
        nextErrors.push(`Only ${maxFiles} files can be uploaded per claim.`)
        return
      }

      if (totalAttachmentSize + file.size > maxTotalFileSize) {
        nextErrors.push("Total files size can't exceed 5MB.")
        return
      }

      nextAttachments.push({
        fileId: createId('DOC'),
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        size: file.size,
        uploadedAt: new Date().toISOString(),
        file
      })
      totalAttachmentSize += file.size
    })

    const dedupedErrors = Array.from(new Set(nextErrors))
    setErrorMessages(dedupedErrors)
    setValues((prev) => ({ ...prev, attachments: nextAttachments }))

    event.target.value = ''
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setErrorMessages([])

    if (!validateForSubmit()) {
      return
    }

    setIsSubmitting(true)

    const payload = {
      claimId: claimToEdit?.claim_id,
      claimType: values.claimType,
      title: values.title,
      description: values.description,
      expenseDate: values.expenseDate,
      expenseFrom: values.expenseFrom,
      expenseTo: values.expenseTo,
      amount: values.amount,
      docRequired: values.docRequired,
      remarks: values.remarks,
      paymentMode: values.paymentMode,
      currency: values.currency,
      vendor: values.vendor,
      location: values.location,
      status: values.status,
      attachments: values.attachments
    }

    const result = await onSubmit(payload)
    if (!result.success) {
      setErrorMessages([result.message || 'Unable to submit claim.'])
    }
    setIsSubmitting(false)
  }

  const saveAsDraft = async () => {
    setErrorMessages([])
    setFieldErrors({})
    setIsSubmitting(true)
    const result = await onSubmit({
      claimId: claimToEdit?.claim_id,
      claimType: values.claimType,
      title: values.title,
      description: values.description,
      expenseDate: values.expenseDate,
      expenseFrom: values.expenseFrom || values.expenseDate,
      expenseTo: values.expenseTo || values.expenseDate,
      amount: values.amount,
      docRequired: values.docRequired,
      remarks: values.remarks,
      paymentMode: values.paymentMode,
      currency: values.currency,
      vendor: values.vendor,
      location: values.location,
      status: 'DRAFT',
      attachments: values.attachments
    })
    if (!result.success) {
      setErrorMessages([result.message || 'Unable to save draft.'])
    }
    setIsSubmitting(false)
  }

  const removeAttachment = (indexToRemove) => {
    setValues((prev) => ({
      ...prev,
      attachments: prev.attachments.filter((_, index) => index !== indexToRemove)
    }))
  }

  return (
    <form className="expense-editor" onSubmit={handleSubmit}>
      {errorMessages.length > 0 && (
        <div className="error-text" role="alert" aria-live="polite">
          <ul className="error-list">
            {errorMessages.map((message, index) => <li key={`${message}-${index}`}>{message}</li>)}
          </ul>
        </div>
      )}
      <div className="editor-main panel-card">
        <label>Expense Type</label>
        <div className="chip-row">
          {claimTypes.map((type) => (
            <button
              key={type}
              type="button"
              className={values.claimType.toLowerCase() === type.toLowerCase() ? 'type-chip active' : 'type-chip'}
              onClick={() => setValues((prev) => ({ ...prev, claimType: type }))}
            >
              {type}
            </button>
          ))}
        </div>

        <div className="form-grid two">
          <div className="field-wide">
            <label>Title</label>
            <input className={fieldErrors.title ? 'input-invalid' : ''} value={values.title} onChange={(event) => setValues((prev) => ({ ...prev, title: event.target.value }))} placeholder="Client lunch" />
            {fieldErrors.title && <span className="field-error">{fieldErrors.title}</span>}
          </div>
          <div className="field-wide">
            <label>Description</label>
            <textarea className={fieldErrors.description ? 'input-invalid' : ''} rows="3" value={values.description} onChange={(event) => setValues((prev) => ({ ...prev, description: event.target.value }))} placeholder="Lunch with the project sponsor." />
            {fieldErrors.description && <span className="field-error">{fieldErrors.description}</span>}
          </div>
          <div>
            <label>Expense Date</label>
            <input className={fieldErrors.expenseDate ? 'input-invalid' : ''} type="date" value={values.expenseDate} onChange={(event) => setValues((prev) => ({ ...prev, expenseDate: event.target.value, expenseFrom: event.target.value }))} />
            {fieldErrors.expenseDate && <span className="field-error">{fieldErrors.expenseDate}</span>}
          </div>
          <div>
            <label>Amount (Rs)</label>
            <input className={fieldErrors.amount ? 'input-invalid' : ''} type="number" min="0.01" step="0.01" value={values.amount} onChange={(event) => setValues((prev) => ({ ...prev, amount: event.target.value }))} />
            {fieldErrors.amount && <span className="field-error">{fieldErrors.amount}</span>}
          </div>
          <div>
            <label>From (Travel/Stay)</label>
            <input
              className={fieldErrors.expenseFrom ? 'input-invalid' : ''}
              type="date"
              value={values.expenseFrom}
              onChange={(event) => setValues((prev) => ({ ...prev, expenseFrom: event.target.value }))}
            />
            {fieldErrors.expenseFrom && <span className="field-error">{fieldErrors.expenseFrom}</span>}
          </div>
          <div>
            <label>To</label>
            <input
              className={fieldErrors.expenseTo ? 'input-invalid' : ''}
              type="date"
              value={values.expenseTo}
              onChange={(event) => setValues((prev) => ({ ...prev, expenseTo: event.target.value }))}
            />
            {fieldErrors.expenseTo && <span className="field-error">{fieldErrors.expenseTo}</span>}
          </div>
          <div className="field-wide chip-field-stack">
            <label>Payment Mode</label>
            <div className="chip-row compact">
              {paymentModeOptions.map((mode) => (
                <button
                  key={mode}
                  type="button"
                  className={values.paymentMode === mode ? 'type-chip active' : 'type-chip'}
                  onClick={() => setValues((prev) => ({ ...prev, paymentMode: mode }))}
                >
                  {mode === 'BANK_TRANSFER' ? 'Bank Transfer' : mode.charAt(0) + mode.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>
          <div className="field-wide chip-field-stack">
            <label>Currency</label>
            <div className="chip-row compact">
              {currencyOptions.map((currency) => (
                <button
                  key={currency}
                  type="button"
                  className={values.currency === currency ? 'type-chip active' : 'type-chip'}
                  onClick={() => setValues((prev) => ({ ...prev, currency }))}
                >
                  {currency}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label>Vendor</label>
            <input value={values.vendor} onChange={(event) => setValues((prev) => ({ ...prev, vendor: event.target.value }))} placeholder="Olive Kitchen" />
          </div>
          <div>
            <label>Location</label>
            <input value={values.location} onChange={(event) => setValues((prev) => ({ ...prev, location: event.target.value }))} placeholder="Bengaluru" />
          </div>
          <div className="field-wide">
            <label>Remarks</label>
            <textarea rows="2" value={values.remarks} onChange={(event) => setValues((prev) => ({ ...prev, remarks: event.target.value }))} placeholder="Optional notes" />
          </div>
        </div>
      </div>

      <aside className="editor-side">
        <div className="panel-card proof-panel">
          <h3>Proof Documents</h3>
          <label htmlFor="claim-files" className="upload-drop">Drop Files Here Or Browse</label>
          <label htmlFor="claim-files" className="choose-files-btn">Choose Files</label>
          <input id="claim-files" className="claim-file-input" type="file" multiple onChange={handleFiles} />
          <small>{values.attachments.length} of 6 uploaded</small>
          <div className="proof-list">
            {values.attachments.map((file, index) => (
              <div key={file.fileId || file.name} className="proof-item">
                <span>{file.name}</span>
                <button type="button" className="tiny-btn" onClick={() => removeAttachment(index)}>Remove</button>
              </div>
            ))}
          </div>
        </div>

        <div className="panel-card total-card">
          <span>Claim total</span>
          <strong>{formatCurrency(values.amount || 0)}</strong>
          <div className="claim-action-buttons">
            <button type="submit" className="btn btn-primary" disabled={isSubmitting}>{isSubmitting ? 'Submitting...' : claimToEdit ? 'Resubmit For Review' : 'Submit For Review'}</button>
            <button type="button" className="btn btn-secondary" onClick={saveAsDraft} disabled={isSubmitting}>Save As Draft</button>
          </div>
          <button type="button" className="btn btn-link" onClick={onCancel}>Cancel</button>
        </div>
      </aside>
    </form>
  )
}

function RejectClaimButton({ claimId, onReject }) {
  const [isOpen, setIsOpen] = useState(false)
  const [remarks, setRemarks] = useState('')

  const handleSubmit = () => {
    const result = onReject(claimId, remarks)
    if (result?.success) {
      setIsOpen(false)
      setRemarks('')
    }
  }

  return (
    <>
      <button className="tiny-btn danger" onClick={() => setIsOpen(true)}>Reject</button>
      {isOpen && (
        <div className="modal-backdrop" onClick={() => setIsOpen(false)}>
          <div className="modal-card" onClick={(event) => event.stopPropagation()}>
            <h3>Reject Claim</h3>
            <label>Rejection remarks</label>
            <textarea rows="4" value={remarks} onChange={(event) => setRemarks(event.target.value)} placeholder="Mandatory rejection remarks" />
            <div className="action-row">
              <button className="btn btn-secondary" onClick={() => setIsOpen(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSubmit}>Confirm Reject</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

function MetricCard({ title, value, accent }) {
  return (
    <article className={`metric-card ${accent}`}>
      <h3>{title}</h3>
      <strong>{value}</strong>
    </article>
  )
}

function InfoBlock({ label, value }) {
  return (
    <div className="info-block">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function Toast({ message, onClose }) {
  useEffect(() => {
    const timeout = window.setTimeout(() => onClose(), 3500)
    return () => window.clearTimeout(timeout)
  }, [message, onClose])

  return (
    <div className="toast">{message}</div>
  )
}

export default App
