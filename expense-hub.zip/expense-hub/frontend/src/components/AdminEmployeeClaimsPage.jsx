import { useMemo, useState } from 'react'

const statusOptions = [
  { label: 'All Status', value: 'ALL' },
  { label: 'Approved', value: 'APPROVED' },
  { label: 'Pending', value: 'PENDING' },
  { label: 'Rejected', value: 'REJECTED' }
]

function toDisplayStatus(status) {
  const safe = String(status || '').toUpperCase()
  if (safe === 'SUBMITTED' || safe === 'UNDER_REVIEW') return 'PENDING'
  if (safe === 'REJECTED' || safe === 'MORE_INFO_NEEDED') return 'REJECTED'
  if (safe === 'APPROVED') return 'APPROVED'
  return safe || 'PENDING'
}

function normalize(value) {
  return String(value || '').trim().toLowerCase()
}

export default function AdminEmployeeClaimsPage({
  claims,
  users,
  formatCurrency,
  formatDate,
  onViewClaim
}) {
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [categoryFilter, setCategoryFilter] = useState('ALL')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [searchText, setSearchText] = useState('')

  const claimsWithMeta = useMemo(() => claims.map((claim) => {
    const employee = users.find((item) => (item.user_id || item.employee_id) === claim.user_id)
    return {
      ...claim,
      employeeName: employee ? `${employee.first_name} ${employee.last_name}` : 'Unknown Employee',
      merchantName: claim.vendor_name || claim.vendor || 'N/A',
      displayStatus: toDisplayStatus(claim.status)
    }
  }), [claims, users])

  const categories = useMemo(() => {
    const allTypes = Array.from(new Set(claimsWithMeta.map((claim) => claim.claim_type).filter(Boolean)))
    return ['ALL', ...allTypes]
  }, [claimsWithMeta])

  const filteredClaims = useMemo(() => {
    return claimsWithMeta.filter((claim) => {
      const statusOk = statusFilter === 'ALL' || claim.displayStatus === statusFilter
      const categoryOk = categoryFilter === 'ALL' || claim.claim_type === categoryFilter

      const expenseDate = claim.expense_from || claim.created_at
      const fromOk = !fromDate || new Date(expenseDate) >= new Date(fromDate)
      const toOk = !toDate || new Date(expenseDate) <= new Date(toDate)

      const needle = normalize(searchText)
      const searchOk = !needle || [
        claim.claim_id,
        claim.claim_type,
        claim.employeeName,
        claim.merchantName,
        claim.remarks
      ].some((field) => normalize(field).includes(needle))

      return statusOk && categoryOk && fromOk && toOk && searchOk
    })
  }, [claimsWithMeta, statusFilter, categoryFilter, fromDate, toDate, searchText])

  const summary = useMemo(() => {
    const total = claimsWithMeta.length
    const approvedItems = claimsWithMeta.filter((claim) => claim.displayStatus === 'APPROVED')
    const pendingItems = claimsWithMeta.filter((claim) => claim.displayStatus === 'PENDING')
    const rejectedItems = claimsWithMeta.filter((claim) => claim.displayStatus === 'REJECTED')

    return {
      total,
      approvedCount: approvedItems.length,
      approvedAmount: approvedItems.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0),
      pendingCount: pendingItems.length,
      pendingAmount: pendingItems.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0),
      rejectedCount: rejectedItems.length,
      rejectedAmount: rejectedItems.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
    }
  }, [claimsWithMeta])

  const resetFilters = () => {
    setStatusFilter('ALL')
    setCategoryFilter('ALL')
    setFromDate('')
    setToDate('')
    setSearchText('')
  }

  return (
    <section className="workspace-page employee-claims-page">
      <div className="workspace-head employee-claims-head">
        <div>
          <h1>Employee Claims</h1>
          <p>View and track all employee expense claims.</p>
        </div>
        <button type="button" className="btn btn-primary employee-claims-new-btn">+ New Claim</button>
      </div>

      <div className="metric-grid employee-claims-metrics">
        <article className="metric-card claims-summary-card">
          <h3>Total Claims</h3>
          <strong>{summary.total}</strong>
        </article>
        <article className="metric-card claims-summary-card success">
          <h3>Approved</h3>
          <strong>{summary.approvedCount}</strong>
          <span>{formatCurrency(summary.approvedAmount)}</span>
        </article>
        <article className="metric-card claims-summary-card warning">
          <h3>Pending</h3>
          <strong>{summary.pendingCount}</strong>
          <span>{formatCurrency(summary.pendingAmount)}</span>
        </article>
        <article className="metric-card claims-summary-card danger">
          <h3>Rejected</h3>
          <strong>{summary.rejectedCount}</strong>
          <span>{formatCurrency(summary.rejectedAmount)}</span>
        </article>
      </div>

      <div className="panel-card employee-claims-filters">
        <div className="employee-filter-grid">
          <div>
            <label>Status</label>
            <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
              {statusOptions.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label>Category</label>
            <select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}>
              {categories.map((type) => (
                <option key={type} value={type}>{type === 'ALL' ? 'All Categories' : type}</option>
              ))}
            </select>
          </div>
          <div>
            <label>Date From</label>
            <input type="date" value={fromDate} onChange={(event) => setFromDate(event.target.value)} />
          </div>
          <div>
            <label>Date To</label>
            <input type="date" value={toDate} onChange={(event) => setToDate(event.target.value)} />
          </div>
          <div>
            <label>Search</label>
            <input type="text" value={searchText} onChange={(event) => setSearchText(event.target.value)} placeholder="Search by employee, claim or category" />
          </div>
          <div className="filter-actions">
            <button type="button" className="btn btn-secondary filter-reset-btn" onClick={resetFilters}>Reset</button>
          </div>
        </div>
      </div>

      <div className="panel-card table-panel modern-table employee-claims-table">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Date</th>
              <th>Description</th>
              <th>Category</th>
              <th>Merchant / Vendor</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Submitted On</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredClaims.length ? filteredClaims.map((claim, index) => (
              <tr key={claim.claim_id}>
                <td>{index + 1}</td>
                <td>{formatDate(claim.expense_from || claim.expense_date)}</td>
                <td>{claim.employeeName}</td>
                <td>{claim.claim_type}</td>
                <td>{claim.merchantName}</td>
                <td>{formatCurrency(claim.expense_amount)}</td>
                <td><span className={`status-badge ${claim.displayStatus.toLowerCase()}`}>{claim.displayStatus}</span></td>
                <td>{formatDate(claim.created_at)}</td>
                <td>
                  <button type="button" className="tiny-btn" onClick={() => onViewClaim(claim.claim_id)}>View</button>
                </td>
              </tr>
            )) : (
              <tr><td colSpan="9" className="empty-state">No claims matched your filters.</td></tr>
            )}
          </tbody>
        </table>
        <div className="employee-claims-footnote">
          Showing {filteredClaims.length ? 1 : 0} - {filteredClaims.length} of {filteredClaims.length} claims
        </div>
      </div>
    </section>
  )
}
