import { useState } from 'react'

function getEmployeeStatus(userItem) {
  const registrationStatus = String(userItem?.registration_status || '').toUpperCase()
  const accountStatus = String(userItem?.account_status || '').toUpperCase()
  const fallbackStatus = String(userItem?.status || '').toUpperCase()

  if (registrationStatus === 'PENDING') return 'PENDING'
  if (registrationStatus === 'REJECTED') return 'REJECTED'
  if (accountStatus === 'ACTIVE' || fallbackStatus === 'ACTIVE') return 'APPROVED'
  if (accountStatus === 'BLOCKED' || fallbackStatus === 'BLOCKED') return 'REJECTED'
  if (fallbackStatus === 'REJECTED') return 'REJECTED'
  if (fallbackStatus === 'PENDING') return 'PENDING'
  return 'APPROVED'
}

function formatRequestedRecency(dateValue) {
  const date = new Date(dateValue)
  if (Number.isNaN(date.getTime())) return '—'

  const now = new Date()
  const midnightToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const midnightDate = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  const diffDays = Math.floor((midnightToday.getTime() - midnightDate.getTime()) / (1000 * 60 * 60 * 24))

  if (diffDays <= 0) return 'Today'
  if (diffDays === 1) return 'Yesterday'
  return `${diffDays} days ago`
}

function getEmployeeId(userItem) {
  return userItem?.employee_id || userItem?.user_id || ''
}

function buildRegistrationRows(employee) {
  if (!employee) return []

  return [
    { label: 'Employee ID', value: employee.employee_id || employee.user_id || '—' },
    { label: 'Employee Code', value: employee.employee_code || '—' },
    { label: 'First Name', value: employee.first_name || '—' },
    { label: 'Last Name', value: employee.last_name || '—' },
    { label: 'Email', value: employee.email || '—' },
    { label: 'Mobile Number', value: employee.mobile_number || '—' },
    { label: 'Company', value: employee.company || 'AxiotechX' },
    { label: 'Department', value: employee.department || '—' },
    { label: 'Designation', value: employee.designation || '—' },
    { label: 'Role', value: employee.role || 'EMPLOYEE' },
    { label: 'Manager ID', value: employee.manager_id || '—' },
    { label: 'Registration Status', value: employee.registration_status || employee.status || '—' },
    { label: 'Account Status', value: employee.account_status || '—' },
    { label: 'Rejected Reason', value: employee.rejection_reason || '—' },
    { label: 'Requested On', value: employee.created_at ? new Date(employee.created_at).toLocaleString('en-IN') : '—' }
  ]
}

export default function AdminEmployeesPage({
  adminUsers,
  adminEmployeeFilter,
  setAdminEmployeeFilter,
  selectedAdminEmployeeId,
  setSelectedAdminEmployeeId,
  adminRejectReason,
  setAdminRejectReason,
  adminRejectError,
  setAdminRejectError,
  onApproveUser,
  onRejectUser
}) {
  const [infoEmployee, setInfoEmployee] = useState(null)

  const filteredUsers = adminUsers.filter((item) => getEmployeeStatus(item) === adminEmployeeFilter)
  const selectedEmployee = adminUsers.find((item) => getEmployeeId(item) === selectedAdminEmployeeId) || null
  const selectedStatus = selectedEmployee ? getEmployeeStatus(selectedEmployee) : null
  const pendingCount = adminUsers.filter((item) => getEmployeeStatus(item) === 'PENDING').length
  const approvedCount = adminUsers.filter((item) => getEmployeeStatus(item) === 'APPROVED').length
  const rejectedCount = adminUsers.filter((item) => getEmployeeStatus(item) === 'REJECTED').length

  return (
    <section className="workspace-page">
      <div className="workspace-head">
        <div>
          <h1>Registration requests</h1>
          <p>Confirm each person is an AxiotechX employee.</p>
        </div>
        <div className="chip-toggle compact">
          <button type="button" className={adminEmployeeFilter === 'PENDING' ? 'active' : ''} onClick={() => setAdminEmployeeFilter('PENDING')}>Pending ({pendingCount})</button>
          <button type="button" className={adminEmployeeFilter === 'APPROVED' ? 'active' : ''} onClick={() => setAdminEmployeeFilter('APPROVED')}>Approved ({approvedCount})</button>
          <button type="button" className={adminEmployeeFilter === 'REJECTED' ? 'active' : ''} onClick={() => setAdminEmployeeFilter('REJECTED')}>Rejected ({rejectedCount})</button>
        </div>
      </div>

      <div className="split-page">
        <div className="panel-card table-panel modern-table">
          <table>
            <thead>
              <tr>
                <th>Info</th>
                <th>Employee</th>
                <th>Department</th>
                <th>Role</th>
                <th>Requested</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length ? filteredUsers.slice(0, 12).map((item) => {
                const status = getEmployeeStatus(item)
                const employeeId = getEmployeeId(item)
                const isSelected = selectedAdminEmployeeId === employeeId
                return (
                  <tr key={employeeId} className={isSelected ? 'employee-row-selected' : ''} onClick={() => { setSelectedAdminEmployeeId(employeeId); setAdminRejectError('') }}>
                    <td>
                      <button
                        type="button"
                        className="table-icon-btn"
                        aria-label={`View ${item.first_name || ''} ${item.last_name || ''} registration details`}
                        onClick={(event) => {
                          event.stopPropagation()
                          setInfoEmployee(item)
                        }}
                      >
                        i
                      </button>
                    </td>
                    <td>
                      <strong>{item.first_name} {item.last_name}</strong>
                      <div className="subtle-row">{item.designation || 'Employee'}</div>
                    </td>
                    <td>{item.department || 'Engineering'}</td>
                    <td>
                      <span className={`employee-role-tag ${String(item.role || 'EMPLOYEE').toLowerCase()}`}>
                        {String(item.role || 'EMPLOYEE').charAt(0).toUpperCase() + String(item.role || 'EMPLOYEE').slice(1).toLowerCase()}
                      </span>
                    </td>
                    <td>{formatRequestedRecency(item.created_at)}</td>
                    <td className="cell-actions">
                      {status === 'PENDING'
                        ? <button className="tiny-btn success" onClick={(event) => { event.stopPropagation(); setSelectedAdminEmployeeId(employeeId) }}>Review</button>
                        : <button className="tiny-btn" onClick={(event) => { event.stopPropagation(); setSelectedAdminEmployeeId(employeeId) }}>View</button>}
                    </td>
                  </tr>
                )
              }) : (
                <tr>
                  <td colSpan="6" className="empty-state">No employees found for this status.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="panel-card side-review-card">
          {!selectedEmployee ? (
            <>
              <h3>Employee review panel</h3>
              <p>Select an employee from the list to review account details and take action.</p>
              <div className="side-placeholder">No employee selected</div>
            </>
          ) : (
            <>
              <h3>{selectedEmployee.first_name} {selectedEmployee.last_name}</h3>
              <p>
                Email domain matches company. Reporting manager: {selectedEmployee.manager_name || 'Not Assigned'}
              </p>
              <div className="status-pill-row">
                <span className={`approval-pill ${selectedStatus === 'APPROVED' ? 'ok-solid' : 'ok'}`}>Approve And Activate</span>
                <span className={`approval-pill ${selectedStatus === 'REJECTED' ? 'bad-solid' : 'bad'}`}>Reject</span>
              </div>

              {selectedStatus === 'PENDING' ? (
                <>
                  <div className="stacked-actions">
                    <button type="button" className="btn btn-primary" onClick={() => onApproveUser(getEmployeeId(selectedEmployee))}>Approve And Activate</button>
                  </div>
                </>
              ) : selectedStatus === 'REJECTED' ? (
                <div className="stacked-actions">
                  <button type="button" className="btn btn-primary" onClick={() => onApproveUser(getEmployeeId(selectedEmployee))}>Approve And Activate</button>
                </div>
              ) : selectedStatus === 'APPROVED' ? (
                <>
                  <label>Reason for rejection (required)</label>
                  <textarea
                    rows="4"
                    value={adminRejectReason}
                    onChange={(event) => { setAdminRejectReason(event.target.value); setAdminRejectError('') }}
                    placeholder="Enter a reason to reject this registration."
                  />
                  {adminRejectError && <span className="field-error">{adminRejectError}</span>}
                  <div className="stacked-actions">
                    <button type="button" className="btn btn-danger" onClick={() => onRejectUser(getEmployeeId(selectedEmployee), adminRejectReason)}>Reject Registration</button>
                  </div>
                </>
              ) : (
                <div className="side-placeholder">This employee has already been {selectedStatus === 'APPROVED' ? 'approved' : 'rejected'}.</div>
              )}
            </>
          )}
        </div>
      </div>

      {infoEmployee && (
        <div className="modal-backdrop" onClick={() => setInfoEmployee(null)}>
          <div className="modal-card registration-info-modal" onClick={(event) => event.stopPropagation()}>
            <h3>{infoEmployee.first_name} {infoEmployee.last_name}</h3>
            <p>Complete registration information</p>
            <div className="registration-info-grid">
              {buildRegistrationRows(infoEmployee).map((row) => (
                <div key={row.label} className="registration-info-row">
                  <span>{row.label}</span>
                  <strong>{row.value}</strong>
                </div>
              ))}
            </div>
            <div className="action-row">
              <button type="button" className="btn btn-primary" onClick={() => setInfoEmployee(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
