export default function ReportsPage({ user, reportMetrics, formatCurrency, MetricCard }) {
  return (
    <section className="content-panel">
      <div className="page-head">
        <div>
          <p className="breadcrumb">{user?.role === 'ADMIN' ? 'Admin / Reports' : 'Reports'}</p>
          <h1>Reports</h1>
        </div>
      </div>

      <div className="metric-grid">
        <MetricCard title="Total Claims" value={reportMetrics.totalClaims} accent="blue" />
        <MetricCard title="Approved" value={reportMetrics.approvedCount} accent="green" />
        <MetricCard title="Rejected" value={reportMetrics.rejectedCount} accent="red" />
        <MetricCard title="Under Review" value={reportMetrics.underReviewCount} accent="amber" />
        <MetricCard title="Total Amount" value={formatCurrency(reportMetrics.totalAmount)} accent="purple" />
      </div>

      <div className="panel-grid two-columns">
        <div className="panel-card">
          <h3>Claims by Type</h3>
          {reportMetrics.byType.map((entry) => (
            <div className="bar-list" key={entry.name}>
              <div className="bar-header"><span>{entry.name}</span><strong>{entry.count}</strong></div>
              <div className="progress"><span style={{ width: `${Math.max((entry.count / Math.max(reportMetrics.totalClaims, 1)) * 100, 8)}%` }} /></div>
            </div>
          ))}
        </div>

        <div className="panel-card">
          <h3>Claims by Status</h3>
          {reportMetrics.byStatus.map((entry) => (
            <div className="bar-list" key={entry.name}>
              <div className="bar-header"><span>{entry.name}</span><strong>{entry.count}</strong></div>
              <div className="progress"><span style={{ width: `${Math.max((entry.count / Math.max(reportMetrics.totalClaims, 1)) * 100, 8)}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
