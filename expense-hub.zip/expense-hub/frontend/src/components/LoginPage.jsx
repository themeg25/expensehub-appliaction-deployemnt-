function LoginPage() {
  const features = [
    {
      icon: 'D',
      title: 'Easy Expense Submission',
      text: 'Upload bills and submit claims in seconds.'
    },
    {
      icon: 'S',
      title: 'Transparent Approvals',
      text: 'Track status and get notified at every step.'
    },
    {
      icon: 'B',
      title: 'Powerful Insights',
      text: 'Real-time reports for better financial control.'
    },
    {
      icon: 'M',
      title: 'Built for Multiple Companies',
      text: 'Manage expenses across organizations seamlessly.'
    }
  ]

  return (
    <div className="page-login">
      <section className="login-hero">
        <header className="brand">ExpenseHub</header>
        <p className="eyebrow">EXPENSE MANAGEMENT MADE SIMPLE</p>
        <h1>
          Track. Claim. Approve.
          <br />
          <span>All in One Place.</span>
        </h1>
        <p className="subtitle">A modern and secure expense management platform for employees and organizations.</p>

        <ul className="feature-list">
          {features.map((feature) => (
            <li key={feature.title}>
              <span className="feature-icon">{feature.icon}</span>
              <div>
                <strong>{feature.title}</strong>
                <p>{feature.text}</p>
              </div>
            </li>
          ))}
        </ul>

        <p className="signature">Work Smarter, Spend Better</p>
      </section>

      <section className="login-panel">
        <div className="top-links">
          <a href="#">Help</a>
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">English</a>
        </div>

        <div className="auth-card">
          <h2>ExpenseHub</h2>
          <h3>Welcome Back</h3>
          <p>Sign in to your account</p>

          <label>Email address</label>
          <input type="email" placeholder="you@company.com" />

          <label>Password</label>
          <input type="password" placeholder="Enter your password" />

          <div className="auth-row">
            <label className="check">
              <input type="checkbox" /> Keep me signed in
            </label>
            <a href="#">Forgot password?</a>
          </div>

          <button type="button" className="btn-primary">Sign In</button>

          <div className="or">OR</div>
          <button type="button" className="btn-secondary">Sign in with Microsoft</button>

          <small>Don\'t have an account? Contact your company administrator.</small>
        </div>
      </section>
    </div>
  )
}

export default LoginPage
