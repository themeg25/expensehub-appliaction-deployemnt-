export default function NewClaimPage({ claimToEdit, ClaimForm, onSubmit, onCancel }) {
  return (
    <section className="workspace-page new-claim-workspace">
      <div className="page-head">
        <div>
          <p className="breadcrumb">My Expenses / {claimToEdit ? 'Edit Expense' : 'New Expense'}</p>
          <h1>{claimToEdit ? 'Edit Expense' : 'Create New Expense'}</h1>
        </div>
      </div>
      {claimToEdit?.reviewer_remarks && (
        <div className="alert-banner note">
          <strong>Reviewer comment:</strong>
          <span>"{claimToEdit.reviewer_remarks}"</span>
        </div>
      )}
      <ClaimForm
        claimToEdit={claimToEdit}
        onSubmit={onSubmit}
        onCancel={onCancel}
      />
    </section>
  )
}
