export default function DashboardPage({
  user,
  myClaims,
  formatCurrency,
  formatDate,
  statusLabels,
  onCreateNewClaim,
  onUpdateClaim,
  onOpenClaim
}) {
  const employeeClaims = myClaims
    .filter((claim) => String(claim.user_id || '').trim() === String(user?.user_id || '').trim())
    .sort((left, right) => new Date(right.created_at) - new Date(left.created_at))

  const submitted = employeeClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW').length
  const approved = employeeClaims.filter((claim) => claim.status === 'APPROVED').length
  const rejected = employeeClaims.filter((claim) => claim.status === 'REJECTED').length
  const totalAmount = employeeClaims.reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
  const approvedAmount = employeeClaims.filter((claim) => claim.status === 'APPROVED').reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
  const submittedAmount = employeeClaims.filter((claim) => claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW').reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
  const rejectedAmount = employeeClaims.filter((claim) => claim.status === 'REJECTED').reduce((sum, claim) => sum + Number(claim.expense_amount || 0), 0)
  const needsInputClaim = employeeClaims.find((claim) => claim.status === 'REJECTED' || claim.status === 'MORE_INFO_NEEDED')

  const monthlySpend = (() => {
    const now = new Date()
    const rows = []

    for (let monthOffset = 5; monthOffset >= 0; monthOffset -= 1) {
      const date = new Date(now.getFullYear(), now.getMonth() - monthOffset, 1)
      rows.push({
        key: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`,
        label: date.toLocaleDateString('en-IN', { month: 'short' }),
        amount: 0
      })
    }

    const monthMap = new Map(rows.map((row) => [row.key, row]))
    employeeClaims.forEach((claim) => {
      const sourceDate = claim.expense_from || claim.expense_date || claim.created_at
      const parsed = new Date(sourceDate)
      if (Number.isNaN(parsed.getTime())) return

      const key = `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, '0')}`
      const monthEntry = monthMap.get(key)
      if (!monthEntry) return
      monthEntry.amount += Number(claim.expense_amount || 0)
    })

    const maxAmount = Math.max(...rows.map((row) => row.amount), 0)
    return rows.map((row) => ({
      ...row,
      height: maxAmount > 0 ? Math.max((row.amount / maxAmount) * 100, row.amount > 0 ? 10 : 4) : 4
    }))
  })()

  const categories = Array.from(
    employeeClaims.reduce((map, claim) => {
      const categoryName = String(claim.claim_type || '').trim()
      if (!categoryName) return map
      const current = map.get(categoryName) || { name: categoryName, count: 0, amount: 0 }
      current.count += 1
      current.amount += Number(claim.expense_amount || 0)
      map.set(categoryName, current)
      return map
    }, new Map()).values()
  ).sort((left, right) => right.amount - left.amount)

  const totalCategoryAmount = categories.reduce((sum, entry) => sum + Number(entry.amount || 0), 0)

  return (
    <section className="workspace-page">
      <div className="workspace-head">
        <div>
          <h1>Good morning, {user?.first_name || 'Employee'}</h1>
          <p>Here is where your claims stand this month.</p>
        </div>
        <button className="btn btn-primary dashboard-new-expense-btn" onClick={onCreateNewClaim}>+ New Expense</button>
      </div>

      {needsInputClaim && (
        <div className="alert-banner warning">
          <strong>1 claim needs your input.</strong>
          <span>{needsInputClaim.claim_type}, {formatDate(needsInputClaim.expense_from)}. Reviewer: "{needsInputClaim.remarks || 'Please attach itemised bill.'}"</span>
          <button className="btn btn-secondary" onClick={() => onUpdateClaim(needsInputClaim.claim_id)}>Update claim</button>
        </div>
      )}

      <div className="metric-grid compact-metrics">
        <article className="metric-card">
          <h3>Total Claims</h3>
          <strong>{employeeClaims.length}</strong>
          <span>{formatCurrency(totalAmount)}</span>
        </article>
        <article className="metric-card">
          <h3>Approved</h3>
          <strong>{approved}</strong>
          <span>{formatCurrency(approvedAmount)}</span>
        </article>
        <article className="metric-card">
          <h3>Pending</h3>
          <strong>{submitted}</strong>
          <span>{formatCurrency(submittedAmount)}</span>
        </article>
        <article className="metric-card">
          <h3>Rejected</h3>
          <strong>{rejected}</strong>
          <span>{formatCurrency(rejectedAmount)}</span>
        </article>
      </div>

      <div className="panel-grid dashboard-two">
        <article className="panel-card">
          <h3>Spend By Month</h3>
          <div className="fake-bars" style={{ gridTemplateColumns: `repeat(${Math.max(monthlySpend.length, 1)}, minmax(0, 1fr))` }}>
            {monthlySpend.map((entry) => (
              <div key={entry.key} className="bar-wrap">
                <span style={{ height: `${entry.height}%` }} title={`${entry.label}: ${formatCurrency(entry.amount)}`} />
              </div>
            ))}
          </div>
          <div className="axis-row" style={{ gridTemplateColumns: `repeat(${Math.max(monthlySpend.length, 1)}, minmax(0, 1fr))` }}>
            {monthlySpend.map((entry) => <span key={`${entry.key}-label`}>{entry.label}</span>)}
          </div>
        </article>

        <article className="panel-card">
          <h3>By Category</h3>
          {categories.length ? categories.map((category, index) => {
            const width = totalCategoryAmount > 0
              ? Math.max((category.amount / totalCategoryAmount) * 100, category.amount > 0 ? 8 : 4)
              : 4

            return (
              <div key={category.name} className="progress-row">
                <span>{category.name} ({category.count})</span>
                <div className="track"><em style={{ width: `${Math.min(width, 100)}%`, opacity: 1 - index * 0.08 }} /></div>
              </div>
            )
          }) : <p className="empty-state">No category data available.</p>}
        </article>
      </div>

      <article className="panel-card table-panel modern-table">
        <h3>Recent Expenses</h3>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Title</th>
              <th>Type</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {employeeClaims.slice(0, 7).map((claim) => (
              <tr key={claim.claim_id}>
                <td>{formatDate(claim.expense_from)}</td>
                <td>{claim.claim_title || claim.claim_id}</td>
                <td>{claim.claim_type}</td>
                <td>{formatCurrency(claim.expense_amount)}</td>
                <td><span className={`status-badge ${claim.status.toLowerCase().replace('_', '-')}`}>{statusLabels[claim.status] || claim.status}</span></td>
                <td><button className="link-button" onClick={() => onOpenClaim(claim.claim_id)}>{claim.status === 'REJECTED' ? 'Update' : 'Edit'}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </article>
    </section>
  )
}
