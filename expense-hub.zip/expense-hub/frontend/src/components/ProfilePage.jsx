import { useState } from 'react'

export default function ProfilePage({
  user,
  statusLabels,
  profileDraft,
  managerOptions,
  departmentOptions,
  isProfileEditing,
  setProfileDraft,
  onSave,
  onChangePassword,
  onStartEdit,
  onCancelEdit
}) {
  const safeManagerOptions = Array.isArray(managerOptions) ? managerOptions : []
  const safeDepartmentOptions = Array.isArray(departmentOptions) ? departmentOptions : []
  const activeDepartment = String(profileDraft.department || '').trim()
  const mergedDepartmentOptions = activeDepartment && !safeDepartmentOptions.includes(activeDepartment)
    ? [activeDepartment, ...safeDepartmentOptions]
    : safeDepartmentOptions
  const [passwordDraft, setPasswordDraft] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  })
  const [passwordMessage, setPasswordMessage] = useState('')
  const [passwordError, setPasswordError] = useState('')
  const [isPasswordSubmitting, setIsPasswordSubmitting] = useState(false)
  const [showPasswordFields, setShowPasswordFields] = useState({
    currentPassword: false,
    newPassword: false,
    confirmPassword: false
  })

  const togglePasswordVisibility = (fieldName) => {
    setShowPasswordFields((prev) => ({
      ...prev,
      [fieldName]: !prev[fieldName]
    }))
  }

  const renderPasswordToggleIcon = (isVisible) => (isVisible ? (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
      <circle cx="12" cy="12" r="3" />
      <path d="M4 4L20 20" />
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 12S6 4.5 12 4.5 21.5 12 21.5 12 18 19.5 12 19.5 2.5 12 2.5 12Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  ))

  const handlePasswordSubmit = async () => {
    setPasswordError('')
    setPasswordMessage('')

    if (!onChangePassword) {
      setPasswordError('Password update is not available right now.')
      return
    }

    setIsPasswordSubmitting(true)
    const result = await onChangePassword(passwordDraft)
    setIsPasswordSubmitting(false)

    if (!result?.success) {
      setPasswordError(result?.message || 'Unable to update password.')
      return
    }

    setPasswordMessage(result.message || 'Password updated successfully.')
    setPasswordDraft({ currentPassword: '', newPassword: '', confirmPassword: '' })
  }

  return (
    <section className="content-panel">
      <div className="page-head">
        <div>
          <h1>Profile</h1>
        </div>
      </div>
      <div className="panel-card profile-card">
        <div className="profile-avatar">{user?.first_name?.[0] || 'U'}</div>
        <div className="profile-body">
          <h3>{user ? `${user.first_name} ${user.last_name}` : 'User'}</h3>
          <p>{user?.email}</p>
          <p>Role: {user?.role}</p>
          <p>Status: {statusLabels[user?.status] || user?.status}</p>

          <div className="profile-form-grid">
            <label>
              First Name
              <input
                type="text"
                value={profileDraft.first_name}
                disabled={!isProfileEditing}
                onChange={(event) => setProfileDraft((prev) => ({ ...prev, first_name: event.target.value }))}
              />
            </label>
            <label>
              Last Name
              <input
                type="text"
                value={profileDraft.last_name}
                disabled={!isProfileEditing}
                onChange={(event) => setProfileDraft((prev) => ({ ...prev, last_name: event.target.value }))}
              />
            </label>
            <label>
              Mobile Number
              <input
                type="text"
                value={profileDraft.mobile_number}
                disabled={!isProfileEditing}
                onChange={(event) => setProfileDraft((prev) => ({ ...prev, mobile_number: event.target.value }))}
              />
            </label>
            <label>
              Reporting Manager
              <select
                value={profileDraft.manager_id || ''}
                disabled={!isProfileEditing}
                onChange={(event) => setProfileDraft((prev) => ({ ...prev, manager_id: event.target.value }))}
              >
                <option value="">Select Manager</option>
                {safeManagerOptions.map((manager) => {
                  const roleLabel = String(manager.role || '').toUpperCase() === 'ADMIN' ? 'Admin' : 'Manager'
                  return (
                    <option key={manager.employee_id} value={manager.employee_id}>
                      {manager.first_name} {manager.last_name} ({roleLabel})
                    </option>
                  )
                })}
              </select>
            </label>
            <div className="profile-form-row">
              <label>
                Department
                <select
                  value={profileDraft.department}
                  disabled={!isProfileEditing}
                  onChange={(event) => setProfileDraft((prev) => ({ ...prev, department: event.target.value }))}
                >
                  {mergedDepartmentOptions.map((department) => (
                    <option key={department} value={department}>{department}</option>
                  ))}
                </select>
              </label>
              <label>
                Designation
                <input
                  type="text"
                  value={profileDraft.designation}
                  disabled={!isProfileEditing}
                  onChange={(event) => setProfileDraft((prev) => ({ ...prev, designation: event.target.value }))}
                />
              </label>
            </div>
          </div>

          <div className="profile-actions">
            {isProfileEditing ? (
              <>
                <button type="button" className="btn btn-primary" onClick={onSave}>Save Changes</button>
                <button type="button" className="btn btn-secondary" onClick={onCancelEdit}>Cancel</button>
              </>
            ) : (
              <button type="button" className="btn btn-primary" onClick={onStartEdit}>Edit Profile</button>
            )}
          </div>

          <div className="password-change-card">
            <h4>Change Password</h4>
            <div className="profile-password-grid">
              <label>
                Current Password
                <div className="password-input-wrap">
                  <input
                    type={showPasswordFields.currentPassword ? 'text' : 'password'}
                    value={passwordDraft.currentPassword}
                    onChange={(event) => setPasswordDraft((prev) => ({ ...prev, currentPassword: event.target.value }))}
                    placeholder="Enter current password"
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    aria-label={showPasswordFields.currentPassword ? 'Hide current password' : 'Show current password'}
                    onClick={() => togglePasswordVisibility('currentPassword')}
                  >
                    {renderPasswordToggleIcon(showPasswordFields.currentPassword)}
                  </button>
                </div>
              </label>
              <label>
                New Password
                <div className="password-input-wrap">
                  <input
                    type={showPasswordFields.newPassword ? 'text' : 'password'}
                    value={passwordDraft.newPassword}
                    onChange={(event) => setPasswordDraft((prev) => ({ ...prev, newPassword: event.target.value }))}
                    placeholder="Enter new password"
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    aria-label={showPasswordFields.newPassword ? 'Hide new password' : 'Show new password'}
                    onClick={() => togglePasswordVisibility('newPassword')}
                  >
                    {renderPasswordToggleIcon(showPasswordFields.newPassword)}
                  </button>
                </div>
              </label>
              <label>
                Confirm New Password
                <div className="password-input-wrap">
                  <input
                    type={showPasswordFields.confirmPassword ? 'text' : 'password'}
                    value={passwordDraft.confirmPassword}
                    onChange={(event) => setPasswordDraft((prev) => ({ ...prev, confirmPassword: event.target.value }))}
                    placeholder="Confirm new password"
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    aria-label={showPasswordFields.confirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                    onClick={() => togglePasswordVisibility('confirmPassword')}
                  >
                    {renderPasswordToggleIcon(showPasswordFields.confirmPassword)}
                  </button>
                </div>
              </label>
            </div>

            {passwordError && <span className="field-error">{passwordError}</span>}
            {passwordMessage && <p className="flash-text">{passwordMessage}</p>}

            <div className="profile-actions">
              <button type="button" className="btn btn-primary" onClick={handlePasswordSubmit} disabled={isPasswordSubmitting}>
                {isPasswordSubmitting ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
