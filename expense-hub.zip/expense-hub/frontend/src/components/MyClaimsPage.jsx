export default function MyClaimsPage({
  myClaims,
  statusLabels,
  formatDate,
  formatCurrency,
  onCreateNewClaim,
  onEditDraft,
  onViewClaim,
  MetricCard
}) {
  return (
    <section className="content-panel">
      <div className="page-head my-claims-head">
        <div>
          <p className="breadcrumb">Claims / My Claims</p>
          <h1>My Claims</h1>
        </div>
        <button className="btn btn-primary my-claims-new-btn" onClick={onCreateNewClaim}>+ New Claim</button>
      </div>

      <div className="metric-grid compact-metrics">
        <MetricCard title="Total Claims" value={myClaims.length} accent="blue" />
        <MetricCard title="Approved" value={myClaims.filter((claim) => claim.status === 'APPROVED').length} accent="green" />
        <MetricCard title="Under Review" value={myClaims.filter((claim) => claim.status === 'UNDER_REVIEW').length} accent="amber" />
        <MetricCard title="Rejected" value={myClaims.filter((claim) => claim.status === 'REJECTED').length} accent="red" />
      </div>

      <div className="panel-card table-panel my-claims-table-panel">
        <div className="my-claims-columns-placeholder">
          <span>Columns</span>
          <p>Claim ID | Type | Expense From | Expense To | Amount | Docs | Status | Created | Action</p>
        </div>

        <div className="my-claims-table-scroll">
          <table className="my-claims-table-grid">
            <thead>
              <tr>
                <th>Claim ID</th>
                <th>Type</th>
                <th>Expense From</th>
                <th>Expense To</th>
                <th>Amount</th>
                <th>Docs</th>
                <th>Status</th>
                <th>Created</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {myClaims.length ? myClaims.map((claim) => (
                <tr key={claim.claim_id}>
                  <td title={claim.claim_id}><span className="claim-id-ellipsis">{claim.claim_id}</span></td>
                  <td>{claim.claim_type}</td>
                  <td>{formatDate(claim.expense_from)}</td>
                  <td>{formatDate(claim.expense_to)}</td>
                  <td>{formatCurrency(claim.expense_amount)}</td>
                  <td>{claim.docs_count}</td>
                  <td><span className={`status-badge ${claim.status.toLowerCase().replace('_', '-')}`}>{statusLabels[claim.status] || claim.status}</span></td>
                  <td>{formatDate(claim.created_at)}</td>
                  <td>
                    <button
                      className="link-button claim-action-btn polished"
                      onClick={() => {
                        if (claim.status === 'DRAFT') {
                          onEditDraft(claim.claim_id)
                          return
                        }

                        onViewClaim(claim.claim_id)
                      }}
                    >
                      {claim.status === 'DRAFT' ? 'Edit' : 'View'}
                    </button>
                  </td>
                </tr>
              )) : <tr><td colSpan="9" className="empty-state">No claims found.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
