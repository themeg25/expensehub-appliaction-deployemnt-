function RequestInReviewPage() {
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="brand dark">ExpenseHub</div>
        <nav>
          <a href="#">Dashboard</a>
          <a href="#" className="active">My Claims</a>
          <a href="#">New Claim</a>
          <a href="#">Reports</a>
          <a href="#">Profile</a>
        </nav>
        <a className="support" href="#">Help & Support</a>
      </aside>

      <main className="content-area">
        <header className="topbar">
          <strong>Axiotech Private Limited</strong>
          <div className="user">Rahul Sharma</div>
        </header>

        <section className="review-center">
          <div className="doc-icon">Q</div>
          <h1>Your request is in review</h1>
          <p>
            Your access request for Axiotech Private Limited is currently under review by the administrator.
            You will be notified once it is approved.
          </p>

          <div className="review-card">
            <div>
              <span>Requested on</span>
              <strong>20 Sep 2026</strong>
            </div>
            <div>
              <span>Status</span>
              <strong className="pill">In Review</strong>
            </div>
          </div>

          <div className="progress-line">
            <div className="step active">Request Submitted</div>
            <div className="step">Under Review</div>
            <div className="step">Access Approved</div>
          </div>

          <div className="next-box">
            <h3>What happens next?</h3>
            <ol>
              <li>Your administrator will review your request and verify your details.</li>
              <li>You will receive an email notification once it is approved.</li>
              <li>After approval, you can sign in and start using the application.</li>
            </ol>
          </div>

          <button type="button" className="btn-secondary">Back to Sign In</button>
        </section>
      </main>
    </div>
  )
}

export default RequestInReviewPage
