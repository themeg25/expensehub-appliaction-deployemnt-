import { useMemo, useState } from 'react'

function parseAttachments(value) {
  try {
    const parsed = JSON.parse(value || '[]')
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function getStatusClass(status) {
  return String(status || '').toLowerCase().replace(/_/g, '-')
}

function toReadableLabel(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase())
}

function formatBytes(bytes = 0) {
  const size = Number(bytes || 0)
  if (!size || size <= 0) return '0 KB'
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(2)} MB`
}

export default function ClaimDetailsPage({
  currentClaim,
  formatDate,
  formatDateTime,
  formatCurrency,
  statusLabels,
  backTarget = '#/my-claims',
  backLabel = 'Back to My Claims',
  onResubmit,
  onOpenAttachment,
  onDownloadAllAttachments
}) {
  const [activeTab, setActiveTab] = useState('DETAILS')

  if (!currentClaim) return null

  const attachments = parseAttachments(currentClaim.attachments)
  const primaryAttachment = attachments[0] || null
  const showResubmit = currentClaim.status === 'REJECTED'
  const statusLabel = statusLabels[currentClaim.status] || toReadableLabel(currentClaim.status)

  const timeline = useMemo(() => {
    const rows = [
      {
        key: 'submitted',
        title: 'Submitted',
        subtitle: 'Claim submitted for review',
        at: currentClaim.created_at,
        tone: 'done'
      }
    ]

    if (['SUBMITTED', 'APPROVED', 'REJECTED', 'MORE_INFO_NEEDED'].includes(currentClaim.status)) {
      rows.push({
        key: 'under-review',
        title: 'Under Review',
        subtitle: 'Pending review by finance team',
        at: currentClaim.updated_at || currentClaim.created_at,
        tone: currentClaim.status === 'SUBMITTED' ? 'active' : 'done'
      })
    }

    if (['APPROVED', 'REJECTED', 'MORE_INFO_NEEDED'].includes(currentClaim.status)) {
      rows.push({
        key: currentClaim.status.toLowerCase(),
        title: statusLabel,
        subtitle: currentClaim.approved_by
          ? `Reviewed by ${currentClaim.approved_by}`
          : 'Reviewed by finance team',
        at: currentClaim.updated_at || currentClaim.created_at,
        tone: currentClaim.status === 'APPROVED' ? 'approved' : 'rejected'
      })
    }

    return rows
  }, [currentClaim.approved_by, currentClaim.created_at, currentClaim.status, currentClaim.updated_at, statusLabel])

  return (
    <section className="content-panel claim-details-page">
      <div className="claim-details-head">
        <a href={backTarget} className="claim-details-back">{backLabel}</a>
        <h1>Claim Details</h1>
        <p>View complete information about this expense claim.</p>
      </div>

      <div className="panel-card claim-summary-card">
        <div className="claim-summary-main">
          <div className="claim-summary-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 8.5h18v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5v-9Z" />
              <path d="M7 20v-3.5A1.5 1.5 0 0 1 8.5 15h7a1.5 1.5 0 0 1 1.5 1.5V20" />
              <path d="M7.5 8.5V7A1.5 1.5 0 0 1 9 5.5h6A1.5 1.5 0 0 1 16.5 7v1.5" />
            </svg>
          </div>

          <div className="claim-summary-text">
            <h2>{currentClaim.claim_title || currentClaim.claim_type}</h2>
            <p>{currentClaim.claim_description || 'Expense claim'}</p>
          </div>
        </div>

        <div className="claim-summary-amount">
          <span>Amount</span>
          <strong>{formatCurrency(currentClaim.expense_amount)}</strong>
          <span className={`status-badge ${getStatusClass(currentClaim.status)}`}>{statusLabel}</span>
        </div>

        <div className="claim-summary-meta">
          <div>
            <span>Claim ID</span>
            <strong>{currentClaim.claim_id}</strong>
          </div>
          <div>
            <span>Expense Date</span>
            <strong>{formatDate(currentClaim.expense_date || currentClaim.expense_from)}</strong>
          </div>
          <div>
            <span>Submitted On</span>
            <strong>{formatDateTime(currentClaim.created_at)}</strong>
          </div>
          <div>
            <span>Category</span>
            <strong>{currentClaim.claim_type}</strong>
          </div>
        </div>
      </div>

      <div className="details-layout">
        <div className="main-details">
          <div className="panel-card claim-tabs-card">
            <div className="claim-tabs-head">
              <button
                type="button"
                className={activeTab === 'DETAILS' ? 'active' : ''}
                onClick={() => setActiveTab('DETAILS')}
              >
                Details
              </button>
              <button
                type="button"
                className={activeTab === 'RECEIPTS' ? 'active' : ''}
                onClick={() => setActiveTab('RECEIPTS')}
              >
                Receipt
              </button>
              <button
                type="button"
                className={activeTab === 'HISTORY' ? 'active' : ''}
                onClick={() => setActiveTab('HISTORY')}
              >
                Approval History
              </button>
            </div>

            {activeTab === 'DETAILS' && (
              <div className="claim-tab-body">
                <h3>Expense Information</h3>
                <div className="claim-info-grid">
                  <div><span>Merchant / Vendor</span><strong>{currentClaim.vendor_name || currentClaim.vendor || 'N/A'}</strong></div>
                  <div><span>Category</span><strong>{currentClaim.claim_type}</strong></div>
                  <div><span>City</span><strong>{currentClaim.location || 'N/A'}</strong></div>
                  <div><span>Payment Mode</span><strong>{toReadableLabel(currentClaim.payment_mode || 'CARD')}</strong></div>
                  <div><span>Expense Date</span><strong>{formatDate(currentClaim.expense_date || currentClaim.expense_from)}</strong></div>
                  <div><span>Currency</span><strong>{currentClaim.currency || 'INR'}</strong></div>
                  <div><span>Amount</span><strong>{formatCurrency(currentClaim.expense_amount)}</strong></div>
                  <div><span>Proof Count</span><strong>{currentClaim.docs_count || attachments.length || 0}</strong></div>
                </div>

                <div className="claim-description-block">
                  <span>Description</span>
                  <p>{currentClaim.claim_description || 'No description provided.'}</p>
                </div>

                <div className="claim-additional-grid">
                  <div><span>Status</span><strong>{statusLabel}</strong></div>
                  <div><span>Reviewed By</span><strong>{currentClaim.approved_by || 'Pending'}</strong></div>
                  <div><span>Created At</span><strong>{formatDateTime(currentClaim.created_at)}</strong></div>
                  <div><span>Last Updated</span><strong>{formatDateTime(currentClaim.updated_at)}</strong></div>
                </div>
              </div>
            )}

            {activeTab === 'RECEIPTS' && (
              <div className="claim-tab-body">
                <div className="claim-receipt-head">
                  <h3>Uploaded Proofs</h3>
                  {attachments.length > 0 && (
                    <button type="button" className="btn btn-secondary proof-open-btn" onClick={() => onDownloadAllAttachments(currentClaim)}>
                      Download All
                    </button>
                  )}
                </div>
                {attachments.length ? (
                  <div className="proof-list">
                    {attachments.map((file, index) => (
                      <article className="proof-item" key={file.fileId || file.name}>
                        <div>
                          <strong>{file.name || 'Proof Document'}</strong>
                          <span>{toReadableLabel(file.mimeType)} . {formatBytes(file.size)}</span>
                        </div>
                        <button type="button" className="btn btn-secondary proof-open-btn" onClick={() => onOpenAttachment(currentClaim, file, index)}>
                          Open
                        </button>
                      </article>
                    ))}
                  </div>
                ) : (
                  <p className="empty-state">No proof documents uploaded for this claim.</p>
                )}
              </div>
            )}

            {activeTab === 'HISTORY' && (
              <div className="claim-tab-body">
                <h3>Approval Timeline</h3>
                <ol className="claim-timeline">
                  {timeline.map((entry) => (
                    <li key={entry.key} className={`tone-${entry.tone}`}>
                      <div className="timeline-dot" aria-hidden="true" />
                      <div>
                        <strong>{entry.title}</strong>
                        <p>{entry.subtitle}</p>
                        <span>{formatDateTime(entry.at)}</span>
                      </div>
                    </li>
                  ))}
                </ol>
                {currentClaim.reviewer_remarks && (
                  <div className="rejection-box">
                    <strong>Reviewer Remarks</strong>
                    <p>{currentClaim.reviewer_remarks}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="claim-details-actions">
            {showResubmit && (
              <button type="button" className="btn btn-primary" onClick={() => onResubmit(currentClaim.claim_id)}>
                Resubmit Claim
              </button>
            )}
          </div>
        </div>

        <aside className="details-side">
          <div className="panel-card proof-preview-card">
            <h3>Receipt / Proof</h3>
            {primaryAttachment ? (
              <div className="proof-preview-content">
                <div className="proof-preview-file">
                  <strong>{primaryAttachment.name || 'Proof Document'}</strong>
                  <span>{toReadableLabel(primaryAttachment.mimeType)} . {formatBytes(primaryAttachment.size)}</span>
                </div>
                <button type="button" className="btn btn-secondary" onClick={() => onOpenAttachment(currentClaim, primaryAttachment, 0)}>
                  Download Receipt
                </button>
              </div>
            ) : (
              <p className="empty-state">No proof available.</p>
            )}
          </div>

          <div className="panel-card approval-history-card">
            <h3>Approval History</h3>
            <ol className="claim-timeline compact">
              {timeline.map((entry) => (
                <li key={`side-${entry.key}`} className={`tone-${entry.tone}`}>
                  <div className="timeline-dot" aria-hidden="true" />
                  <div>
                    <strong>{entry.title}</strong>
                    <p>{entry.subtitle}</p>
                    <span>{formatDateTime(entry.at)}</span>
                  </div>
                </li>
              ))}
            </ol>

            {currentClaim.status === 'REJECTED' && currentClaim.reviewer_remarks && (
              <div className="rejection-box">
                <strong>Rejection Remarks</strong>
                <p>{currentClaim.reviewer_remarks}</p>
              </div>
            )}
          </div>
        </aside>
      </div>
    </section>
  )
}
