const companies = [
  {
    code: 'AX',
    name: 'Axiotech Private Limited',
    city: 'Bangalore, India',
    tag: 'AX01',
    claims: 12,
    total: 'Rs48,250',
    approved: 8,
    active: true
  },
  {
    code: 'C9',
    name: 'Cloud9 Services',
    city: 'Hyderabad, India',
    tag: 'CLOUD9',
    claims: 8,
    total: 'Rs21,400',
    approved: 6
  },
  {
    code: 'ST',
    name: 'Stylo Technologies',
    city: 'Pune, India',
    tag: 'STYLO',
    claims: 5,
    total: 'Rs12,800',
    approved: 4
  },
  {
    code: 'KI',
    name: 'Kiwi Innovations',
    city: 'Chennai, India',
    tag: 'KIWI',
    claims: 3,
    total: 'Rs6,200',
    approved: 2
  },
  {
    code: 'NS',
    name: 'NextGen Solutions',
    city: 'Mumbai, India',
    tag: 'NGS',
    claims: 7,
    total: 'Rs18,600',
    approved: 5
  },
  {
    code: 'GV',
    name: 'GovTech Ventures',
    city: 'Delhi, India',
    tag: 'GTV',
    claims: 4,
    total: 'Rs9,750',
    approved: 3
  }
]

function SelectCompanyPage() {
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="brand dark">ExpenseHub</div>
        <nav>
          <a href="#">Dashboard</a>
          <a href="#" className="active">Select Company</a>
          <a href="#">My Claims</a>
          <a href="#">New Claim</a>
          <a href="#">Reports</a>
          <a href="#">Profile</a>
          <a href="#">Settings</a>
        </nav>
        <a className="support" href="#">Help & Support</a>
      </aside>

      <main className="content-area">
        <header className="topbar">
          <strong>ExpenseHub</strong>
          <div className="user">Rahul Sharma</div>
        </header>

        <section className="company-section">
          <p>Welcome, Rahul!</p>
          <h1>Select Company</h1>
          <p>Choose a company to access your expense claims and related information.</p>

          <div className="search-row">
            <input type="text" placeholder="Search company by name, location or code..." />
            <button type="button" className="view-btn active">Grid</button>
            <button type="button" className="view-btn">List</button>
          </div>

          <div className="company-grid">
            {companies.map((company) => (
              <article key={company.name} className={company.active ? 'company-card active' : 'company-card'}>
                <div className="company-head">
                  <span className="company-code">{company.code}</span>
                  <div>
                    <h3>{company.name}</h3>
                    <p>{company.city}</p>
                  </div>
                  <span className="tag">{company.tag}</span>
                </div>
                <div className="stats-row">
                  <div><strong>{company.claims}</strong><span>My Claims</span></div>
                  <div><strong>{company.total}</strong><span>Total Claimed</span></div>
                  <div><strong>{company.approved}</strong><span>Approved</span></div>
                </div>
                <button type="button" className={company.active ? 'btn-primary' : 'btn-secondary'}>Continue</button>
              </article>
            ))}
          </div>

          <div className="contact-box">
            <div>
              <strong>Don\'t see your company?</strong>
              <p>Contact your administrator to get access to another company.</p>
            </div>
            <button type="button" className="btn-secondary">Contact Admin</button>
          </div>
        </section>
      </main>
    </div>
  )
}

export default SelectCompanyPage
