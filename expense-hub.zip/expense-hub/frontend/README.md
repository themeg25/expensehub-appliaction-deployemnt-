# Expense Hub Frontend

React + Vite client application for Expense Hub.

## Project Structure

```text
frontend/
  public/
  src/
    components/
    services/
  index.html
  vite.config.js
  package.json
  .env
```

## Setup

1. Install dependencies:

```bash
npm install
```

2. Configure the frontend environment in `.env`:

- `VITE_API_BASE_URL=http://localhost:4000/api`

3. Start the frontend:

```bash
npm run dev
```

Frontend default URL: `http://localhost:5173`

## Notes

- UI components are in `src/components`.
- API integration helpers are in `src/services`.
- The frontend uses the backend REST API directly and no longer depends on spreadsheet or intermediary proxy endpoints.
