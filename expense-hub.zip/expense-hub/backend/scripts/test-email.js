import { sendSecurityCodeEmail, verifySmtpConnection } from '../src/services/mailer.service.js'

const recipient = process.env.MAIL_TEST_RECIPIENT || process.argv[2] || 'test@yopmail.com'

async function main() {
  try {
    console.log('Verifying Microsoft 365 SMTP connectivity...')
    await verifySmtpConnection()
    console.log('SMTP verification succeeded.')

    const result = await sendSecurityCodeEmail({
      toEmail: recipient,
      code: '123456',
      firstName: 'Expense Hub Tester'
    })

    console.log('Test email sent successfully.', {
      accepted: result?.accepted ?? [],
      rejected: result?.rejected ?? [],
      response: result?.response ?? 'n/a'
    })
  } catch (error) {
    console.error('Email verification failed:', error?.message || error)
    process.exitCode = 1
  }
}

main()
