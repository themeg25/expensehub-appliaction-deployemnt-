import pool from '../config/database.js'

export async function findUserByEmail(email) {
  const result = await pool.query(
    'SELECT * FROM employees WHERE LOWER(email) = LOWER($1)',
    [email]
  )

  return result.rows[0] || null
}

export async function findUserById(id) {
  const result = await pool.query('SELECT * FROM employees WHERE employee_id = $1', [id])
  return result.rows[0] || null
}

export async function updateUserSecurityCode({ userId, securityCode }) {
  const result = await pool.query(
    `UPDATE employees
     SET security_code = $2,
         updated_at = NOW()
     WHERE employee_id = $1
     RETURNING *`,
    [userId, securityCode || null]
  )

  return result.rows[0] || null
}

export async function updateUserPasswordById({ userId, passwordHash }) {
  const result = await pool.query(
    `UPDATE employees
     SET password = $2,
         security_code = NULL,
         updated_at = NOW()
     WHERE employee_id = $1
     RETURNING *`,
    [userId, passwordHash]
  )

  return result.rows[0] || null
}

export async function updateUserProfileById({
  userId,
  firstName,
  lastName,
  mobileNumber,
  department,
  designation,
  managerId
}) {
  const result = await pool.query(
    `UPDATE employees
     SET first_name = $2,
         last_name = $3,
         mobile_number = $4,
         department = $5,
         designation = $6,
         manager_id = $7,
         updated_at = NOW()
     WHERE employee_id = $1
     RETURNING *`,
    [
      userId,
      firstName,
      lastName || null,
      mobileNumber || null,
      department || null,
      designation || null,
      managerId || null
    ]
  )

  return result.rows[0] || null
}

export async function createUser({
  firstName,
  lastName,
  email,
  password,
  mobileNumber,
  company,
  department,
  designation,
  role = 'EMPLOYEE',
  managerId,
  employeeCode
}) {
  const result = await pool.query(
    `INSERT INTO employees (
      employee_code,
      first_name,
      last_name,
      email,
      mobile_number,
      password,
      company,
      department,
      designation,
      role,
      manager_id,
      registration_status,
      account_status
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'PENDING', 'INACTIVE')
    RETURNING *`,
    [employeeCode || null, firstName, lastName || null, email, mobileNumber || null, password, company || 'AxiotechX', department || null, designation || null, role.toUpperCase(), managerId || null]
  )

  return result.rows[0]
}

export async function updateUserApproval({ id, isApproved, approvedBy, reason }) {
  const result = await pool.query(
    `UPDATE employees
     SET registration_status = $2,
         account_status = $3,
         approved_by = $4,
         approved_at = NOW(),
         rejection_reason = $5,
         updated_at = NOW()
     WHERE employee_id = $1
     RETURNING *`,
    [id, isApproved ? 'APPROVED' : 'REJECTED', isApproved ? 'ACTIVE' : 'INACTIVE', approvedBy || null, isApproved ? null : (reason || null)]
  )

  return result.rows[0] || null
}

export async function findManagerById(id) {
  const result = await pool.query(
    `SELECT * FROM employees
     WHERE employee_id = $1 AND role IN ('MANAGER', 'ADMIN') AND registration_status = 'APPROVED' AND account_status = 'ACTIVE'`,
    [id]
  )

  return result.rows[0] || null
}

export async function listManagers() {
  const result = await pool.query(
    `SELECT employee_id, first_name, last_name, email, designation, role
     FROM employees
     WHERE role IN ('MANAGER', 'ADMIN') AND registration_status = 'APPROVED' AND account_status = 'ACTIVE'
     ORDER BY first_name ASC, last_name ASC`
  )

  return result.rows
}

export async function listAdmins({ includeInactive = false } = {}) {
  const query = `
    SELECT employee_id, first_name, last_name, email, designation, role
    FROM employees
    WHERE role = 'ADMIN'
      AND registration_status = 'APPROVED'
      ${includeInactive ? '' : "AND account_status = 'ACTIVE'"}
    ORDER BY first_name ASC, last_name ASC
  `

  const result = await pool.query(query)
  return result.rows
}

export async function listUsers({ registrationStatus = null } = {}) {
  let query = 'SELECT * FROM employees'
  const values = []

  if (registrationStatus !== null) {
    query += ' WHERE registration_status = $1'
    values.push(registrationStatus)
  }

  query += ' ORDER BY created_at DESC'

  const result = await pool.query(query, values)
  return result.rows
}
