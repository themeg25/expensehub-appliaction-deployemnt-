import { checkDatabaseHealth } from '../config/database.js'

export async function getDatabaseStatus() {
  const result = await checkDatabaseHealth()
  return {
    ok: Boolean(result.ok),
    dbTime: result.db_time
  }
}
