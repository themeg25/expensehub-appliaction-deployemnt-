import pool from '../config/database.js'

function normalizeJsonbValue(value) {
  if (value === undefined || value === null) return null
  if (typeof value === 'string') return value
  return JSON.stringify(value)
}

export async function createExpense({
  employeeId,
  expenseType,
  expenseTitle,
  expenseDescription,
  expenseDate,
  expenseFrom,
  expenseTo,
  amount,
  currency,
  paymentMode,
  vendorName,
  location,
  documents,
  documentCount,
  status = 'DRAFT',
  employeeRemarks
}) {
  const result = await pool.query(
    `INSERT INTO epmployee_expenses (
      employee_id,
      expense_type,
      expense_title,
      expense_description,
      expense_date,
      expense_from,
      expense_to,
      amount,
      currency,
      payment_mode,
      vendor_name,
      location,
      documents,
      document_count,
      status,
      employee_remarks,
      created_at,
      updated_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    RETURNING *`,
    [
      employeeId,
      expenseType,
      expenseTitle,
      expenseDescription,
      expenseDate,
      expenseFrom || null,
      expenseTo || null,
      amount,
      currency || 'INR',
      paymentMode || null,
      vendorName || null,
      location || null,
      normalizeJsonbValue(documents || []),
      documentCount || 0,
      status,
      employeeRemarks || null
    ]
  )

  return result.rows[0]
}

export async function findExpenseById(id) {
  const result = await pool.query('SELECT * FROM epmployee_expenses WHERE expense_id = $1', [id])
  return result.rows[0] || null
}

export async function listExpensesForEmployee(employeeId) {
  const result = await pool.query(
    'SELECT * FROM epmployee_expenses WHERE employee_id = $1 ORDER BY created_at DESC',
    [employeeId]
  )

  return result.rows
}

export async function listExpensesForAdmin() {
  const result = await pool.query(
    `SELECT e.*, emp.first_name, emp.last_name, emp.email, emp.department
     FROM epmployee_expenses e
     JOIN employees emp ON emp.employee_id = e.employee_id
     ORDER BY e.created_at DESC`
  )

  return result.rows
}

export async function updateExpenseById(id, fields) {
  const entries = Object.entries(fields).filter(([, value]) => value !== undefined)

  if (!entries.length) {
    return findExpenseById(id)
  }

  const assignments = entries.map(([key], index) => `${key} = $${index + 1}`).join(', ')
  const values = entries.map(([key, value]) => (key === 'documents' ? normalizeJsonbValue(value) : value))

  const result = await pool.query(
    `UPDATE epmployee_expenses
     SET ${assignments}, updated_at = CURRENT_TIMESTAMP
     WHERE expense_id = $${entries.length + 1}
     RETURNING *`,
    [...values, id]
  )

  return result.rows[0] || null
}

export async function reviewExpense({ expenseId, reviewerId, decision, remark }) {
  const normalizedDecision = String(decision || '').toUpperCase()
  const normalizedRemark = String(remark || '').trim()

  const result = await pool.query(
    `UPDATE epmployee_expenses
     SET status = $1,
         reviewed_by = $2,
         reviewed_at = CURRENT_TIMESTAMP,
         admin_comments = $3,
         updated_at = CURRENT_TIMESTAMP
     WHERE expense_id = $4
     RETURNING *`,
    [normalizedDecision, reviewerId, normalizedRemark || null, expenseId]
  )

  return result.rows[0] || null
}

export async function getEmployeeExpenseSummary(employeeId) {
  const result = await pool.query(
    `SELECT
      COUNT(*)::int AS total_expenses,
      COALESCE(SUM(CASE WHEN status = 'APPROVED' THEN amount ELSE 0 END), 0)::numeric AS approved_total,
      COALESCE(SUM(CASE WHEN status = 'SUBMITTED' THEN amount ELSE 0 END), 0)::numeric AS submitted_total,
      COALESCE(SUM(CASE WHEN status = 'REJECTED' THEN amount ELSE 0 END), 0)::numeric AS rejected_total,
      COALESCE(SUM(CASE WHEN status = 'MORE_INFO_NEEDED' THEN amount ELSE 0 END), 0)::numeric AS more_info_total,
      COALESCE(SUM(CASE WHEN status IN ('APPROVED', 'SUBMITTED', 'REJECTED', 'MORE_INFO_NEEDED') THEN amount ELSE 0 END), 0)::numeric AS total_amount,
      COALESCE(SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END), 0)::int AS approved_count,
      COALESCE(SUM(CASE WHEN status = 'SUBMITTED' THEN 1 ELSE 0 END), 0)::int AS submitted_count,
      COALESCE(SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END), 0)::int AS rejected_count,
      COALESCE(SUM(CASE WHEN status = 'MORE_INFO_NEEDED' THEN 1 ELSE 0 END), 0)::int AS more_info_count
    FROM epmployee_expenses
    WHERE employee_id = $1`,
    [employeeId]
  )

  return result.rows[0]
}

export async function getAdminExpenseSummary() {
  const overallResult = await pool.query(
    `SELECT
      COUNT(*)::int AS total_expenses,
      COALESCE(SUM(CASE WHEN status = 'APPROVED' THEN amount ELSE 0 END), 0)::numeric AS approved_total,
      COALESCE(SUM(CASE WHEN status = 'SUBMITTED' THEN amount ELSE 0 END), 0)::numeric AS submitted_total,
      COALESCE(SUM(CASE WHEN status = 'REJECTED' THEN amount ELSE 0 END), 0)::numeric AS rejected_total,
      COALESCE(SUM(CASE WHEN status = 'MORE_INFO_NEEDED' THEN amount ELSE 0 END), 0)::numeric AS more_info_total,
      COALESCE(SUM(CASE WHEN status IN ('APPROVED', 'SUBMITTED', 'REJECTED', 'MORE_INFO_NEEDED') THEN amount ELSE 0 END), 0)::numeric AS total_amount,
      COUNT(DISTINCT employee_id)::int AS employee_count
    FROM epmployee_expenses`
  )

  const breakdownResult = await pool.query(
    `SELECT
      emp.employee_id,
      emp.first_name,
      emp.last_name,
      emp.email,
      COUNT(e.expense_id)::int AS total_expenses,
      COALESCE(SUM(e.amount), 0)::numeric AS total_amount,
      COALESCE(SUM(CASE WHEN e.status = 'APPROVED' THEN e.amount ELSE 0 END), 0)::numeric AS approved_total,
      COALESCE(SUM(CASE WHEN e.status = 'SUBMITTED' THEN e.amount ELSE 0 END), 0)::numeric AS submitted_total,
      COALESCE(SUM(CASE WHEN e.status = 'REJECTED' THEN e.amount ELSE 0 END), 0)::numeric AS rejected_total,
      COALESCE(SUM(CASE WHEN e.status = 'MORE_INFO_NEEDED' THEN e.amount ELSE 0 END), 0)::numeric AS more_info_total
    FROM employees emp
    LEFT JOIN epmployee_expenses e ON e.employee_id = emp.employee_id
    WHERE emp.registration_status = 'APPROVED'
    GROUP BY emp.employee_id, emp.first_name, emp.last_name, emp.email
    ORDER BY total_amount DESC NULLS LAST`
  )

  return {
    overall: overallResult.rows[0],
    byEmployee: breakdownResult.rows
  }
}
