import { Router } from 'express'
import {
  changePassword,
  forgotPasswordRequestCode,
  forgotPasswordReset,
  forgotPasswordVerifyCode,
  login,
  me,
  updateProfile,
  register
} from '../controllers/auth.controller.js'
import { requireAuth } from '../utils/auth.js'
import { listManagers } from '../services/auth.service.js'

const authRouter = Router()

/**
 * @openapi
 * /api/auth/managers:
 *   get:
 *     tags: [Auth]
 *     summary: List approved managers for employee registration
 *     responses:
 *       200:
 *         description: Approved manager list
 */
authRouter.get('/managers', async (_req, res) => {
  const managers = await listManagers()
  res.status(200).json({ success: true, data: managers })
})

/**
 * @openapi
 * /api/auth/register:
 *   post:
 *     tags: [Auth]
 *     summary: Register a new employee
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [first_name, email, password]
 *             properties:
 *               first_name:
 *                 type: string
 *               last_name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 format: password
 *               mobile_number:
 *                 type: string
 *               department:
 *                 type: string
 *               designation:
 *                 type: string
 *               manager_id:
 *                 type: string
 *                 nullable: true
 *     responses:
 *       201:
 *         description: Registration is submitted and pending approval
 */
authRouter.post('/register', register)

/**
 * @openapi
 * /api/auth/login:
 *   post:
 *     tags: [Auth]
 *     summary: Log in an approved user
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, password]
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 format: password
 *     responses:
 *       200:
 *         description: Login successful
 */
authRouter.post('/login', login)

authRouter.post('/forgot-password/request-code', forgotPasswordRequestCode)
authRouter.post('/forgot-password/verify-code', forgotPasswordVerifyCode)
authRouter.post('/forgot-password/reset', forgotPasswordReset)
authRouter.patch('/profile', requireAuth, updateProfile)
authRouter.post('/change-password', requireAuth, changePassword)

/**
 * @openapi
 * /api/auth/me:
 *   get:
 *     tags: [Auth]
 *     summary: Get current authenticated user
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Authenticated user details
 */
authRouter.get('/me', requireAuth, me)

export default authRouter
