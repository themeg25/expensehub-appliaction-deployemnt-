import { Router } from 'express'
import adminRouter from './admin.routes.js'
import authRouter from './auth.routes.js'
import expenseRouter from './expense.routes.js'
import healthRouter from './health.routes.js'

const router = Router()

router.use('/health', healthRouter)
router.use('/auth', authRouter)
router.use('/expenses', expenseRouter)
router.use('/admin', adminRouter)

export default router
