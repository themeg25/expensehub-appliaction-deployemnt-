import { Router } from 'express'
import {
  getAllRegistrations,
  approveRegistration,
  getAdminExpenseList,
  getAdminExpenseSummary,
  getPendingRegistrations,
  reviewExpense
} from '../controllers/admin.controller.js'
import { requireAuth, requireRole } from '../utils/auth.js'

const adminRouter = Router()

adminRouter.use(requireAuth, requireRole('admin'))

/**
 * @openapi
 * /api/admin/users:
 *   get:
 *     tags: [Admin]
 *     summary: List all employee registrations
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All user registrations
 */
adminRouter.get('/users', getPendingRegistrations)

/**
 * @openapi
 * /api/admin/users/all:
 *   get:
 *     tags: [Admin]
 *     summary: List all employee registrations by status
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: All user registrations
 */
adminRouter.get('/users/all', getAllRegistrations)

/**
 * @openapi
 * /api/admin/users/{userId}/approve:
 *   patch:
 *     tags: [Admin]
 *     summary: Approve or reject a registration
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Approval update result
 */
adminRouter.patch('/users/:userId/approve', approveRegistration)

/**
 * @openapi
 * /api/admin/expenses:
 *   get:
 *     tags: [Admin]
 *     summary: List all expenses for admin review
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Expenses list
 */
adminRouter.get('/expenses', getAdminExpenseList)

/**
 * @openapi
 * /api/admin/expenses/summary:
 *   get:
 *     tags: [Admin]
 *     summary: Get summary for the admin dashboard
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Summary data
 */
adminRouter.get('/expenses/summary', getAdminExpenseSummary)

/**
 * @openapi
 * /api/admin/expenses/{expenseId}/review:
 *   patch:
 *     tags: [Admin]
 *     summary: Review or reject an expense claim
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: expenseId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Review update result
 */
adminRouter.patch('/expenses/:expenseId/review', reviewExpense)

export default adminRouter
