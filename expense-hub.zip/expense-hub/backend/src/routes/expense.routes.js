import { Router } from 'express'
import {
  createExpense,
  downloadAllExpenseDocuments,
  downloadExpenseDocument,
  getAdminExpenseList,
  getAdminExpenseSummary,
  getMyExpenseById,
  getMyExpenseSummary,
  getMyExpenses,
  reviewExpense,
  updateExpense,
  uploadExpenseDocuments
} from '../controllers/expense.controller.js'
import { uploadExpenseProofs, uploadExpenseProofsToS3 } from '../middleware/upload.js'
import { requireAuth, requireRole } from '../utils/auth.js'

const expenseRouter = Router()

expenseRouter.use(requireAuth)

/**
 * @openapi
 * /api/expenses:
 *   post:
 *     tags: [Expenses]
 *     summary: Create a new expense claim
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required: [expense_type, expense_title, expense_description, expense_date, amount]
 *             properties:
 *               expense_type:
 *                 type: string
 *               expense_title:
 *                 type: string
 *               expense_description:
 *                 type: string
 *               expense_date:
 *                 type: string
 *                 format: date
 *               expense_from:
 *                 type: string
 *                 format: date
 *               expense_to:
 *                 type: string
 *                 format: date
 *               amount:
 *                 type: number
 *               currency:
 *                 type: string
 *               payment_mode:
 *                 type: string
 *               vendor_name:
 *                 type: string
 *               location:
 *                 type: string
 *               proofs:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *     responses:
 *       201:
 *         description: Expense created successfully
 */
expenseRouter.post('/', uploadExpenseProofsToS3.array('proofs', 10), createExpense)

/**
 * @openapi
 * /api/expenses/mine:
 *   get:
 *     tags: [Expenses]
 *     summary: List expenses for the current employee
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Expense list for employee
 */
expenseRouter.get('/mine', getMyExpenses)

/**
 * @openapi
 * /api/expenses/summary:
 *   get:
 *     tags: [Expenses]
 *     summary: Get current employee expense summary
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Employee expense summary
 */
expenseRouter.get('/summary', getMyExpenseSummary)

/**
 * @openapi
 * /api/expenses/{expenseId}/documents:
 *   post:
 *     tags: [Expenses]
 *     summary: Upload proof documents to S3 under the expense folder
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: expenseId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               files:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *     responses:
 *       200:
 *         description: Files uploaded to S3 successfully
 */
expenseRouter.post('/:expenseId/documents', uploadExpenseProofsToS3.array('files', 10), uploadExpenseDocuments)
expenseRouter.get('/:expenseId/documents/download-all', downloadAllExpenseDocuments)
expenseRouter.get('/:expenseId/documents/:documentIndex', downloadExpenseDocument)

/**
 * @openapi
 * /api/expenses/{expenseId}:
 *   get:
 *     tags: [Expenses]
 *     summary: Get one employee expense by id
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: expenseId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Expense details
 */
expenseRouter.get('/:expenseId', getMyExpenseById)

/**
 * @openapi
 * /api/expenses/{expenseId}:
 *   patch:
 *     tags: [Expenses]
 *     summary: Update an expense claim
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: expenseId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Expense updated
 */
expenseRouter.patch('/:expenseId', uploadExpenseProofsToS3.array('proofs', 10), updateExpense)

/**
 * @openapi
 * /api/expenses/admin/list:
 *   get:
 *     tags: [Expenses]
 *     summary: List expenses for admin review
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Admin expense list
 */
expenseRouter.get('/admin/list', requireRole('admin'), getAdminExpenseList)

/**
 * @openapi
 * /api/expenses/admin/summary:
 *   get:
 *     tags: [Expenses]
 *     summary: Get admin expense summary
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Admin summary data
 */
expenseRouter.get('/admin/summary', requireRole('admin'), getAdminExpenseSummary)

/**
 * @openapi
 * /api/expenses/admin/{expenseId}/review:
 *   patch:
 *     tags: [Expenses]
 *     summary: Approve or reject an expense claim
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: expenseId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Review result
 */
expenseRouter.patch('/admin/:expenseId/review', requireRole('admin'), reviewExpense)

export default expenseRouter
