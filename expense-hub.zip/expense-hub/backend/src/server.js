import app from './app.js'
import env from './config/env.js'
import { checkDatabaseHealth, initializeDatabase } from './config/database.js'
import { logError, logInfo, logWarn } from './utils/logger.js'

async function startServer() {
  try {
    try {
      if (env.initializeSchemaOnBoot) {
        await initializeDatabase()
      }
      await checkDatabaseHealth()
    } catch (databaseError) {
      if (env.databaseRequired) {
        throw databaseError
      }

      logWarn('Database connection failed, starting API in limited mode', {
        error: databaseError?.message || String(databaseError),
        databaseRequired: env.databaseRequired
      })
    }

    const server = app.listen(env.port, () => {
      logInfo('Expense Hub API is running', {
        port: env.port,
        environment: env.nodeEnv,
        databaseRequired: env.databaseRequired
      })
    })

    server.on('error', (listenError) => {
      logError('Failed to bind API server port', {
        port: env.port,
        error: listenError?.message || String(listenError),
        code: listenError?.code || 'UNKNOWN'
      })
      process.exit(1)
    })
  } catch (error) {
    logError('Failed to start Expense Hub API', {
      error: error?.message || String(error),
      stack: error?.stack || null
    })
    process.exit(1)
  }
}

startServer()
