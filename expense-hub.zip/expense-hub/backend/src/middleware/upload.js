import fs from 'fs'
import path from 'path'
import AWS from 'aws-sdk'
import multer from 'multer'
import env from '../config/env.js'

const uploadDir = path.resolve(process.cwd(), env.uploadDir)
fs.mkdirSync(uploadDir, { recursive: true })

const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf']

const fileFilter = (_req, file, callback) => {
  if (allowedTypes.includes(file.mimetype)) {
    return callback(null, true)
  }

  return callback(new Error('Only JPG, JPEG, PNG, and PDF files are allowed'))
}

const storage = multer.diskStorage({
  destination: (_req, _file, callback) => {
    callback(null, uploadDir)
  },
  filename: (_req, file, callback) => {
    const safeName = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${path.extname(file.originalname)}`
    callback(null, safeName)
  }
})

export const uploadExpenseProofs = multer({
  storage,
  fileFilter,
  limits: {
    files: 10,
    fileSize: 10 * 1024 * 1024
  }
})

export const uploadExpenseProofsToS3 = multer({
  storage: multer.memoryStorage(),
  fileFilter,
  limits: {
    files: 10,
    fileSize: 5 * 1024 * 1024
  }
})

function getS3RuntimeConfig() {
  const bucketName = env.awsS3Bucket || 'stylo-captain-bucket'
  const baseFolder = 'employee_expenses'
  const region = env.awsRegion || 'us-east-1'
  const useLocalStack = env.nodeEnv === 'development'
  const endpoint = useLocalStack ? env.awsEndpointUrl || 'http://localhost:4566' : undefined

  const maskedAccessKey = env.awsAccessKeyId ? `${env.awsAccessKeyId.slice(0, 4)}...${env.awsAccessKeyId.slice(-4)}` : 'Not Set'
  const maskedSecret = env.awsSecretAccessKey ? '********' : 'Not Set'

  const debugConfig = {
    mode: useLocalStack ? 'localstack' : 'aws',
    bucketName,
    baseFolder,
    region,
    endpoint,
    forcePathStyle: env.awsS3ForcePathStyle,
    accessKeyId: maskedAccessKey,
    secretAccessKey: maskedSecret
  }

  return {
    bucketName,
    baseFolder,
    region,
    endpoint,
    useLocalStack,
    debugConfig
  }
}

function createS3Client() {
  const runtime = getS3RuntimeConfig()

  if (!runtime.useLocalStack && (!env.awsAccessKeyId || !env.awsSecretAccessKey)) {
    throw new Error('AWS S3 credentials are missing. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in the environment.')
  }

  const s3 = new AWS.S3({
    region: runtime.region,
    endpoint: runtime.endpoint,
    sslEnabled: !runtime.useLocalStack,
    accessKeyId: env.awsAccessKeyId || 'test',
    secretAccessKey: env.awsSecretAccessKey || 'test',
    s3ForcePathStyle: env.awsS3ForcePathStyle,
    signatureVersion: 's3v4'
  })

  return { s3, runtime }
}

export function resolveDocumentStorage(doc = {}) {
  const runtime = getS3RuntimeConfig()
  const bucketName = doc.s3_bucket || runtime.bucketName

  let key = doc.s3_key || doc.key || null
  if (!key && typeof doc.url === 'string' && doc.url.trim()) {
    try {
      const parsed = new URL(doc.url)
      const pathname = parsed.pathname.replace(/^\/+/, '')
      if (pathname.startsWith(`${bucketName}/`)) {
        key = pathname.slice(bucketName.length + 1)
      } else {
        key = pathname
      }
    } catch {
      key = null
    }
  }

  return {
    bucketName,
    key
  }
}

export async function downloadFileFromS3({ bucketName, key }) {
  const { s3, runtime } = createS3Client()

  try {
    const object = await s3.getObject({
      Bucket: bucketName,
      Key: key
    }).promise()

    return {
      body: object.Body,
      contentType: object.ContentType || 'application/octet-stream',
      contentLength: object.ContentLength
    }
  } catch (error) {
    error.details = {
      ...(error.details || {}),
      awsConfig: runtime.debugConfig,
      key,
      bucketName
    }
    throw error
  }
}

export async function uploadFilesToS3(files = [], expenseId) {
  if (!Array.isArray(files) || !files.length) {
    return []
  }

  const { s3, runtime } = createS3Client()
  const {
    bucketName,
    baseFolder,
    region,
    endpoint,
    useLocalStack,
    debugConfig
  } = runtime

  console.log('[AWS S3 Config]', {
    ...debugConfig
  })

  if (useLocalStack) {
    console.log('[AWS S3] Using LocalStack endpoint for development environment.')
  }

  try {
    const uploads = await Promise.all(files.map(async (file) => {
      const safeFileName = String(file.originalname || 'document').replace(/[^a-zA-Z0-9._-]/g, '_')
      const key = `${baseFolder}/${expenseId}/${safeFileName}`
      const body = file.buffer || (file.path ? fs.readFileSync(file.path) : Buffer.alloc(0))

      await s3.putObject({
        Bucket: bucketName,
        Key: key,
        Body: body,
        ContentType: file.mimetype || 'application/octet-stream',
        ACL: 'private'
      }).promise()

      const url = useLocalStack
        ? `${endpoint}/${bucketName}/${key}`
        : `https://${bucketName}.s3.${region}.amazonaws.com/${key}`

      return {
        file_name: safeFileName,
        s3_key: key,
        s3_bucket: bucketName,
        mime_type: file.mimetype,
        size: file.size,
        url,
        uploaded_at: new Date().toISOString()
      }
    }))

    return uploads
  } catch (error) {
    error.details = {
      ...(error.details || {}),
      awsConfig: debugConfig
    }
    throw error
  }
}
