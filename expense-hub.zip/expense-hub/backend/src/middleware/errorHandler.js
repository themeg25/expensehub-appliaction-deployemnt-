import env from '../config/env.js'
import { logError } from '../utils/logger.js'

export default function errorHandler(err, req, res, _next) {
  const statusCode = err.statusCode || 500
  const response = {
    success: false,
    message: err.message || 'Internal Server Error'
  }

  if (err.details) {
    response.details = err.details
  }

  if (env.nodeEnv !== 'production') {
    response.stack = err.stack
  }

  logError('Request failed', {
    method: req.method,
    path: req.originalUrl,
    statusCode,
    message: err.message
  })

  res.status(statusCode).json(response)
}
