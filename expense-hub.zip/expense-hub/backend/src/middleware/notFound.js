import ApiError from '../utils/apiError.js'

export default function notFound(req, _res, next) {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`))
}
