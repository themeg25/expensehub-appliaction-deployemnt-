export function logInfo(message, metadata = {}) {
  console.log(JSON.stringify({ level: 'info', message, ...metadata, timestamp: new Date().toISOString() }))
}

export function logWarn(message, metadata = {}) {
  console.warn(JSON.stringify({ level: 'warn', message, ...metadata, timestamp: new Date().toISOString() }))
}

export function logError(message, metadata = {}) {
  console.error(JSON.stringify({ level: 'error', message, ...metadata, timestamp: new Date().toISOString() }))
}
