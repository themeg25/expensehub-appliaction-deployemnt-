import jwt from 'jsonwebtoken'
import env from '../config/env.js'
import ApiError from './apiError.js'

export function signToken(user) {
  return jwt.sign(
    {
      sub: user.employee_id || user.id,
      email: user.email,
      role: (user.role || 'EMPLOYEE').toUpperCase()
    },
    env.jwtSecret,
    { expiresIn: '7d' }
  )
}

export function verifyToken(token) {
  try {
    return jwt.verify(token, env.jwtSecret)
  } catch {
    throw new ApiError(401, 'Invalid or expired token')
  }
}

export function getAuthToken(req) {
  const authHeader = req.headers.authorization || ''
  const match = authHeader.match(/^Bearer\s+(.+)$/i)
  return match ? match[1] : null
}

export function requireAuth(req, _res, next) {
  const token = getAuthToken(req)

  if (!token) {
    return next(new ApiError(401, 'Authentication required'))
  }

  req.user = verifyToken(token)
  return next()
}

export function requireRole(...roles) {
  return (req, _res, next) => {
    const userRole = String(req.user?.role || '').toUpperCase()
    const allowedRoles = roles.map((role) => String(role).toUpperCase())

    if (!req.user || !allowedRoles.includes(userRole)) {
      return next(new ApiError(403, 'Access denied'))
    }

    return next()
  }
}
