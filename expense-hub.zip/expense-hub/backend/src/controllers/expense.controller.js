import ApiError from '../utils/apiError.js'
import { ZipArchive } from 'archiver'
import asyncHandler from '../middleware/asyncHandler.js'
import { findExpenseById, updateExpenseById } from '../repositories/expense.repository.js'
import {
  createEmployeeExpense,
  getAdminExpenses as getAllAdminExpenses,
  getAdminSummary,
  getEmployeeExpenseSummary as getEmployeeExpenseSummaryData,
  getEmployeeExpenses,
  getExpenseByIdForUser,
  reviewExpenseByAdmin,
  updateEmployeeExpense
} from '../services/expense.service.js'
import { downloadFileFromS3, resolveDocumentStorage, uploadFilesToS3 } from '../middleware/upload.js'

function canAccessExpense(user = {}, expense = {}) {
  const role = String(user.role || '').toUpperCase()
  if (['ADMIN', 'MANAGER'].includes(role)) {
    return true
  }

  return expense.employee_id === user.sub
}

function sanitizeDownloadName(value = '', fallback = 'document') {
  const safe = String(value || fallback).replace(/[^a-zA-Z0-9._-]/g, '_').replace(/_+/g, '_')
  return safe || fallback
}

async function getAuthorizedExpense(req, expenseId) {
  const expense = await findExpenseById(expenseId)
  if (!expense) {
    throw new ApiError(404, 'Expense not found')
  }

  if (!canAccessExpense(req.user, expense)) {
    throw new ApiError(403, 'You are not allowed to access this expense document')
  }

  return expense
}

export const createExpense = asyncHandler(async (req, res) => {
  const result = await createEmployeeExpense(req.user.sub, req.body, req.files || [])

  res.status(201).json({
    success: true,
    message: 'Expense created successfully',
    data: result
  })
})

export const getMyExpenses = asyncHandler(async (req, res) => {
  const result = await getEmployeeExpenses(req.user.sub)

  res.status(200).json({
    success: true,
    data: result
  })
})

export const uploadExpenseDocuments = asyncHandler(async (req, res) => {
  const { expenseId } = req.params
  const files = req.files || []

  if (!files.length) {
    throw new ApiError(400, 'At least one valid document is required.')
  }

  const expense = await findExpenseById(expenseId)
  if (!expense) {
    throw new ApiError(404, 'Expense not found')
  }

  if (expense.employee_id !== req.user.sub) {
    throw new ApiError(403, 'You can only upload documents to your own expense')
  }

  if (['APPROVED', 'REJECTED'].includes(expense.status)) {
    throw new ApiError(400, 'This expense has already been reviewed and cannot accept new documents')
  }

  const uploadedDocs = await uploadFilesToS3(files, expenseId)
  const existingDocs = Array.isArray(expense.documents) ? expense.documents : []
  const mergedDocs = [...existingDocs, ...uploadedDocs]

  const updatedExpense = await updateExpenseById(expenseId, {
    documents: mergedDocs,
    document_count: mergedDocs.length
  })

  res.status(200).json({
    success: true,
    message: 'Expense documents uploaded to S3 successfully',
    data: {
      expenseId,
      uploadedFiles: uploadedDocs,
      documents: updatedExpense.documents
    }
  })
})

export const getMyExpenseById = asyncHandler(async (req, res) => {
  const result = await getExpenseByIdForUser(req.user.sub, req.params.expenseId)

  res.status(200).json({
    success: true,
    data: result
  })
})

export const updateExpense = asyncHandler(async (req, res) => {
  const files = req.files || []
  const documentPayload = [
    ...(Array.isArray(req.body.documents) ? req.body.documents : []),
    ...(Array.isArray(req.body.proofs) ? req.body.proofs : [])
  ]

  if (!files.length && documentPayload.length && !documentPayload.every((doc) => {
    const value = typeof doc === 'string' ? doc : doc && (doc.s3_key || doc.url)
    return typeof value === 'string' && (value.includes('s3.amazonaws.com') || value.startsWith('https://') || value.startsWith('http://'))
  })) {
    throw new ApiError(400, 'Files cannot be uploaded from JSON metadata alone. Use multipart/form-data with the proofs field or upload via /api/expenses/:expenseId/documents first.')
  }

  const result = await updateEmployeeExpense(req.user.sub, req.params.expenseId, req.body, files)

  res.status(200).json({
    success: true,
    message: 'Expense updated successfully',
    data: result
  })
})

export const downloadExpenseDocument = asyncHandler(async (req, res) => {
  const { expenseId, documentIndex } = req.params
  const expense = await getAuthorizedExpense(req, expenseId)

  const docs = Array.isArray(expense.documents) ? expense.documents : []
  const index = Number.parseInt(documentIndex, 10)

  if (!Number.isInteger(index) || index < 0 || index >= docs.length) {
    throw new ApiError(404, 'Document not found for this claim')
  }

  const doc = docs[index] || {}
  const { bucketName, key } = resolveDocumentStorage(doc)
  if (!key) {
    throw new ApiError(400, 'Document storage key is missing for this claim proof')
  }

  const { body, contentType, contentLength } = await downloadFileFromS3({ bucketName, key })
  const fileName = sanitizeDownloadName(doc.file_name || key.split('/').pop(), `proof-${index + 1}`)

  res.setHeader('Content-Type', contentType || 'application/octet-stream')
  if (contentLength) {
    res.setHeader('Content-Length', String(contentLength))
  }
  res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`)
  res.status(200).send(body)
})

export const downloadAllExpenseDocuments = asyncHandler(async (req, res) => {
  const { expenseId } = req.params
  const expense = await getAuthorizedExpense(req, expenseId)

  const docs = Array.isArray(expense.documents) ? expense.documents : []
  if (!docs.length) {
    throw new ApiError(404, 'No documents found for this claim')
  }

  const zipName = `${sanitizeDownloadName(expense.claim_id || expense.expense_id || expenseId, 'claim')}-proofs.zip`
  res.setHeader('Content-Type', 'application/zip')
  res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`)

  const archive = new ZipArchive({ zlib: { level: 9 } })
  archive.on('error', (error) => {
    res.destroy(error)
  })
  archive.pipe(res)

  for (let index = 0; index < docs.length; index += 1) {
    const doc = docs[index] || {}
    const { bucketName, key } = resolveDocumentStorage(doc)
    if (!key) {
      continue
    }

    const { body } = await downloadFileFromS3({ bucketName, key })
    const fileName = sanitizeDownloadName(doc.file_name || key.split('/').pop(), `proof-${index + 1}`)
    archive.append(body, { name: fileName })
  }

  await archive.finalize()
})

export const getMyExpenseSummary = asyncHandler(async (req, res) => {
  const result = await getEmployeeExpenseSummaryData(req.user.sub)

  res.status(200).json({
    success: true,
    data: result
  })
})

export const getAdminExpenseList = asyncHandler(async (_req, res) => {
  const result = await getAllAdminExpenses()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const getAdminExpenseSummary = asyncHandler(async (_req, res) => {
  const result = await getAdminSummary()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const reviewExpense = asyncHandler(async (req, res) => {
  const result = await reviewExpenseByAdmin(req.user.sub, req.params.expenseId, req.body.decision, req.body.remark)

  res.status(200).json({
    success: true,
    message: `Expense ${req.body.decision} successfully`,
    data: result
  })
})
