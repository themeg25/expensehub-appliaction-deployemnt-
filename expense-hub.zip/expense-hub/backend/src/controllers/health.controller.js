import asyncHandler from '../middleware/asyncHandler.js'
import { buildHealthStatus } from '../services/health.service.js'

export const getHealth = asyncHandler(async (_req, res) => {
  const data = await buildHealthStatus()

  res.status(200).json({
    success: true,
    message: 'Service is healthy',
    data
  })
})
