import asyncHandler from '../middleware/asyncHandler.js'
import {
  changeOwnPassword,
  loginUser,
  registerUser,
  requestPasswordRecoveryCode,
  updateOwnProfile,
  resetPasswordWithSecurityCode,
  verifyPasswordRecoveryCode
} from '../services/auth.service.js'

export const register = asyncHandler(async (req, res) => {
  const result = await registerUser(req.body)

  res.status(201).json({
    success: true,
    message: result.message,
    data: result.user
  })
})

export const login = asyncHandler(async (req, res) => {
  const result = await loginUser(req.body)

  res.status(200).json({
    success: true,
    message: 'Login successful',
    data: result
  })
})

export const me = asyncHandler(async (req, res) => {
  res.status(200).json({
    success: true,
    data: {
      id: req.user.sub,
      email: req.user.email,
      role: req.user.role
    }
  })
})

export const forgotPasswordRequestCode = asyncHandler(async (req, res) => {
  const result = await requestPasswordRecoveryCode(req.body)

  res.status(200).json({
    success: true,
    message: result.message
  })
})

export const forgotPasswordVerifyCode = asyncHandler(async (req, res) => {
  const result = await verifyPasswordRecoveryCode(req.body)

  res.status(200).json({
    success: true,
    message: result.message
  })
})

export const forgotPasswordReset = asyncHandler(async (req, res) => {
  const result = await resetPasswordWithSecurityCode(req.body)

  res.status(200).json({
    success: true,
    message: result.message
  })
})

export const updateProfile = asyncHandler(async (req, res) => {
  const result = await updateOwnProfile(req.user.sub, req.body)

  res.status(200).json({
    success: true,
    message: result.message,
    data: result.user
  })
})

export const changePassword = asyncHandler(async (req, res) => {
  const result = await changeOwnPassword(req.user.sub, req.body)

  res.status(200).json({
    success: true,
    message: result.message
  })
})
