import asyncHandler from '../middleware/asyncHandler.js'
import { approveUserRegistration, listAllUsers, listPendingUsers } from '../services/auth.service.js'
import {
  getAdminExpenseSummary as getAdminExpenseSummaryData,
  getAdminExpenses as getAllAdminExpenses,
  reviewExpenseByAdmin
} from '../services/expense.service.js'

export const getPendingRegistrations = asyncHandler(async (_req, res) => {
  const result = await listAllUsers()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const getAllRegistrations = asyncHandler(async (_req, res) => {
  const result = await listAllUsers()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const approveRegistration = asyncHandler(async (req, res) => {
  const result = await approveUserRegistration({
    userId: req.params.userId,
    approved: req.body.approved,
    remark: req.body.remark,
    approvedBy: req.user.sub
  })

  res.status(200).json({
    success: true,
    message: result.message,
    data: result.user
  })
})

export const getAdminExpenseList = asyncHandler(async (_req, res) => {
  const result = await getAllAdminExpenses()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const getAdminExpenseSummary = asyncHandler(async (_req, res) => {
  const result = await getAdminExpenseSummaryData()

  res.status(200).json({
    success: true,
    data: result
  })
})

export const reviewExpense = asyncHandler(async (req, res) => {
  const result = await reviewExpenseByAdmin(req.user.sub, req.params.expenseId, req.body.decision, req.body.remark)

  res.status(200).json({
    success: true,
    message: `Expense ${req.body.decision} successfully`,
    data: result
  })
})
