import ApiError from '../utils/apiError.js'
import { uploadFilesToS3 } from '../middleware/upload.js'
import { findUserById, listAdmins } from '../repositories/user.repository.js'
import {
  createExpense,
  getAdminExpenseSummary as getAdminExpenseSummaryRepository,
  getEmployeeExpenseSummary as getEmployeeExpenseSummaryRepository,
  findExpenseById,
  listExpensesForAdmin,
  listExpensesForEmployee,
  reviewExpense,
  updateExpenseById
} from '../repositories/expense.repository.js'
import { sendExpenseNotificationEmail } from './mailer.service.js'

const VALID_EXPENSE_TYPES = [
  'TRAVEL',
  'FOOD',
  'STAY',
  'TECH',
  'OFFICE',
  'COMMUNICATION',
  'MAINTENANCE',
  'TRAINING',
  'CLIENT',
  'MARKETING',
  'PROFESSIONAL_SERVICES',
  'OTHERS'
]

const VALID_PAYMENT_MODES = ['CASH', 'UPI', 'CARD', 'BANK_TRANSFER', 'OTHER']

function normalizeDocumentList(documents, files = []) {
  const list = Array.isArray(documents) ? documents : []
  const uploadedDocs = files.map((file) => {
    const normalizedFile = file || {}
    const fileName = normalizedFile.file_name || normalizedFile.originalname || normalizedFile.name || 'document'
    const mimeType = normalizedFile.mime_type || normalizedFile.mimetype || normalizedFile.type || 'application/octet-stream'
    const item = {
      file_name: fileName,
      mime_type: mimeType,
      size: Number(normalizedFile.size || 0),
      uploaded_at: normalizedFile.uploaded_at || new Date().toISOString()
    }

    if (normalizedFile.stored_name) item.stored_name = normalizedFile.stored_name
    if (normalizedFile.path) item.path = normalizedFile.path
    if (normalizedFile.url) item.url = normalizedFile.url
    if (normalizedFile.s3_key) item.s3_key = normalizedFile.s3_key
    if (normalizedFile.s3_bucket) item.s3_bucket = normalizedFile.s3_bucket
    if (normalizedFile.location) item.location = normalizedFile.location

    return item
  })

  return [...list, ...uploadedDocs]
}

function normalizeExpensePayload(payload = {}) {
  const amountRaw = payload.amount ?? payload.total_amount
  const expenseDate = payload.expense_date ?? payload.expenseDate ?? payload.date
  const fromDate = payload.expense_from ?? payload.expenseFrom ?? payload.from
  const toDate = payload.expense_to ?? payload.expenseTo ?? payload.to

  return {
    expense_type: typeof payload.expense_type === 'string' ? payload.expense_type.trim().toUpperCase() : '',
    expense_title: typeof payload.expense_title === 'string' ? payload.expense_title.trim() : '',
    expense_description: typeof payload.expense_description === 'string' ? payload.expense_description.trim() : '',
    expense_date: expenseDate || null,
    expense_from: fromDate || null,
    expense_to: toDate || null,
    amount: amountRaw === undefined || amountRaw === null || amountRaw === '' ? null : Number(amountRaw),
    currency: typeof payload.currency === 'string' && payload.currency.trim() ? payload.currency.trim().toUpperCase() : 'INR',
    payment_mode: typeof payload.payment_mode === 'string' ? payload.payment_mode.trim().toUpperCase() : null,
    vendor_name: typeof payload.vendor_name === 'string' ? payload.vendor_name.trim() : null,
    location: typeof payload.location === 'string' ? payload.location.trim() : null,
    employee_remarks: typeof payload.employee_remarks === 'string' ? payload.employee_remarks.trim() : null,
    documents: Array.isArray(payload.documents) ? payload.documents : [],
    status: typeof payload.status === 'string' ? payload.status.trim().toUpperCase() : 'DRAFT'
  }
}

async function sendExpenseNotifications({ employee, expense, eventLabel, reviewerName = 'Expense Hub', remark = '' }) {
  if (!employee) return []

  const manager = employee?.manager_id ? await findUserById(employee.manager_id) : null
  const admins = await listAdmins().catch(() => [])

  const recipients = []
  const seen = new Set()
  const pushRecipient = (user, role) => {
    if (!user?.email) return
    const normalizedEmail = String(user.email).trim().toLowerCase()
    if (!normalizedEmail || seen.has(normalizedEmail)) return
    seen.add(normalizedEmail)
    recipients.push({
      email: normalizedEmail,
      recipientName: `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.email,
      role
    })
  }

  pushRecipient(employee, 'Employee')
  if (manager) pushRecipient(manager, 'Manager')
  admins.forEach((admin) => pushRecipient(admin, admin.role || 'Admin'))

  await Promise.allSettled(recipients.map(({ email, recipientName, role }) => sendExpenseNotificationEmail({
    toEmail: email,
    recipientName,
    employeeName: `${employee.first_name || ''} ${employee.last_name || ''}`.trim() || employee.email,
    expense,
    eventLabel,
    reviewerName,
    remark,
    recipientRole: role
  })))

  return recipients
}

export async function createEmployeeExpense(employeeId, payload, files = []) {
  const employee = await findUserById(employeeId)
  if (!employee) {
    throw new ApiError(404, 'Employee not found')
  }

  if (employee.registration_status !== 'APPROVED') {
    throw new ApiError(403, 'Employee account is not approved yet')
  }

  if (employee.account_status !== 'ACTIVE') {
    throw new ApiError(403, 'Employee account is not active')
  }

  const normalized = normalizeExpensePayload(payload)

  if (!normalized.expense_type || !VALID_EXPENSE_TYPES.includes(normalized.expense_type)) {
    throw new ApiError(400, 'Expense type is required and must be a valid expense category')
  }

  if (!normalized.expense_title || !normalized.expense_description || !normalized.expense_date) {
    throw new ApiError(400, 'Expense title, description, and date are required')
  }

  if (normalized.amount === null || Number.isNaN(normalized.amount) || normalized.amount <= 0) {
    throw new ApiError(400, 'Expense amount must be greater than zero')
  }

  if (normalized.payment_mode && !VALID_PAYMENT_MODES.includes(normalized.payment_mode)) {
    throw new ApiError(400, 'Payment mode is invalid')
  }

  const initialDocuments = normalizeDocumentList(normalized.documents, [])
  const initialDocumentCount = initialDocuments.length
  const status = ['DRAFT', 'SUBMITTED'].includes(normalized.status) ? normalized.status : 'DRAFT'

  if (status === 'SUBMITTED' && (initialDocumentCount + files.length < 1 || initialDocumentCount + files.length > 6)) {
    throw new ApiError(400, 'A submitted expense must have between 1 and 6 proof documents')
  }

  let expense = await createExpense({
    employeeId,
    expenseType: normalized.expense_type,
    expenseTitle: normalized.expense_title,
    expenseDescription: normalized.expense_description,
    expenseDate: normalized.expense_date,
    expenseFrom: normalized.expense_from,
    expenseTo: normalized.expense_to,
    amount: normalized.amount,
    currency: normalized.currency,
    paymentMode: normalized.payment_mode,
    vendorName: normalized.vendor_name,
    location: normalized.location,
    documents: initialDocuments,
    documentCount: initialDocumentCount,
    status,
    employeeRemarks: normalized.employee_remarks
  })

  if (Array.isArray(files) && files.length) {
    const uploadedS3Docs = await uploadFilesToS3(files, expense.expense_id)
    const mergedDocs = normalizeDocumentList(initialDocuments, uploadedS3Docs)

    expense = await updateExpenseById(expense.expense_id, {
      documents: mergedDocs,
      document_count: mergedDocs.length
    })
  }

  if (status === 'SUBMITTED') {
    await sendExpenseNotifications({
      employee,
      expense,
      eventLabel: 'created',
      reviewerName: `${employee.first_name || ''} ${employee.last_name || ''}`.trim() || 'Employee'
    })
  }

  return expense
}

export async function updateEmployeeExpense(employeeId, expenseId, payload, files = []) {
  const employee = await findUserById(employeeId)
  const expense = await findExpenseById(expenseId)

  if (!expense) {
    throw new ApiError(404, 'Expense not found')
  }

  if (!employee) {
    throw new ApiError(404, 'Employee not found')
  }

  if (expense.employee_id !== employeeId) {
    throw new ApiError(403, 'You can only update your own expenses')
  }

  if (['APPROVED', 'REJECTED'].includes(expense.status)) {
    throw new ApiError(400, 'This expense has already been reviewed and can no longer be edited')
  }

  let uploadedS3Docs = []
  if (Array.isArray(files) && files.length) {
    uploadedS3Docs = await uploadFilesToS3(files, expenseId)
  }

  const normalized = normalizeExpensePayload(payload)
  const updatePayload = {}

  if (normalized.expense_type) updatePayload.expense_type = normalized.expense_type
  if (normalized.expense_title) updatePayload.expense_title = normalized.expense_title
  if (normalized.expense_description) updatePayload.expense_description = normalized.expense_description
  if (normalized.expense_date) updatePayload.expense_date = normalized.expense_date
  if (normalized.expense_from !== null) updatePayload.expense_from = normalized.expense_from
  if (normalized.expense_to !== null) updatePayload.expense_to = normalized.expense_to
  if (normalized.amount !== null) updatePayload.amount = normalized.amount
  if (normalized.currency) updatePayload.currency = normalized.currency
  if (normalized.payment_mode !== null) updatePayload.payment_mode = normalized.payment_mode
  if (normalized.vendor_name !== null) updatePayload.vendor_name = normalized.vendor_name
  if (normalized.location !== null) updatePayload.location = normalized.location
  if (normalized.employee_remarks !== null) updatePayload.employee_remarks = normalized.employee_remarks

  if (files.length || Array.isArray(payload.documents)) {
    const existingDocs = Array.isArray(expense.documents) ? expense.documents : []
    const incomingJsonDocs = Array.isArray(payload.documents) ? payload.documents : []
    const validJsonDocs = incomingJsonDocs.filter((doc) => doc && (doc.s3_key || doc.url))

    const mergedDocs = normalizeDocumentList(existingDocs, uploadedS3Docs.length ? uploadedS3Docs : files)
    const finalDocs = [...validJsonDocs, ...mergedDocs]
    updatePayload.documents = finalDocs
    updatePayload.document_count = finalDocs.length
  }

  if (normalized.status && ['DRAFT', 'SUBMITTED', 'MORE_INFO_NEEDED'].includes(normalized.status)) {
    updatePayload.status = normalized.status
  }

  const updatedExpense = await updateExpenseById(expenseId, updatePayload)

  if (updatedExpense) {
    await sendExpenseNotifications({
      employee,
      expense: updatedExpense,
      eventLabel: updatedExpense.status === 'SUBMITTED' ? 'submitted' : 'updated',
      reviewerName: `${employee.first_name || ''} ${employee.last_name || ''}`.trim() || 'Employee'
    })
  }

  return updatedExpense
}

export async function getEmployeeExpenses(employeeId) {
  const employee = await findUserById(employeeId)
  if (!employee) {
    throw new ApiError(404, 'Employee not found')
  }

  return listExpensesForEmployee(employeeId)
}

export async function getExpenseByIdForUser(employeeId, expenseId) {
  const expense = await findExpenseById(expenseId)

  if (!expense) {
    throw new ApiError(404, 'Expense not found')
  }

  if (expense.employee_id !== employeeId) {
    throw new ApiError(403, 'You can only view your own expenses')
  }

  return expense
}

export async function reviewExpenseByAdmin(adminId, expenseId, decision, remark) {
  const expense = await findExpenseById(expenseId)
  if (!expense) {
    throw new ApiError(404, 'Expense not found')
  }

  const normalizedDecision = String(decision || '').trim().toUpperCase()
  if (!['APPROVED', 'REJECTED', 'MORE_INFO_NEEDED'].includes(normalizedDecision)) {
    throw new ApiError(400, 'Decision must be APPROVED, REJECTED, or MORE_INFO_NEEDED')
  }

  if (['REJECTED', 'MORE_INFO_NEEDED'].includes(normalizedDecision) && !String(remark || '').trim()) {
    throw new ApiError(400, 'Admin comments are required when rejecting or requesting more information')
  }

  const admin = await findUserById(adminId)
  if (!admin || !['ADMIN', 'MANAGER'].includes((admin.role || '').toUpperCase())) {
    throw new ApiError(403, 'Only admin/manager roles can review expenses')
  }

  const result = await reviewExpense({
    expenseId,
    reviewerId: adminId,
    decision: normalizedDecision,
    remark: String(remark || '').trim()
  })

  const employee = result?.employee_id ? await findUserById(result.employee_id) : null
  if (employee) {
    await sendExpenseNotifications({
      employee,
      expense: result,
      eventLabel: normalizedDecision.toLowerCase(),
      reviewerName: `${admin.first_name || ''} ${admin.last_name || ''}`.trim() || 'Admin',
      remark: String(remark || '').trim()
    })
  }

  return result
}

export async function getEmployeeExpenseSummary(employeeId) {
  const employee = await findUserById(employeeId)
  if (!employee) {
    throw new ApiError(404, 'Employee not found')
  }

  const summary = await getEmployeeExpenseSummaryRepository(employeeId)

  return {
    employee: {
      employeeId: employee.employee_id,
      firstName: employee.first_name,
      lastName: employee.last_name,
      email: employee.email
    },
    summary: {
      totalExpenses: Number(summary.total_expenses || 0),
      approvedCount: Number(summary.approved_count || 0),
      submittedCount: Number(summary.submitted_count || 0),
      rejectedCount: Number(summary.rejected_count || 0),
      moreInfoCount: Number(summary.more_info_count || 0),
      totalAmount: Number(summary.total_amount || 0),
      approvedTotal: Number(summary.approved_total || 0),
      submittedTotal: Number(summary.submitted_total || 0),
      rejectedTotal: Number(summary.rejected_total || 0),
      moreInfoTotal: Number(summary.more_info_total || 0)
    }
  }
}

export async function getAdminExpenseSummary() {
  const summary = await getAdminExpenseSummaryRepository()

  return {
    overall: {
      totalExpenses: Number(summary.overall.total_expenses || 0),
      totalAmount: Number(summary.overall.total_amount || 0),
      approvedTotal: Number(summary.overall.approved_total || 0),
      submittedTotal: Number(summary.overall.submitted_total || 0),
      rejectedTotal: Number(summary.overall.rejected_total || 0),
      moreInfoTotal: Number(summary.overall.more_info_total || 0),
      employeeCount: Number(summary.overall.employee_count || 0)
    },
    byEmployee: (summary.byEmployee || []).map((entry) => ({
      employeeId: entry.employee_id,
      firstName: entry.first_name,
      lastName: entry.last_name,
      email: entry.email,
      totalExpenses: Number(entry.total_expenses || 0),
      totalAmount: Number(entry.total_amount || 0),
      approvedTotal: Number(entry.approved_total || 0),
      submittedTotal: Number(entry.submitted_total || 0),
      rejectedTotal: Number(entry.rejected_total || 0),
      moreInfoTotal: Number(entry.more_info_total || 0)
    }))
  }
}

export async function getAdminExpenses() {
  return listExpensesForAdmin()
}

export async function getEmployeeSummary(employeeId) {
  return getEmployeeExpenseSummary(employeeId)
}

export async function getAdminSummary() {
  return getAdminExpenseSummary()
}
