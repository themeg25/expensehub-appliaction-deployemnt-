import nodemailer from 'nodemailer'
import { ConfidentialClientApplication } from '@azure/msal-node'
import env from '../config/env.js'

const OUTLOOK_OAUTH_SCOPE = 'https://outlook.office365.com/.default'
let transporter = null
let cachedAccessToken = null
let tokenExpiresAt = 0

function parseSmtpPort(value) {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : 587
}

function getSenderAddress() {
  return String(env.smtpUser || env.smtpFrom || 'no-reply@axiotechx.com').trim()
}

function getAzureConfig() {
  const tenantId = String(env.azureTenantId || '').trim()
  const clientId = String(env.azureClientId || '').trim()
  const clientSecret = String(env.azureClientSecret || '').trim()

  if (!tenantId || !clientId || !clientSecret) {
    return null
  }

  return { tenantId, clientId, clientSecret }
}

async function acquireAccessToken() {
  const azureConfig = getAzureConfig()
  if (!azureConfig) {
    throw new Error('Missing Microsoft 365 Azure OAuth configuration. Set AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET.')
  }

  const now = Date.now()
  if (cachedAccessToken && tokenExpiresAt > now + 60_000) {
    return cachedAccessToken
  }

  const msalClient = new ConfidentialClientApplication({
    auth: {
      clientId: azureConfig.clientId,
      authority: `https://login.microsoftonline.com/${azureConfig.tenantId}`,
      clientSecret: azureConfig.clientSecret
    }
  })

  const response = await msalClient.acquireTokenByClientCredential({
    scopes: [OUTLOOK_OAUTH_SCOPE]
  })

  if (!response?.accessToken) {
    throw new Error('Failed to acquire Microsoft 365 OAuth access token for SMTP.')
  }

  cachedAccessToken = response.accessToken

  if (response.expiresOn) {
    tokenExpiresAt = new Date(response.expiresOn).getTime() - 60_000
  } else {
    tokenExpiresAt = now + 50 * 60 * 1000
  }

  return cachedAccessToken
}

async function getTransporter() {
  if (transporter) {
    return transporter
  }

  const senderAddress = getSenderAddress()
  const smtpHost = String(env.smtpHost || 'smtp.office365.com').trim()
  const smtpPort = parseSmtpPort(env.smtpPort)
  const useSecureConnection = Boolean(env.smtpSecure && String(env.smtpSecure).toLowerCase() !== 'false')

  if (getAzureConfig()) {
    const accessToken = await acquireAccessToken()

    transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: useSecureConnection,
      requireTLS: true,
      auth: {
        type: 'OAuth2',
        user: senderAddress,
        accessToken
      }
    })

    return transporter
  }

  if (env.smtpUser && env.smtpPass) {
    transporter = nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: useSecureConnection,
      requireTLS: true,
      auth: {
        user: env.smtpUser,
        pass: env.smtpPass
      }
    })

    return transporter
  }

  throw new Error('Missing email transport settings. Configure Azure OAuth credentials or SMTP credentials.')
}

export async function verifySmtpConnection() {
  const transport = await getTransporter()
  await transport.verify()
  return true
}

function getFromAddress() {
  return String(env.smtpFrom || getSenderAddress()).trim()
}

function formatCurrency(value) {
  const amount = Number(value || 0)
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(amount)
}

function formatDate(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return String(value)
  return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(date)
}

function buildExpenseNotificationHtml({
  recipientName,
  employeeName,
  expense,
  eventLabel,
  reviewerName,
  remark,
  recipientRole
}) {
  const expenseId = String(expense?.expense_id || expense?.claim_id || 'N/A')
  const expenseTitle = String(expense?.expense_title || expense?.claim_title || 'Expense Claim').trim() || 'Expense Claim'
  const expenseType = String(expense?.expense_type || expense?.claim_type || 'General').trim() || 'General'
  const amount = formatCurrency(expense?.amount || expense?.expense_amount || 0)
  const status = String(expense?.status || 'SUBMITTED').toUpperCase()
  const eventText = String(eventLabel || 'Expense Update').trim() || 'Expense Update'
  const reviewerText = String(reviewerName || 'System').trim() || 'System'
  const remarkText = String(remark || '').trim()

  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Expense Hub Update</title>
      </head>
      <body style="margin:0; padding:0; background:#f3f7fb; font-family:Arial,Helvetica,sans-serif; color:#1f2d3d;">
        <div style="max-width:680px; margin:32px auto; background:#ffffff; border-radius:16px; overflow:hidden; border:1px solid #dfeaf8; box-shadow:0 12px 32px rgba(28,55,95,0.08);">
          <div style="background:linear-gradient(135deg, #0d5bd7 0%, #0b3b86 100%); padding:24px 28px; color:#ffffff;">
            <div style="font-size:12px; letter-spacing:1.6px; text-transform:uppercase; opacity:0.9;">Expense Hub</div>
            <h2 style="margin:10px 0 0; font-size:28px; line-height:1.2;">${eventText}</h2>
          </div>

          <div style="padding:28px;">
            <p style="margin:0 0 18px; font-size:15px; line-height:1.7; color:#2d3f57;">
              Hello ${recipientName || 'there'},<br />
              This is an update regarding the expense claim for <strong>${employeeName || 'Employee'}</strong>.
            </p>

            <div style="background:#f7faff; border:1px solid #dfeaf8; border-radius:12px; padding:18px; margin-bottom:22px;">
              <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:14px;">
                <div>
                  <div style="font-size:12px; color:#647899; text-transform:uppercase; letter-spacing:0.8px; margin-bottom:4px;">Claim ID</div>
                  <div style="font-size:18px; font-weight:700; color:#17345e;">${expenseId}</div>
                </div>
                <span style="display:inline-block; background:#e7f6ee; color:#1f7a4b; border-radius:999px; padding:7px 12px; font-size:12px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase;">
                  ${status}
                </span>
              </div>

              <table style="width:100%; border-collapse:collapse; font-size:14px; color:#2c4668;">
                <tr>
                  <td style="padding:8px 0; font-weight:700; width:170px; color:#4f6485;">Expense title</td>
                  <td style="padding:8px 0;">${expenseTitle}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Expense type</td>
                  <td style="padding:8px 0;">${expenseType}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Amount</td>
                  <td style="padding:8px 0;">${amount}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Date</td>
                  <td style="padding:8px 0;">${formatDate(expense?.expense_date || expense?.expense_from || expense?.created_at)}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Vendor</td>
                  <td style="padding:8px 0;">${String(expense?.vendor_name || '—').trim() || '—'}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Location</td>
                  <td style="padding:8px 0;">${String(expense?.location || '—').trim() || '—'}</td>
                </tr>
                <tr>
                  <td style="padding:8px 0; font-weight:700; color:#4f6485;">Payment mode</td>
                  <td style="padding:8px 0;">${String(expense?.payment_mode || '—').trim() || '—'}</td>
                </tr>
              </table>
            </div>

            <div style="background:#ffffff; border:1px solid #e4edf7; border-radius:12px; padding:16px 18px; margin-bottom:18px;">
              <div style="font-size:12px; color:#647899; text-transform:uppercase; letter-spacing:0.8px; margin-bottom:8px;">Action details</div>
              <p style="margin:0; font-size:14px; line-height:1.7; color:#2d3f57;">
                <strong>Updated by:</strong> ${reviewerText}<br />
                <strong>Role:</strong> ${recipientRole || 'Stakeholder'}<br />
                <strong>Current status:</strong> ${status}
              </p>
            </div>

            ${remarkText ? `
              <div style="background:#fff8eb; border:1px solid #f2d389; border-radius:12px; padding:16px 18px; margin-bottom:18px;">
                <div style="font-size:12px; color:#8b6519; text-transform:uppercase; letter-spacing:0.8px; margin-bottom:6px;">Comment</div>
                <p style="margin:0; font-size:14px; line-height:1.7; color:#684b12;">${remarkText}</p>
              </div>
            ` : ''}

            <p style="margin:0; font-size:14px; line-height:1.8; color:#2d3f57;">
              Please review the claim details in Expense Hub. Proof attachments are not included in this email for security purposes.
            </p>
          </div>

          <div style="background:#eef4ff; border-top:1px solid #dfeaf8; padding:18px 28px; font-size:12px; color:#587095; text-align:center;">
            This is an automated notification from Expense Hub.
          </div>
        </div>
      </body>
    </html>
  `
}

export async function sendSecurityCodeEmail({ toEmail, code, firstName }) {
  const displayName = String(firstName || '').trim() || 'there'
  const subject = 'Expense Hub password recovery code'
  const text = [
    `Hello ${displayName},`,
    '',
    `Use this security code to recover your Expense Hub account: ${code}`,
    '',
    'If you did not request this, please ignore this email.'
  ].join('\n')

  const transport = await getTransporter()

  try {
    const info = await transport.sendMail({
      from: getFromAddress(),
      to: toEmail,
      subject,
      text
    })

    return info
  } catch (error) {
    const message = error?.response || error?.message || 'SMTP send failed'
    const errorCode = error?.code || 'UNKNOWN'

    if (errorCode === 'EAUTH' || /535|535 5\.7\.3|authentication unsuccessful/i.test(message)) {
      throw new Error(`Microsoft 365 SMTP authentication failed. Verify the app registration has Microsoft Graph Mail.Send permissions and the mailbox allows sending as ${getFromAddress()}.`)
    }

    throw new Error(message)
  }
}

export async function sendExpenseNotificationEmail({
  toEmail,
  recipientName,
  employeeName,
  expense,
  eventLabel,
  reviewerName,
  remark,
  recipientRole
}) {
  if (!toEmail) return null

  const transport = await getTransporter()
  const html = buildExpenseNotificationHtml({
    recipientName,
    employeeName,
    expense,
    eventLabel,
    reviewerName,
    remark,
    recipientRole
  })
  const subject = `Expense claim ${String(expense?.status || eventLabel || 'updated').toUpperCase()} - ${String(expense?.expense_id || expense?.claim_id || 'N/A')}`
  const text = [
    `Hello ${recipientName || 'there'},`,
    '',
    `Expense claim ${String(expense?.expense_id || expense?.claim_id || 'N/A')} for ${employeeName || 'employee'} has been ${String(eventLabel || 'updated').toLowerCase()}.`,
    `Status: ${String(expense?.status || 'SUBMITTED').toUpperCase()}`,
    `Title: ${String(expense?.expense_title || expense?.claim_title || 'Expense Claim')}`,
    `Amount: ${formatCurrency(expense?.amount || expense?.expense_amount || 0)}`,
    `Type: ${String(expense?.expense_type || expense?.claim_type || 'General')}`,
    remark ? `Comment: ${remark}` : '',
    '',
    'Proof attachments are not included in this email for security reasons.'
  ].filter(Boolean).join('\n')

  return transport.sendMail({
    from: getFromAddress(),
    to: toEmail,
    subject,
    text,
    html
  })
}
