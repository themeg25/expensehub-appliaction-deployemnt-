import bcrypt from 'bcryptjs'
import ApiError from '../utils/apiError.js'
import { signToken } from '../utils/auth.js'
import {
  createUser,
  findUserByEmail,
  findUserById,
  findManagerById,
  listAdmins,
  listManagers as listApprovedManagers,
  listUsers,
  updateUserApproval,
  updateUserProfileById,
  updateUserPasswordById,
  updateUserSecurityCode
} from '../repositories/user.repository.js'
import { sendSecurityCodeEmail } from './mailer.service.js'

function sanitizeUser(user) {
  if (!user) return null

  const { password: _password, ...safeUser } = user
  return safeUser
}

function isStrongPassword(password) {
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,20}$/.test(String(password || ''))
}

function generateSecurityCode() {
  return String(Math.floor(100000 + Math.random() * 900000))
}

export async function registerUser({
  first_name,
  last_name,
  email,
  password,
  mobile_number,
  company,
  department,
  designation,
  role = 'EMPLOYEE',
  manager_id,
  employee_code
}) {
  const cleanFirstName = typeof first_name === 'string' ? first_name.trim() : ''
  const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : ''
  const cleanPassword = typeof password === 'string' ? password : ''

  if (!cleanFirstName || !cleanEmail || !cleanPassword) {
    throw new ApiError(400, 'First name, email, and password are required')
  }

  if (!cleanEmail.endsWith('@axiotechx.com')) {
    throw new ApiError(400, 'Only @axiotechx.com email addresses can register')
  }

  const safeRole = String(role || 'EMPLOYEE').toUpperCase()
  if (!['EMPLOYEE', 'MANAGER'].includes(safeRole)) {
    throw new ApiError(400, 'Role must be either EMPLOYEE or MANAGER')
  }

  if (!isStrongPassword(cleanPassword)) {
    throw new ApiError(400, 'Password must be 8-20 characters and include uppercase, lowercase, number, and special character')
  }

  if (safeRole === 'EMPLOYEE') {
    if (!manager_id) {
      throw new ApiError(400, 'A reporting manager is required for employee registration')
    }

    const manager = await findManagerById(manager_id)
    if (!manager) {
      throw new ApiError(400, 'Selected reporting manager is invalid')
    }
  }

  const existingUser = await findUserByEmail(cleanEmail)
  if (existingUser) {
    throw new ApiError(400, 'An account with this email already exists. Please use a different email.')
  }

  const storedUser = await createUser({
    firstName: cleanFirstName,
    lastName: typeof last_name === 'string' ? last_name.trim() : null,
    email: cleanEmail,
    password: await bcrypt.hash(cleanPassword, 10),
    mobileNumber: typeof mobile_number === 'string' ? mobile_number.trim() : null,
    company: typeof company === 'string' && company ? company : 'AxiotechX',
    department: typeof department === 'string' ? department.trim() : null,
    designation: typeof designation === 'string' ? designation.trim() : null,
    role: safeRole,
    managerId: safeRole === 'EMPLOYEE' ? manager_id : null,
    employeeCode: typeof employee_code === 'string' ? employee_code.trim() || null : null
  })

  return {
    user: sanitizeUser(storedUser),
    message: 'Registration submitted successfully. An admin must approve your account.'
  }
}

export async function loginUser({ email, password }) {
  const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : ''
  const cleanPassword = typeof password === 'string' ? password : ''

  if (!cleanEmail || !cleanPassword) {
    throw new ApiError(400, 'Email and password are required')
  }

  const user = await findUserByEmail(cleanEmail)
  if (!user) {
    throw new ApiError(400, 'We could not sign you in. Please check your email and password.')
  }

  const isPasswordValid = await bcrypt.compare(cleanPassword, user.password)
  if (!isPasswordValid) {
    throw new ApiError(400, 'We could not sign you in. Please check your email and password.')
  }

  if (user.registration_status !== 'APPROVED') {
    throw new ApiError(400, 'Your registration is still pending approval. Please wait for admin confirmation.')
  }

  if (user.account_status !== 'ACTIVE') {
    throw new ApiError(400, 'Your account is not active. Please contact the administrator.')
  }

  const token = signToken(user)

  return {
    token,
    user: sanitizeUser(user)
  }
}

export async function approveUserRegistration({ userId, approved, remark = '', approvedBy }) {
  const targetUser = await findUserById(userId)

  if (!targetUser) {
    throw new ApiError(404, 'Employee not found')
  }

  const shouldApprove = Boolean(approved)

  if (!shouldApprove && !String(remark || '').trim()) {
    throw new ApiError(400, 'A rejection reason is required when rejecting an employee registration')
  }

  const updatedUser = await updateUserApproval({
    id: userId,
    isApproved: shouldApprove,
    approvedBy,
    reason: String(remark || '').trim()
  })

  return {
    user: sanitizeUser(updatedUser),
    message: shouldApprove ? 'Employee registration approved successfully' : 'Employee registration rejected successfully'
  }
}

export async function listPendingUsers() {
  const users = await listUsers({ registrationStatus: 'PENDING' })
  return users.map((user) => sanitizeUser(user))
}

export async function listAllUsers() {
  const users = await listUsers()
  return users.map((user) => sanitizeUser(user))
}

export async function listManagers() {
  const managers = await listApprovedManagers()
  return managers.map((manager) => ({
    employee_id: manager.employee_id,
    first_name: manager.first_name,
    last_name: manager.last_name,
    email: manager.email,
    designation: manager.designation,
    role: manager.role
  }))
}

export async function listExpenseNotificationRecipients({ employeeId }) {
  const employee = await findUserById(employeeId)
  if (!employee) {
    throw new ApiError(404, 'Employee not found')
  }

  const manager = employee.manager_id ? await findUserById(employee.manager_id) : null
  const admins = await listAdmins()

  const recipients = []
  const seen = new Set()

  const pushRecipient = (user) => {
    if (!user?.email) return
    const normalizedEmail = String(user.email).trim().toLowerCase()
    if (!normalizedEmail || seen.has(normalizedEmail)) return
    seen.add(normalizedEmail)
    recipients.push({
      employee_id: user.employee_id,
      first_name: user.first_name,
      last_name: user.last_name,
      email: normalizedEmail,
      role: user.role
    })
  }

  pushRecipient(employee)
  if (manager) pushRecipient(manager)
  admins.forEach(pushRecipient)

  return recipients
}

export async function requestPasswordRecoveryCode({ email }) {
  const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : ''
  if (!cleanEmail) {
    throw new ApiError(400, 'Email is required')
  }

  const user = await findUserByEmail(cleanEmail)
  if (!user) {
    throw new ApiError(404, 'No account found for this email')
  }

  const securityCode = generateSecurityCode()
  await updateUserSecurityCode({ userId: user.employee_id, securityCode })
  await sendSecurityCodeEmail({
    toEmail: cleanEmail,
    code: securityCode,
    firstName: user.first_name
  })

  return {
    message: 'Security code sent. Please check your email inbox.'
  }
}

export async function verifyPasswordRecoveryCode({ email, security_code }) {
  const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : ''
  const cleanCode = String(security_code || '').trim()

  if (!cleanEmail || !cleanCode) {
    throw new ApiError(400, 'Email and security code are required')
  }

  const user = await findUserByEmail(cleanEmail)
  if (!user || String(user.security_code || '').trim() !== cleanCode) {
    throw new ApiError(400, 'Invalid security code')
  }

  return {
    message: 'Security code verified successfully.'
  }
}

export async function resetPasswordWithSecurityCode({ email, security_code, new_password, confirm_password }) {
  const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : ''
  const cleanCode = String(security_code || '').trim()
  const newPassword = String(new_password || '')
  const confirmPassword = String(confirm_password || '')

  if (!cleanEmail || !cleanCode || !newPassword || !confirmPassword) {
    throw new ApiError(400, 'Email, security code, new password, and confirm password are required')
  }

  if (newPassword !== confirmPassword) {
    throw new ApiError(400, 'Passwords do not match')
  }

  if (!isStrongPassword(newPassword)) {
    throw new ApiError(400, 'Password must be 8-20 characters and include uppercase, lowercase, number, and special character')
  }

  const user = await findUserByEmail(cleanEmail)
  if (!user || String(user.security_code || '').trim() !== cleanCode) {
    throw new ApiError(400, 'Invalid security code')
  }

  await updateUserPasswordById({
    userId: user.employee_id,
    passwordHash: await bcrypt.hash(newPassword, 10)
  })

  return {
    message: 'Password reset successful. Please sign in with your new password.'
  }
}

export async function updateOwnProfile(userId, {
  first_name,
  last_name,
  mobile_number,
  department,
  designation,
  manager_id
}) {
  const user = await findUserById(userId)
  if (!user) {
    throw new ApiError(404, 'User not found')
  }

  const firstName = String(first_name || '').trim()
  const lastName = String(last_name || '').trim()
  const mobileNumber = String(mobile_number || '').trim()
  const departmentValue = String(department || '').trim()
  const designationValue = String(designation || '').trim()
  const managerIdValue = String(manager_id || '').trim()

  if (!firstName) {
    throw new ApiError(400, 'First name is required')
  }

  if (!lastName) {
    throw new ApiError(400, 'Last name is required')
  }

  if (managerIdValue) {
    if (managerIdValue === String(userId)) {
      throw new ApiError(400, 'You cannot select yourself as reporting manager')
    }

    const manager = await findManagerById(managerIdValue)
    if (!manager) {
      throw new ApiError(400, 'Selected reporting manager is invalid')
    }
  }

  const updatedUser = await updateUserProfileById({
    userId,
    firstName,
    lastName,
    mobileNumber,
    department: departmentValue,
    designation: designationValue,
    managerId: managerIdValue || null
  })

  return {
    user: sanitizeUser(updatedUser),
    message: 'Profile updated successfully.'
  }
}

export async function changeOwnPassword(userId, {
  current_password,
  new_password,
  confirm_password
}) {
  const currentPassword = String(current_password || '')
  const newPassword = String(new_password || '')
  const confirmPassword = String(confirm_password || '')

  if (!currentPassword || !newPassword || !confirmPassword) {
    throw new ApiError(400, 'Current password, new password, and confirm password are required')
  }

  if (newPassword !== confirmPassword) {
    throw new ApiError(400, 'Passwords do not match')
  }

  if (!isStrongPassword(newPassword)) {
    throw new ApiError(400, 'Password must be 8-20 characters and include uppercase, lowercase, number, and special character')
  }

  const user = await findUserById(userId)
  if (!user) {
    throw new ApiError(404, 'User not found')
  }

  const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password)
  if (!isCurrentPasswordValid) {
    throw new ApiError(400, 'Current password is incorrect')
  }

  const isSamePassword = await bcrypt.compare(newPassword, user.password)
  if (isSamePassword) {
    throw new ApiError(400, 'New password must be different from current password')
  }

  await updateUserPasswordById({
    userId,
    passwordHash: await bcrypt.hash(newPassword, 10)
  })

  return {
    message: 'Password changed successfully.'
  }
}
