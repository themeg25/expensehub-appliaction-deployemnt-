import { getDatabaseStatus } from '../repositories/health.repository.js'

export async function buildHealthStatus() {
  const database = await getDatabaseStatus()

  return {
    status: database.ok ? 'ok' : 'degraded',
    service: 'expense-hub-api',
    uptimeSeconds: process.uptime(),
    timestamp: new Date().toISOString(),
    database
  }
}
