import pg from 'pg'
import env from './env.js'

const { Pool } = pg

const pool = new Pool({
  connectionString: env.databaseUrl,
  ssl: env.nodeEnv === 'production' ? { rejectUnauthorized: false } : false
})

pool.on('error', (error) => {
  console.error('Unexpected PostgreSQL pool error:', error)
})

export async function initializeDatabase() {
  await pool.query(`
    CREATE EXTENSION IF NOT EXISTS pgcrypto;

    CREATE TABLE IF NOT EXISTS employees (
      employee_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      employee_code VARCHAR(50) UNIQUE,
      first_name VARCHAR(100) NOT NULL,
      last_name VARCHAR(100),
      email VARCHAR(150) NOT NULL UNIQUE,
      mobile_number VARCHAR(20),
      password VARCHAR(255) NOT NULL,
      company VARCHAR(100) NOT NULL DEFAULT 'AxiotechX',
      department VARCHAR(100),
      designation VARCHAR(100),
      role VARCHAR(30) NOT NULL DEFAULT 'EMPLOYEE',
      manager_id UUID,
      registration_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
      account_status VARCHAR(30) NOT NULL DEFAULT 'INACTIVE',
      approved_by UUID,
      approved_at TIMESTAMP,
      rejection_reason TEXT,
      last_login_at TIMESTAMP,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT chk_employee_company CHECK (company = 'AxiotechX'),
      CONSTRAINT chk_employee_role CHECK (role IN ('EMPLOYEE', 'MANAGER', 'ADMIN')),
      CONSTRAINT chk_registration_status CHECK (registration_status IN ('PENDING', 'APPROVED', 'REJECTED')),
      CONSTRAINT chk_account_status CHECK (account_status IN ('ACTIVE', 'INACTIVE', 'BLOCKED')),
      CONSTRAINT fk_employee_manager FOREIGN KEY (manager_id) REFERENCES employees(employee_id),
      CONSTRAINT fk_employee_approved_by FOREIGN KEY (approved_by) REFERENCES employees(employee_id)
    );

    CREATE TABLE IF NOT EXISTS epmployee_expenses (
      expense_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      employee_id UUID NOT NULL,
      expense_type VARCHAR(40) NOT NULL,
      expense_title VARCHAR(200) NOT NULL,
      expense_description TEXT NOT NULL,
      expense_date DATE NOT NULL,
      expense_from DATE,
      expense_to DATE,
      amount DECIMAL(12,2) NOT NULL,
      currency VARCHAR(10) NOT NULL DEFAULT 'INR',
      payment_mode VARCHAR(30),
      vendor_name VARCHAR(200),
      location VARCHAR(200),
      documents JSONB,
      document_count SMALLINT NOT NULL DEFAULT 0,
      status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
      employee_remarks TEXT,
      reviewed_by UUID,
      reviewed_at TIMESTAMP,
      admin_comments TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_expense_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
      CONSTRAINT fk_expense_reviewer FOREIGN KEY (reviewed_by) REFERENCES employees(employee_id),
      CONSTRAINT chk_expense_type CHECK (expense_type IN (
        'TRAVEL', 'FOOD', 'STAY', 'TECH', 'OFFICE', 'COMMUNICATION', 'MAINTENANCE', 'TRAINING',
        'CLIENT', 'MARKETING', 'PROFESSIONAL_SERVICES', 'OTHERS'
      )),
      CONSTRAINT chk_payment_mode CHECK (
        payment_mode IS NULL OR payment_mode IN ('CASH', 'UPI', 'CARD', 'BANK_TRANSFER', 'OTHER')
      ),
      CONSTRAINT chk_expense_status CHECK (status IN ('DRAFT', 'SUBMITTED', 'MORE_INFO_NEEDED', 'APPROVED', 'REJECTED')),
      CONSTRAINT chk_expense_amount CHECK (amount > 0),
      CONSTRAINT chk_document_count CHECK (document_count BETWEEN 0 AND 6),
      CONSTRAINT chk_expense_dates CHECK (
        expense_to IS NULL OR expense_from IS NULL OR expense_to >= expense_from
      ),
      CONSTRAINT chk_review_comments CHECK (
        status NOT IN ('REJECTED', 'MORE_INFO_NEEDED') OR NULLIF(TRIM(admin_comments), '') IS NOT NULL
      ),
      CONSTRAINT chk_submitted_documents CHECK (
        status IN ('DRAFT', 'MORE_INFO_NEEDED') OR document_count BETWEEN 1 AND 6
      )
    );

    CREATE INDEX IF NOT EXISTS idx_expenses_employee_id ON epmployee_expenses(employee_id);
    CREATE INDEX IF NOT EXISTS idx_expenses_status ON epmployee_expenses(status);
    CREATE INDEX IF NOT EXISTS idx_expenses_expense_date ON epmployee_expenses(expense_date);
    CREATE INDEX IF NOT EXISTS idx_employees_manager_id ON employees(manager_id);
    CREATE INDEX IF NOT EXISTS idx_employees_registration_status ON employees(registration_status);
  `)
}

export async function checkDatabaseHealth() {
  const result = await pool.query('SELECT NOW() AS db_time, 1 AS ok')
  return result.rows[0]
}

export default pool
