import env from './env.js'

const config = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Expense Hub API',
      version: '1.0.0',
      description: 'Postgres-backed expense management API'
    },
    servers: [
      {
        url: `http://localhost:${env.port}`,
        description: 'Local development server'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      }
    }
  },
  apis: [
    './src/routes/*.js',
    './src/controllers/*.js'
  ]
}

export default config
