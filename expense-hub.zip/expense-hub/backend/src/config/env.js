import dotenv from 'dotenv'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const cwd = process.cwd()
const currentFilePath = fileURLToPath(import.meta.url)
const backendRoot = path.resolve(path.dirname(currentFilePath), '../..')

const candidateEnvDirs = [cwd, backendRoot]

candidateEnvDirs.forEach((dirPath) => {
  const envPath = path.join(dirPath, '.env')
  if (fs.existsSync(envPath)) {
    dotenv.config({ path: envPath, override: true })
  }
})

const nodeEnv = process.env.NODE_ENV || 'development'
candidateEnvDirs.forEach((dirPath) => {
  const envByStagePath = path.join(dirPath, `.env.${nodeEnv}`)
  if (fs.existsSync(envByStagePath)) {
    dotenv.config({ path: envByStagePath, override: true })
  }
})

const requiredVariables = ['DATABASE_URL']

requiredVariables.forEach((name) => {
  if (!process.env[name]) {
    throw new Error(`Missing required environment variable: ${name}`)
  }
})

function parseBoolean(value, defaultValue) {
  if (value === undefined || value === null || value === '') return defaultValue
  return ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase())
}

const env = {
  nodeEnv,
  port: Number(process.env.PORT || 4000),
  databaseUrl: process.env.DATABASE_URL,
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  jwtSecret: process.env.JWT_SECRET || 'expense-hub-dev-secret',
  uploadDir: process.env.UPLOAD_DIR || './uploads/proofs',
  awsRegion: process.env.AWS_REGION || 'us-east-1',
  awsUseLocalStack: nodeEnv === 'development',
  awsEndpointUrl: process.env.AWS_ENDPOINT_URL || 'http://localhost:4566',
  awsS3ForcePathStyle: parseBoolean(process.env.AWS_S3_FORCE_PATH_STYLE, true),
  awsS3Bucket: process.env.AWS_S3_BUCKET || 'stylo-captain-bucket',
  awsAccessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
  awsSecretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
  azureTenantId: process.env.AZURE_TENANT_ID || '',
  azureClientId: process.env.AZURE_CLIENT_ID || '',
  azureClientSecret: process.env.AZURE_CLIENT_SECRET || '',
  smtpHost: process.env.SMTP_HOST || 'smtp.office365.com',
  smtpPort: process.env.SMTP_PORT || '587',
  smtpSecure: parseBoolean(process.env.SMTP_SECURE, false),
  smtpUser: process.env.SMTP_USER || '',
  smtpPass: process.env.SMTP_PASS || '',
  smtpFrom: process.env.SMTP_FROM || '',
  databaseRequired: parseBoolean(process.env.DATABASE_REQUIRED, nodeEnv !== 'development'),
  initializeSchemaOnBoot: parseBoolean(process.env.DB_INIT_ON_BOOT, true)
}

export default env
