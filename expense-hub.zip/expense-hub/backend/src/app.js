import cors from 'cors'
import express from 'express'
import swaggerJsdoc from 'swagger-jsdoc'
import swaggerUi from 'swagger-ui-express'
import env from './config/env.js'
import swaggerConfig from './config/swagger.js'
import router from './routes/index.js'
import notFound from './middleware/notFound.js'
import errorHandler from './middleware/errorHandler.js'

const app = express()
const swaggerSpec = swaggerJsdoc(swaggerConfig)

app.use(cors({
  origin: env.corsOrigin,
  credentials: true
}))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  customSiteTitle: 'Expense Hub API Docs',
  customfavIcon: '',
  explorer: true
}))

app.use('/api', router)

app.use(notFound)
app.use(errorHandler)

export default app
