# Expense Hub Backend

Express.js and PostgreSQL backend foundation for scalable REST API development.

## Tech Stack

- Node.js + Express.js
- PostgreSQL (`pg`)
- CORS support
- Environment configuration with `dotenv`
- Centralized error handling middleware

## Project Structure

```text
backend/
  src/
    app.js
    server.js
    config/
      env.js
      database.js
    routes/
      index.js
      health.routes.js
    controllers/
      health.controller.js
    services/
      health.service.js
    repositories/
      health.repository.js
    models/
    middleware/
      asyncHandler.js
      notFound.js
      errorHandler.js
    utils/
      apiError.js
      logger.js
  .env
  .env.example
  package.json
```

## Setup

1. Install dependencies:

```bash
npm install
```

2. Configure environment variables:

- Copy `.env.example` to `.env`
- Update `DATABASE_URL` based on your PostgreSQL instance
- Update the Microsoft 365 values for `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`, `SMTP_HOST`, `SMTP_USER`, and `SMTP_FROM`
- Optionally copy `.env.development.example` to `.env.development`
- Optionally copy `.env.production.example` to `.env.production`

### Microsoft 365 SMTP with OAuth 2.0 Client Credentials

This backend now acquires a Microsoft 365 OAuth access token through the Azure MSAL client-credential flow and uses it with Nodemailer against `smtp.office365.com` on port `587` with STARTTLS. The token scope is `https://outlook.office365.com/.default`.

Required environment variables:

```bash
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-application-id
AZURE_CLIENT_SECRET=your-client-secret
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=no-reply@your-domain.com
SMTP_FROM=no-reply@your-domain.com
```

Notes:

- The app does not send emails on startup.
- Use the verification script below to test SMTP connectivity and delivery.
- The Microsoft 365 app registration must have the required mailbox or SMTP permission for sending via the configured identity.

### Verify SMTP and send a real test email

```bash
npm run test:email
```

To send the test to a specific address:

```bash
npm run test:email -- you@your-domain.com
```

The script performs a live `verify()` check and then sends a test security-code email. No email is sent automatically during application boot.

Environment loading order:

- `.env`
- `.env.<NODE_ENV>` (overrides `.env` when present)

Important runtime flags:

- `DATABASE_REQUIRED`:
  - `true` => server exits if database is unavailable
  - `false` => server starts in limited mode without DB
- `DB_INIT_ON_BOOT`:
  - `true` => creates/updates schema on boot
  - `false` => skips automatic schema initialization

3. Start the backend:

```bash
npm run dev
```

Alternative startup commands:

```bash
npm start
node server.js
```

The API starts on `http://localhost:4000` by default.

## Health Check

- Endpoint: `GET /api/health`
- URL: `http://localhost:4000/api/health`

Sample success response:

```json
{
  "success": true,
  "message": "Service is healthy",
  "data": {
    "status": "ok",
    "service": "expense-hub-api",
    "uptimeSeconds": 12.34,
    "timestamp": "2026-10-06T12:34:56.000Z",
    "database": {
      "ok": true,
      "dbTime": "2026-10-06T12:34:56.000Z"
    }
  }
}
```

## Notes

- Keep all upcoming business APIs under `routes -> controllers -> services -> repositories`.
- Use `models` for schema and ORM/query abstractions if you later introduce an ORM.
